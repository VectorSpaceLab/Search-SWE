// SPDX-FileCopyrightText: Copyright (c) 2018, NVIDIA Corporation. All rights reserved.
// SPDX-License-Identifier: Apache-2.0

/*! \file
 *  \brief Global operator new-based memory resource.
 */

#pragma once

#include <thrust/detail/config.h>

#if defined(_CCCL_IMPLICIT_SYSTEM_HEADER_GCC)
#  pragma GCC system_header
#elif defined(_CCCL_IMPLICIT_SYSTEM_HEADER_CLANG)
#  pragma clang system_header
#elif defined(_CCCL_IMPLICIT_SYSTEM_HEADER_MSVC)
#  pragma system_header
#endif // no system header

#include <thrust/mr/memory_resource.h>

THRUST_NAMESPACE_BEGIN
namespace mr
{
/** \addtogroup memory_resources Memory Resources
 *  \ingroup memory_management
 *  \{
 */

class new_delete_resource_base : public memory_resource<>
{
public:
  void* do_allocate(std::size_t bytes, // NOLINT(google-default-arguments)
                    std::size_t alignment = THRUST_MR_DEFAULT_ALIGNMENT) override
  {
#if __cpp_aligned_new >= 201606L
    return ::operator new(bytes, std::align_val_t(alignment));
#else // ^^^ __cpp_aligned_new >= 201606L ^^^ / vvv __cpp_aligned_new < 201606L vvv
    // allocate memory for bytes, plus potential alignment correction,
    // plus store of the correction offset
    void* p             = ::operator new(bytes + alignment + sizeof(std::size_t));
    std::size_t ptr_int = reinterpret_cast<std::size_t>(p);
    // calculate the offset, i.e. how many bytes of correction was necessary
    // to get an aligned pointer
    std::size_t offset = (ptr_int % alignment) ? (alignment - ptr_int % alignment) : 0;
    // calculate the return pointer
    char* ptr = static_cast<char*>(p) + offset;
    // store the offset right after the actually returned value
    std::size_t* offset_store = reinterpret_cast<std::size_t*>(ptr + bytes);
    *offset_store             = offset;
    return static_cast<void*>(ptr);
#endif // ^^^ __cpp_aligned_new < 201606L ^^^
  }

  void do_deallocate(void* p, // NOLINT(google-default-arguments)
                     [[maybe_unused]] std::size_t bytes,
                     [[maybe_unused]] std::size_t alignment = THRUST_MR_DEFAULT_ALIGNMENT) override
  {
#if __cpp_aligned_new >= 201606L
#  if __cpp_sized_deallocation >= 201309L
    ::operator delete(p, bytes, std::align_val_t(alignment));
#  else // ^^^ __cpp_sized_deallocation >= 201309L ^^^ / vvv __cpp_sized_deallocation < 201309L vvv
    ::operator delete(p, std::align_val_t(alignment));
#  endif // ^^^ __cpp_sized_deallocation < 201309L ^^^
#else // ^^^ __cpp_aligned_new >= 201606L ^^^ / vvv __cpp_aligned_new < 201606L vvv
    char* ptr = static_cast<char*>(p);
    // calculate where the offset is stored
    std::size_t* offset = reinterpret_cast<std::size_t*>(ptr + bytes);
    // calculate the original pointer
    p = static_cast<void*>(ptr - *offset);
    ::operator delete(p);
#endif // ^^^ __cpp_aligned_new < 201606L ^^^
  }
};

/*! A memory resource that uses global operators new and delete to allocate and deallocate memory. Uses
 * alignment-enabled overloads when available, otherwise uses regular overloads and implements alignment requirements by
 * itself.
 */
class new_delete_resource final : public new_delete_resource_base
{};

/*! \} // memory_resources
 */
} // namespace mr
THRUST_NAMESPACE_END
