// SPDX-FileCopyrightText: Copyright (c) 2008-2021, NVIDIA Corporation. All rights reserved.
// SPDX-License-Identifier: Apache-2.0

#pragma once

#include <thrust/detail/config.h>

#if defined(_CCCL_IMPLICIT_SYSTEM_HEADER_GCC)
#  pragma GCC system_header
#elif defined(_CCCL_IMPLICIT_SYSTEM_HEADER_CLANG)
#  pragma clang system_header
#elif defined(_CCCL_IMPLICIT_SYSTEM_HEADER_MSVC)
#  pragma system_header
#endif // no system header

#include <thrust/random/linear_feedback_shift_engine.h>

THRUST_NAMESPACE_BEGIN

namespace random
{
template <typename UIntType, size_t W, size_t K, size_t Q, size_t S>
_CCCL_HOST_DEVICE linear_feedback_shift_engine<UIntType, W, K, Q, S>::linear_feedback_shift_engine(result_type value)
{
  seed(value);
} // end linear_feedback_shift_engine::linear_feedback_shift_engine()

template <typename UIntType, size_t W, size_t K, size_t Q, size_t S>
_CCCL_HOST_DEVICE void linear_feedback_shift_engine<UIntType, W, K, Q, S>::seed(result_type value)
{
  m_value = value;
} // end linear_feedback_shift_engine::seed()

template <typename UIntType, size_t W, size_t K, size_t Q, size_t S>
_CCCL_HOST_DEVICE typename linear_feedback_shift_engine<UIntType, W, K, Q, S>::result_type
linear_feedback_shift_engine<UIntType, W, K, Q, S>::operator()()
{
  const UIntType b    = (((m_value << Q) ^ m_value) & wordmask) >> (K - S);
  const UIntType mask = ((~static_cast<UIntType>(0)) << (W - K)) & wordmask;
  m_value             = ((m_value & mask) << S) ^ b;
  return m_value;
} // end linear_feedback_shift_engine::operator()()

template <typename UIntType, size_t W, size_t K, size_t Q, size_t S>
_CCCL_HOST_DEVICE void linear_feedback_shift_engine<UIntType, W, K, Q, S>::discard(unsigned long long z)
{
  for (; z > 0; --z)
  {
    this->operator()();
  } // end for
} // end linear_feedback_shift_engine::discard()

template <typename UIntType, size_t W, size_t K, size_t Q, size_t S>
template <typename CharT, typename Traits>
std::basic_ostream<CharT, Traits>&
linear_feedback_shift_engine<UIntType, W, K, Q, S>::stream_out(std::basic_ostream<CharT, Traits>& os) const
{
  using ostream_type = std::basic_ostream<CharT, Traits>;
  using ios_base     = typename ostream_type::ios_base;

  // save old flags & fill character
  const typename ios_base::fmtflags flags = os.flags();
  const CharT fill                        = os.fill();

  os.flags(ios_base::dec | ios_base::fixed | ios_base::left);
  os.fill(os.widen(' '));

  // output one word of state
  os << m_value;

  // restore flags & fill character
  os.flags(flags);
  os.fill(fill);

  return os;
}

template <typename UIntType, size_t W, size_t K, size_t Q, size_t S>
template <typename CharT, typename Traits>
std::basic_istream<CharT, Traits>&
linear_feedback_shift_engine<UIntType, W, K, Q, S>::stream_in(std::basic_istream<CharT, Traits>& is)
{
  using istream_type = std::basic_istream<CharT, Traits>;
  using ios_base     = typename istream_type::ios_base;

  // save old flags
  const typename ios_base::fmtflags flags = is.flags();

  is.flags(ios_base::skipws);

  // input one word of state
  is >> m_value;

  // restore flags
  is.flags(flags);

  return is;
}

template <typename UIntType, size_t W, size_t K, size_t Q, size_t S>
_CCCL_HOST_DEVICE bool linear_feedback_shift_engine<UIntType, W, K, Q, S>::equal(
  const linear_feedback_shift_engine<UIntType, W, K, Q, S>& rhs) const
{
  return m_value == rhs.m_value;
}

template <typename UIntType, size_t W, size_t K, size_t Q, size_t S>
_CCCL_HOST_DEVICE bool operator==(const linear_feedback_shift_engine<UIntType, W, K, Q, S>& lhs,
                                  const linear_feedback_shift_engine<UIntType, W, K, Q, S>& rhs)
{
  return thrust::random::detail::random_core_access::equal(lhs, rhs);
}

template <typename UIntType, size_t W, size_t K, size_t Q, size_t S>
_CCCL_HOST_DEVICE bool operator!=(const linear_feedback_shift_engine<UIntType, W, K, Q, S>& lhs,
                                  const linear_feedback_shift_engine<UIntType, W, K, Q, S>& rhs)
{
  return !(lhs == rhs);
}

template <typename UIntType, size_t W, size_t K, size_t Q, size_t S, typename CharT, typename Traits>
std::basic_ostream<CharT, Traits>&
operator<<(std::basic_ostream<CharT, Traits>& os, const linear_feedback_shift_engine<UIntType, W, K, Q, S>& e)
{
  return thrust::random::detail::random_core_access::stream_out(os, e);
}

template <typename UIntType, size_t W, size_t K, size_t Q, size_t S, typename CharT, typename Traits>
std::basic_istream<CharT, Traits>&
operator>>(std::basic_istream<CharT, Traits>& is, linear_feedback_shift_engine<UIntType, W, K, Q, S>& e)
{
  return thrust::random::detail::random_core_access::stream_in(is, e);
}
} // namespace random

THRUST_NAMESPACE_END
