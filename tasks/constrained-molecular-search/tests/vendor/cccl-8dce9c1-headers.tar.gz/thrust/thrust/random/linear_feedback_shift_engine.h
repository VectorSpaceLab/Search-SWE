// SPDX-FileCopyrightText: Copyright (c) 2008-2013, NVIDIA Corporation. All rights reserved.
// SPDX-License-Identifier: Apache-2.0

/*! \file linear_feedback_shift_engine.h
 *  \brief A linear feedback shift pseudorandom number generator.
 */

/*
 * Copyright Jens Maurer 2002
 *
 * Distributed under the Boost Software License, Version 1.0.
 * (See accompanying NOTICE file for the complete license)
 *
 * For more information, see http://www.boost.org
 */

#pragma once

#include <thrust/detail/config.h>

#if defined(_CCCL_IMPLICIT_SYSTEM_HEADER_GCC)
#  pragma GCC system_header
#elif defined(_CCCL_IMPLICIT_SYSTEM_HEADER_CLANG)
#  pragma clang system_header
#elif defined(_CCCL_IMPLICIT_SYSTEM_HEADER_MSVC)
#  pragma system_header
#endif // no system header
#include <thrust/random/detail/linear_feedback_shift_engine_wordmask.h>
#include <thrust/random/detail/random_core_access.h>

#include <cuda/std/__host_stdlib/istream>
#include <cuda/std/__host_stdlib/ostream>
#include <cuda/std/cstddef> // for size_t

THRUST_NAMESPACE_BEGIN

namespace random
{
/*! \addtogroup random_number_engine_templates
 *  \{
 */

/*! \class linear_feedback_shift_engine
 *  \brief A \p linear_feedback_shift_engine random number engine produces
 *         unsigned integer random values using a linear feedback shift random number
 *         generation algorithm.
 *
 *  \tparam UIntType The type of unsigned integer to produce.
 *  \tparam W The word size of the produced values (<tt>W <= sizeof(UIntType)</tt>).
 *  \tparam K The K parameter of Tausworthe's 1965 algorithm.
 *  \tparam Q The Q exponent of Tausworthe's 1965 algorithm.
 *  \tparam S The step size of Tausworthe's 1965 algorithm.
 *
 *  \note linear_feedback_shift_engine is based on the Boost Template Library's linear_feedback_shift.
 */
template <typename UIntType, size_t W, size_t K, size_t Q, size_t S>
class linear_feedback_shift_engine
{
public:
  // types

  /*! \typedef result_type
   *  \brief The type of the unsigned integer produced by this \p linear_feedback_shift_engine.
   */
  using result_type = UIntType;

  // engine characteristics

  /*! The word size of the produced values.
   */
  static const size_t word_size = W;

  /*! A constant used in the generation algorithm.
   */
  static const size_t exponent1 = K;

  /*! A constant used in the generation algorithm.
   */
  static const size_t exponent2 = Q;

  /*! The step size used in the generation algorithm.
   */
  static const size_t step_size = S;

  /*! \cond
   */

private:
  static const result_type wordmask = detail::linear_feedback_shift_engine_wordmask<result_type, W>::value;
  /*! \endcond
   */

public:
  /*! The smallest value this \p linear_feedback_shift_engine may potentially produce.
   */
  static const result_type min = 0;

  /*! The largest value this \p linear_feedback_shift_engine may potentially produce.
   */
  static const result_type max = wordmask;

  /*! The default seed of this \p linear_feedback_shift_engine.
   */
  static const result_type default_seed = 341u;

  // constructors and seeding functions

  /*! This constructor, which optionally accepts a seed, initializes a new
   *  \p linear_feedback_shift_engine.
   *
   *  \param value The seed used to initialize this \p linear_feedback_shift_engine's state.
   */
  _CCCL_HOST_DEVICE explicit linear_feedback_shift_engine(result_type value = default_seed);

  /*! This method initializes this \p linear_feedback_shift_engine's state, and optionally accepts
   *  a seed value.
   *
   *  \param value The seed used to initializes this \p linear_feedback_shift_engine's state.
   */
  _CCCL_HOST_DEVICE void seed(result_type value = default_seed);

  // generating functions

  /*! This member function produces a new random value and updates this \p linear_feedback_shift_engine's state.
   *  \return A new random number.
   */
  _CCCL_HOST_DEVICE result_type operator()();

  /*! This member function advances this \p linear_feedback_shift_engine's state a given number of times
   *  and discards the results.
   *
   *  \param z The number of random values to discard.
   *  \note This function is provided because an implementation may be able to accelerate it.
   */
  _CCCL_HOST_DEVICE void discard(unsigned long long z);

  /*! \cond
   */

private:
  result_type m_value;

  friend struct thrust::random::detail::random_core_access;

  _CCCL_HOST_DEVICE bool equal(const linear_feedback_shift_engine& rhs) const;

  template <typename CharT, typename Traits>
  std::basic_ostream<CharT, Traits>& stream_out(std::basic_ostream<CharT, Traits>& os) const;

  template <typename CharT, typename Traits>
  std::basic_istream<CharT, Traits>& stream_in(std::basic_istream<CharT, Traits>& is);

  /*! \endcond
   */
}; // end linear_feedback_shift_engine

/*! This function checks two \p linear_feedback_shift_engines for equality.
 *  \param lhs The first \p linear_feedback_shift_engine to test.
 *  \param rhs The second \p linear_feedback_shift_engine to test.
 *  \return \c true if \p lhs is equal to \p rhs; \c false, otherwise.
 */
template <typename UIntType, size_t W, size_t K, size_t Q, size_t S>
_CCCL_HOST_DEVICE bool operator==(const linear_feedback_shift_engine<UIntType, W, K, Q, S>& lhs,
                                  const linear_feedback_shift_engine<UIntType, W, K, Q, S>& rhs);

/*! This function checks two \p linear_feedback_shift_engines for inequality.
 *  \param lhs The first \p linear_feedback_shift_engine to test.
 *  \param rhs The second \p linear_feedback_shift_engine to test.
 *  \return \c true if \p lhs is not equal to \p rhs; \c false, otherwise.
 */
template <typename UIntType, size_t W, size_t K, size_t Q, size_t S>
_CCCL_HOST_DEVICE bool operator!=(const linear_feedback_shift_engine<UIntType, W, K, Q, S>& lhs,
                                  const linear_feedback_shift_engine<UIntType, W, K, Q, S>& rhs);

/*! This function streams a linear_feedback_shift_engine to a \p std::basic_ostream.
 *  \param os The \p basic_ostream to stream out to.
 *  \param e The \p linear_feedback_shift_engine to stream out.
 *  \return \p os
 */
template <typename UIntType, size_t W, size_t K, size_t Q, size_t S, typename CharT, typename Traits>
std::basic_ostream<CharT, Traits>&
operator<<(std::basic_ostream<CharT, Traits>& os, const linear_feedback_shift_engine<UIntType, W, K, Q, S>& e);

/*! This function streams a linear_feedback_shift_engine in from a std::basic_istream.
 *  \param is The \p basic_istream to stream from.
 *  \param e The \p linear_feedback_shift_engine to stream in.
 *  \return \p is
 */
template <typename UIntType, size_t W, size_t K, size_t Q, size_t S, typename CharT, typename Traits>
std::basic_istream<CharT, Traits>&
operator>>(std::basic_istream<CharT, Traits>& is, linear_feedback_shift_engine<UIntType, W, K, Q, S>& e);

/*! \} // end random_number_engine_templates
 */
} // namespace random

// import names into thrust::
using random::linear_feedback_shift_engine;

THRUST_NAMESPACE_END

#include <thrust/random/detail/linear_feedback_shift_engine.inl>
