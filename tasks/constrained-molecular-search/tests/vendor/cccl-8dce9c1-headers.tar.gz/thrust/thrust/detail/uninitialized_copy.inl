// SPDX-FileCopyrightText: Copyright (c) 2008-2013, NVIDIA Corporation. All rights reserved.
// SPDX-License-Identifier: Apache-2.0

#pragma once

#include <thrust/detail/config.h>

#if defined(_CCCL_IMPLICIT_SYSTEM_HEADER_GCC)
#  pragma GCC system_header
#elif defined(_CCCL_IMPLICIT_SYSTEM_HEADER_CLANG)
#  pragma clang system_header
#elif defined(_CCCL_IMPLICIT_SYSTEM_HEADER_MSVC)
#  pragma system_header
#endif // no system header

#include <thrust/iterator/iterator_traits.h>
#include <thrust/system/detail/generic/select_system.h>
#include <thrust/uninitialized_copy.h>

// Include all active backend system implementations (generic, sequential, host and device)
#include <thrust/system/detail/generic/uninitialized_copy.h>
#include <thrust/system/detail/sequential/uninitialized_copy.h>
#include __THRUST_HOST_SYSTEM_ALGORITH_DETAIL_HEADER_INCLUDE(uninitialized_copy.h)
#include __THRUST_DEVICE_SYSTEM_ALGORITH_DETAIL_HEADER_INCLUDE(uninitialized_copy.h)

// Some build systems need a hint to know which files we could include
#if 0
#  include <thrust/system/cpp/detail/uninitialized_copy.h>
#  include <thrust/system/cuda/detail/uninitialized_copy.h>
#  include <thrust/system/omp/detail/uninitialized_copy.h>
#  include <thrust/system/tbb/detail/uninitialized_copy.h>
#endif

THRUST_NAMESPACE_BEGIN

_CCCL_EXEC_CHECK_DISABLE
template <typename DerivedPolicy, typename InputIterator, typename ForwardIterator>
_CCCL_HOST_DEVICE ForwardIterator uninitialized_copy(
  const thrust::detail::execution_policy_base<DerivedPolicy>& exec,
  InputIterator first,
  InputIterator last,
  ForwardIterator result)
{
  _CCCL_NVTX_RANGE_SCOPE("uninitialized_copy");
  using thrust::system::detail::generic::uninitialized_copy;
  return uninitialized_copy(thrust::detail::derived_cast(thrust::detail::strip_const(exec)), first, last, result);
} // end uninitialized_copy()

_CCCL_EXEC_CHECK_DISABLE
template <typename DerivedPolicy, typename InputIterator, typename Size, typename ForwardIterator>
_CCCL_HOST_DEVICE ForwardIterator uninitialized_copy_n(
  const thrust::detail::execution_policy_base<DerivedPolicy>& exec, InputIterator first, Size n, ForwardIterator result)
{
  _CCCL_NVTX_RANGE_SCOPE("uninitialized_copy_n");
  using thrust::system::detail::generic::uninitialized_copy_n;
  return uninitialized_copy_n(thrust::detail::derived_cast(thrust::detail::strip_const(exec)), first, n, result);
} // end uninitialized_copy_n()

template <typename InputIterator, typename ForwardIterator>
ForwardIterator uninitialized_copy(InputIterator first, InputIterator last, ForwardIterator result)
{
  _CCCL_NVTX_RANGE_SCOPE("uninitialized_copy");
  using thrust::system::detail::generic::select_system;

  using System1 = typename thrust::iterator_system<InputIterator>::type;
  using System2 = typename thrust::iterator_system<ForwardIterator>::type;

  System1 system1;
  System2 system2;

  return thrust::uninitialized_copy(select_system(system1, system2), first, last, result);
} // end uninitialized_copy()

template <typename InputIterator, typename Size, typename ForwardIterator>
ForwardIterator uninitialized_copy_n(InputIterator first, Size n, ForwardIterator result)
{
  _CCCL_NVTX_RANGE_SCOPE("uninitialized_copy_n");
  using thrust::system::detail::generic::select_system;

  using System1 = typename thrust::iterator_system<InputIterator>::type;
  using System2 = typename thrust::iterator_system<ForwardIterator>::type;

  System1 system1;
  System2 system2;

  return thrust::uninitialized_copy_n(select_system(system1, system2), first, n, result);
} // end uninitialized_copy_n()

THRUST_NAMESPACE_END
