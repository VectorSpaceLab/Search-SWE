// SPDX-FileCopyrightText: Copyright (c) 2008-2013, NVIDIA Corporation. All rights reserved.
// SPDX-License-Identifier: Apache-2.0

#pragma once

#include <thrust/detail/config.h>

#if defined(_CCCL_IMPLICIT_SYSTEM_HEADER_GCC)
#  pragma GCC system_header
#elif defined(_CCCL_IMPLICIT_SYSTEM_HEADER_CLANG)
#  pragma clang system_header
#elif defined(_CCCL_IMPLICIT_SYSTEM_HEADER_MSVC)
#  pragma system_header
#endif // no system header

#include <thrust/detail/type_traits/has_member_function.h>

#include <cuda/std/__type_traits/copy_cv.h>
#include <cuda/std/__type_traits/integral_constant.h>

// inspired by Roman Perepelitsa's presentation from comp.lang.c++.moderated
// based on the implementation here: http://www.rsdn.ru/forum/cpp/2759773.1.aspx

THRUST_NAMESPACE_BEGIN
namespace detail::is_call_possible_detail
{
template <typename T>
class void_exp_result
{};

template <typename T, typename U>
U const& operator,(U const&, void_exp_result<T>);

template <typename T, typename U>
U& operator,(U&, void_exp_result<T>);
} // namespace detail::is_call_possible_detail
THRUST_NAMESPACE_END

#define __THRUST_DEFINE_IS_CALL_POSSIBLE(trait_name, member_function_name)                                             \
  __THRUST_DEFINE_HAS_MEMBER_FUNCTION(trait_name##_has_member, member_function_name)                                   \
                                                                                                                       \
  template <typename T, typename Signature>                                                                            \
  struct trait_name                                                                                                    \
  {                                                                                                                    \
  private:                                                                                                             \
    struct yes                                                                                                         \
    {};                                                                                                                \
    struct no                                                                                                          \
    {                                                                                                                  \
      yes m[2];                                                                                                        \
    };                                                                                                                 \
    struct derived : public T                                                                                          \
    {                                                                                                                  \
      using T::member_function_name;                                                                                   \
      no member_function_name(...) const;                                                                              \
    };                                                                                                                 \
                                                                                                                       \
    using derived_type = ::cuda::std::__copy_cv_t<T, derived>;                                                         \
                                                                                                                       \
    template <typename U, typename Result>                                                                             \
    struct return_value_check                                                                                          \
    {                                                                                                                  \
      static yes deduce(Result);                                                                                       \
      static no deduce(...);                                                                                           \
      static no deduce(no);                                                                                            \
      static no deduce(thrust::detail::is_call_possible_detail::void_exp_result<T>);                                   \
    };                                                                                                                 \
                                                                                                                       \
    template <typename U>                                                                                              \
    struct return_value_check<U, void>                                                                                 \
    {                                                                                                                  \
      static yes deduce(...);                                                                                          \
      static no deduce(no);                                                                                            \
    };                                                                                                                 \
                                                                                                                       \
    template <bool HasTheMemberOfInterest, typename F>                                                                 \
    struct impl                                                                                                        \
    {                                                                                                                  \
      static const bool value = false;                                                                                 \
    };                                                                                                                 \
                                                                                                                       \
    template <typename Result, typename Arg>                                                                           \
    struct impl<true, Result(Arg)>                                                                                     \
    {                                                                                                                  \
      static ::cuda::std::add_lvalue_reference_t<derived_type> test_me;                                                \
      static ::cuda::std::add_lvalue_reference_t<Arg> arg;                                                             \
                                                                                                                       \
      static const bool value =                                                                                        \
        sizeof(return_value_check<T, Result>::deduce(                                                                  \
          (test_me.member_function_name(arg), thrust::detail::is_call_possible_detail::void_exp_result<T>())))         \
        == sizeof(yes);                                                                                                \
    };                                                                                                                 \
                                                                                                                       \
    template <typename Result, typename Arg1, typename Arg2>                                                           \
    struct impl<true, Result(Arg1, Arg2)>                                                                              \
    {                                                                                                                  \
      static ::cuda::std::add_lvalue_reference_t<derived_type> test_me;                                                \
      static ::cuda::std::add_lvalue_reference_t<Arg1> arg1;                                                           \
      static ::cuda::std::add_lvalue_reference_t<Arg2> arg2;                                                           \
                                                                                                                       \
      static const bool value =                                                                                        \
        sizeof(return_value_check<T, Result>::deduce(                                                                  \
          (test_me.member_function_name(arg1, arg2), thrust::detail::is_call_possible_detail::void_exp_result<T>())))  \
        == sizeof(yes);                                                                                                \
    };                                                                                                                 \
                                                                                                                       \
    template <typename Result, typename Arg1, typename Arg2, typename Arg3>                                            \
    struct impl<true, Result(Arg1, Arg2, Arg3)>                                                                        \
    {                                                                                                                  \
      static ::cuda::std::add_lvalue_reference_t<derived_type> test_me;                                                \
      static ::cuda::std::add_lvalue_reference_t<Arg1> arg1;                                                           \
      static ::cuda::std::add_lvalue_reference_t<Arg2> arg2;                                                           \
      static ::cuda::std::add_lvalue_reference_t<Arg3> arg3;                                                           \
                                                                                                                       \
      static const bool value =                                                                                        \
        sizeof(return_value_check<T, Result>::deduce((test_me.member_function_name(arg1, arg2, arg3),                  \
                                                      thrust::detail::is_call_possible_detail::void_exp_result<T>()))) \
        == sizeof(yes);                                                                                                \
    };                                                                                                                 \
                                                                                                                       \
    template <typename Result, typename Arg1, typename Arg2, typename Arg3, typename Arg4>                             \
    struct impl<true, Result(Arg1, Arg2, Arg3, Arg4)>                                                                  \
    {                                                                                                                  \
      static ::cuda::std::add_lvalue_reference_t<derived_type> test_me;                                                \
      static ::cuda::std::add_lvalue_reference_t<Arg1> arg1;                                                           \
      static ::cuda::std::add_lvalue_reference_t<Arg2> arg2;                                                           \
      static ::cuda::std::add_lvalue_reference_t<Arg3> arg3;                                                           \
      static ::cuda::std::add_lvalue_reference_t<Arg4> arg4;                                                           \
                                                                                                                       \
      static const bool value =                                                                                        \
        sizeof(return_value_check<T, Result>::deduce((test_me.member_function_name(arg1, arg2, arg3, arg4),            \
                                                      thrust::detail::is_call_possible_detail::void_exp_result<T>()))) \
        == sizeof(yes);                                                                                                \
    };                                                                                                                 \
                                                                                                                       \
  public:                                                                                                              \
    static const bool value = impl<trait_name##_has_member<T, Signature>::value, Signature>::value;                    \
    using type              = ::cuda::std::bool_constant<value>;                                                       \
  };
