// SPDX-FileCopyrightText: Copyright (c) 2008-2013, NVIDIA Corporation
// SPDX-FileCopyrightText: Copyright (c) 2013, Filipe RNC Maia
// SPDX-License-Identifier: Apache-2.0

/*-
 * Copyright (c) 2011 David Schultz
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice unmodified, this list of conditions, and the following
 *    disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 * OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 * NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 * THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 * Adapted from FreeBSD by Filipe Maia <filipe.c.maia@gmail.com>:
 *    freebsd/lib/msun/src/s_ctanh.c
 */

/*
 * Hyperbolic tangent of a complex argument z = x + i y.
 *
 * The algorithm is from:
 *
 *   W. Kahan.  Branch Cuts for Complex Elementary Functions or Much
 *   Ado About Nothing's Sign Bit.  In The State of the Art in
 *   Numerical Analysis, pp. 165 ff.  Iserles and Powell, eds., 1987.
 *
 * Method:
 *
 *   Let t    = tan(x)
 *       beta = 1/cos^2(y)
 *       s    = sinh(x)
 *       rho  = cosh(x)
 *
 *   We have:
 *
 *   tanh(z) = sinh(z) / cosh(z)
 *
 *             sinh(x) cos(y) + i cosh(x) sin(y)
 *           = ---------------------------------
 *             cosh(x) cos(y) + i sinh(x) sin(y)
 *
 *             cosh(x) sinh(x) / cos^2(y) + i tan(y)
 *           = -------------------------------------
 *                    1 + sinh^2(x) / cos^2(y)
 *
 *             beta rho s + i t
 *           = ----------------
 *               1 + beta s^2
 *
 * Modifications:
 *
 *   I omitted the original algorithm's handling of overflow in tan(x) after
 *   verifying with nearpi.c that this can't happen in IEEE single or double
 *   precision.  I also handle large x differently.
 */

#pragma once

#include <thrust/detail/config.h>

#include <thrust/complex.h>
#include <thrust/detail/complex/math_private.h>

#include <cuda/std/__cmath/abs.h>
#include <cuda/std/__cmath/copysign.h>
#include <cuda/std/__cmath/exponential_functions.h>
#include <cuda/std/__cmath/hyperbolic_functions.h>
#include <cuda/std/__cmath/inverse_trigonometric_functions.h>
#include <cuda/std/__cmath/isfinite.h>
#include <cuda/std/__cmath/isinf.h>
#include <cuda/std/__cmath/roots.h>
#include <cuda/std/__cmath/trigonometric_functions.h>

THRUST_NAMESPACE_BEGIN
namespace detail::complex
{
using thrust::complex;

// `y - y` is a deliberate IEEE-754 idiom, not a redundant expression: it yields +0.0 for a
// finite y and propagates a NaN or raises invalid for an infinite y. C99 Annex G specifies
// the complex functions in these terms.
// NOLINTBEGIN(misc-redundant-expression)
_CCCL_HOST_DEVICE inline complex<double> ctanh(const complex<double>& z)
{
  double x, y;
  double t, beta, s, rho, denom;
  uint32_t hx, ix, lx;

  x = z.real();
  y = z.imag();

  extract_words(hx, lx, x);
  ix = hx & 0x7fffffff;

  /*
   * ctanh(NaN + i 0) = NaN + i 0
   *
   * ctanh(NaN + i y) = NaN + i NaN		for y != 0
   *
   * The imaginary part has the sign of x*sin(2*y), but there's no
   * special effort to get this right.
   *
   * ctanh(+-Inf +- i Inf) = +-1 +- 0
   *
   * ctanh(+-Inf + i y) = +-1 + 0 sin(2y)		for y finite
   *
   * The imaginary part of the sign is unspecified.  This special
   * case is only needed to avoid a spurious invalid exception when
   * y is infinite.
   */
  if (ix >= 0x7ff00000)
  {
    if ((ix & 0xfffff) | lx) /* x is NaN */
    {
      return (complex<double>(x, (y == 0 ? y : x * y)));
    }
    set_high_word(x, hx - 0x40000000); /* x = copysign(1, x) */
    return (complex<double>(
      x, ::cuda::std::copysign(0.0, ::cuda::std::isinf(y) ? y : ::cuda::std::sin(y) * ::cuda::std::cos(y))));
  }

  /*
   * ctanh(x + i NAN) = NaN + i NaN
   * ctanh(x +- i Inf) = NaN + i NaN
   */
  if (!::cuda::std::isfinite(y))
  {
    return (complex<double>(y - y, y - y));
  }

  /*
   * ctanh(+-huge + i +-y) ~= +-1 +- i 2sin(2y)/exp(2x), using the
   * approximation sinh^2(huge) ~= exp(2*huge) / 4.
   * We use a modified formula to avoid spurious overflow.
   */
  if (ix >= 0x40360000)
  { /* x >= 22 */
    const double exp_mx = ::cuda::std::exp(-fabs(x));
    return (complex<double>(::cuda::std::copysign(1.0, x),
                            4.0 * ::cuda::std::sin(y) * ::cuda::std::cos(y) * exp_mx * exp_mx));
  }

  /* Kahan's algorithm */
  t     = ::cuda::std::tan(y);
  beta  = 1.0 + t * t; /* = 1 / cos^2(y) */
  s     = ::cuda::std::sinh(x);
  rho   = ::cuda::std::sqrt(1.0 + s * s); /* = cosh(x) */
  denom = 1.0 + beta * s * s;
  return (complex<double>((beta * rho * s) / denom, t / denom));
}
// NOLINTEND(misc-redundant-expression)

_CCCL_HOST_DEVICE inline complex<double> ctan(complex<double> z)
{
  /* ctan(z) = -I * ctanh(I * z) */
  z = ctanh(complex<double>(-z.imag(), z.real()));
  return (complex<double>(z.imag(), -z.real()));
}
} // namespace detail::complex

template <typename ValueType>
_CCCL_HOST_DEVICE inline complex<ValueType> tan(const complex<ValueType>& z)
{
  return sin(z) / cos(z);
}

template <typename ValueType>
_CCCL_HOST_DEVICE inline complex<ValueType> tanh(const complex<ValueType>& z)
{
  // This implementation seems better than the simple sin/cos
  return (thrust::exp(ValueType(2) * z) - ValueType(1)) / (thrust::exp(ValueType(2) * z) + ValueType(1));
}

template <>
_CCCL_HOST_DEVICE inline complex<double> tan(const complex<double>& z)
{
  return detail::complex::ctan(z);
}

template <>
_CCCL_HOST_DEVICE inline complex<double> tanh(const complex<double>& z)
{
  return detail::complex::ctanh(z);
}

THRUST_NAMESPACE_END
