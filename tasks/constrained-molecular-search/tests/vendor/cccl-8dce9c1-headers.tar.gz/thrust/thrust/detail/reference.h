// SPDX-FileCopyrightText: Copyright (c) 2008-2013, NVIDIA Corporation. All rights reserved.
// SPDX-License-Identifier: Apache-2.0

/*! \file
 *  \brief A pointer to a variable which resides in memory associated with a
 *  system.
 */

#pragma once

#include <thrust/detail/config.h>

#if defined(_CCCL_IMPLICIT_SYSTEM_HEADER_GCC)
#  pragma GCC system_header
#elif defined(_CCCL_IMPLICIT_SYSTEM_HEADER_CLANG)
#  pragma clang system_header
#elif defined(_CCCL_IMPLICIT_SYSTEM_HEADER_MSVC)
#  pragma system_header
#endif // no system header
#include <thrust/detail/reference_forward_declaration.h>
#include <thrust/iterator/iterator_traits.h>
#include <thrust/system/detail/generic/memory.h>
#include <thrust/system/detail/generic/select_system.h>

#include <cuda/std/__host_stdlib/ostream>
#include <cuda/std/__type_traits/enable_if.h>
#include <cuda/std/__type_traits/is_comparable.h>
#include <cuda/std/__type_traits/is_convertible.h>
#include <cuda/std/__type_traits/remove_cvref.h>
#include <cuda/std/__utility/move.h>

// Include all active backend system implementations (sequential, host and device) (there is no generic implementation)
#include <thrust/system/detail/sequential/assign_value.h>
#include <thrust/system/detail/sequential/get_value.h>
#include <thrust/system/detail/sequential/iter_swap.h>
#include __THRUST_HOST_SYSTEM_ALGORITH_DETAIL_HEADER_INCLUDE(assign_value.h)
#include __THRUST_HOST_SYSTEM_ALGORITH_DETAIL_HEADER_INCLUDE(get_value.h)
#include __THRUST_HOST_SYSTEM_ALGORITH_DETAIL_HEADER_INCLUDE(iter_swap.h)
#include __THRUST_DEVICE_SYSTEM_ALGORITH_DETAIL_HEADER_INCLUDE(assign_value.h)
#include __THRUST_DEVICE_SYSTEM_ALGORITH_DETAIL_HEADER_INCLUDE(get_value.h)
#include __THRUST_DEVICE_SYSTEM_ALGORITH_DETAIL_HEADER_INCLUDE(iter_swap.h)

// Some build systems need a hint to know which files we could include
#if 0
#  include <thrust/system/cpp/detail/assign_value.h>
#  include <thrust/system/cpp/detail/get_value.h>
#  include <thrust/system/cpp/detail/iter_swap.h>
#  include <thrust/system/cuda/detail/assign_value.h>
#  include <thrust/system/cuda/detail/get_value.h>
#  include <thrust/system/cuda/detail/iter_swap.h>
#  include <thrust/system/omp/detail/assign_value.h>
#  include <thrust/system/omp/detail/get_value.h>
#  include <thrust/system/omp/detail/iter_swap.h>
#  include <thrust/system/tbb/detail/assign_value.h>
#  include <thrust/system/tbb/detail/get_value.h>
#  include <thrust/system/tbb/detail/iter_swap.h>
#endif

THRUST_NAMESPACE_BEGIN

namespace detail
{
template <typename>
struct is_wrapped_reference;
}

/*! \p reference acts as a reference-like wrapper for an object residing in
 *  memory that a \p pointer refers to.
 */
template <typename Element, typename Pointer, typename Derived>
class reference
{
private:
  using derived_type = std::conditional_t<std::is_same_v<Derived, use_default>, reference, Derived>;

public:
  using pointer    = Pointer;
  using value_type = ::cuda::std::remove_cvref_t<Element>;

  reference(reference const&) = default;

  reference(reference&&) = default;

  /*! Construct a \p reference from another \p reference whose pointer type is
   *  convertible to \p pointer. After this \p reference is constructed, it
   *  shall refer to the same object as \p other.
   *
   *  \tparam OtherElement The element type of the other \p reference.
   *  \tparam OtherPointer The pointer type of the other \p reference.
   *  \tparam OtherDerived The derived type of the other \p reference.
   *  \param  other        A \p reference to copy from.
   */
  template <typename OtherElement, typename OtherPointer, typename OtherDerived>
  _CCCL_HOST_DEVICE reference(
    reference<OtherElement, OtherPointer, OtherDerived> const& other
    /*! \cond
     */
    ,
    std::enable_if_t<
      std::is_convertible_v<typename reference<OtherElement, OtherPointer, OtherDerived>::pointer, pointer>>* = nullptr
    /*! \endcond
     */
    )
      : ptr(other.ptr)
  {}

  /*! Construct a \p reference that refers to an object pointed to by the given
   *  \p pointer. After this \p reference is constructed, it shall refer to the
   *  object pointed to by \p ptr.
   *
   *  \param ptr A \p pointer to construct from.
   */
  _CCCL_HOST_DEVICE explicit reference(pointer const& p)
      : ptr(p)
  {}

  /*! Assign the object referred to \p other to the object referred to by
   *  this \p reference.
   *
   *  \param other The other \p reference to assign from.
   *
   *  \return <tt>*this</tt>.
   */
  // A reference refers to an object elsewhere, so assigning through a const reference
  // writes the referent and not the proxy. This mirrors std::vector<bool>::reference and is
  // what `*it = x` needs for output iterators. derived_type& is the CRTP derived type, so
  // returning reference& instead would slice.
  // NOLINTNEXTLINE(misc-unconventional-assign-operator)
  _CCCL_HOST_DEVICE const derived_type& operator=(reference const& other) const
  {
    assign_from(&other);
    return derived();
  }

  /*! Assign the object referred to by this \p reference with the object
   *  referred to by another \p reference whose pointer type is convertible to
   *  \p pointer.
   *
   *  \tparam OtherElement The element type of the other \p reference.
   *  \tparam OtherPointer The pointer type of the other \p reference.
   *  \tparam OtherDerived The derived type of the other \p reference.
   *  \param  other        The other \p reference to assign from.
   *
   *  \return <tt>*this</tt>.
   */
  // NOLINTBEGIN(misc-unconventional-assign-operator): proxy reference, see above
  template <
    typename OtherElement,
    typename OtherPointer,
    typename OtherDerived,
    ::cuda::std::enable_if_t<
      ::cuda::std::is_convertible_v<typename reference<OtherElement, OtherPointer, OtherDerived>::pointer, pointer>,
      int> = 0>
  _CCCL_HOST_DEVICE const derived_type& operator=(reference<OtherElement, OtherPointer, OtherDerived> const& other) const
  {
    assign_from(&other);
    return derived();
  }
  // NOLINTEND(misc-unconventional-assign-operator)

  /*! Assign \p rhs to the object referred to by this \p tagged_reference.
   *
   *  \param rhs The \p value_type to assign from.
   *
   *  \return <tt>*this</tt>.
   */
  // NOLINTNEXTLINE(misc-unconventional-assign-operator): proxy reference, see above
  _CCCL_HOST_DEVICE const derived_type& operator=(value_type const& rhs) const
  {
    assign_from(&rhs);
    return derived();
  }

  /*! Exchanges the value of the object referred to by this \p tagged_reference
   *  with the object referred to by \p other.
   *
   *  \param other The \p tagged_reference to swap with.
   */
  _CCCL_HOST_DEVICE void swap(derived_type other)
  {
    // we cannot construct a system solely from its type, since it may be stateful, so just use the system's tag
    typename iterator_system_t<pointer>::tag_type tag;
    swap(&tag, other);
  }

  _CCCL_HOST_DEVICE pointer operator&() const
  {
    return ptr;
  }

  // This is inherently hazardous, as it discards the strong type information
  // about what system the object is on.
  _CCCL_HOST_DEVICE operator value_type() const
  {
    // we cannot construct a system solely from its type, since it may be stateful, so just use the system's tag
    typename iterator_system_t<pointer>::tag_type tag;
    return convert_to_value_type(&tag);
  }

  _CCCL_HOST_DEVICE derived_type& operator++()
  {
    // Sadly, this has to make a copy. The only mechanism we have for
    // modifying the value, which may be in memory inaccessible to this
    // system, is to get a copy of it, modify the copy, and then update it.
    value_type tmp = *this;
    ++tmp;
    *this = tmp;
    return derived();
  }

  _CCCL_HOST_DEVICE value_type operator++(int)
  {
    value_type tmp          = *this;
    const value_type result = tmp++;
    *this                   = ::cuda::std::move(tmp);
    return result;
  }

  derived_type& operator--()
  {
    // Sadly, this has to make a copy. The only mechanism we have for
    // modifying the value, which may be in memory inaccessible to this
    // system, is to get a copy of it, modify the copy, and then update it.
    value_type tmp = *this;
    --tmp;
    *this = ::cuda::std::move(tmp);
    return derived();
  }

  value_type operator--(int)
  {
    value_type tmp    = *this;
    value_type result = tmp--;
    *this             = ::cuda::std::move(tmp);
    return derived();
  }

  _CCCL_HOST_DEVICE derived_type& operator+=(value_type const& rhs)
  {
    value_type tmp = *this;
    tmp += rhs;
    *this = tmp;
    return derived();
  }

  derived_type& operator-=(value_type const& rhs)
  {
    value_type tmp = *this;
    tmp -= rhs;
    *this = tmp;
    return derived();
  }

  derived_type& operator*=(value_type const& rhs)
  {
    value_type tmp = *this;
    tmp *= rhs;
    *this = tmp;
    return derived();
  }

  derived_type& operator/=(value_type const& rhs)
  {
    value_type tmp = *this;
    tmp /= rhs;
    *this = tmp;
    return derived();
  }

  derived_type& operator%=(value_type const& rhs)
  {
    value_type tmp = *this;
    tmp %= rhs;
    *this = tmp;
    return derived();
  }

  derived_type& operator<<=(value_type const& rhs)
  {
    value_type tmp = *this;
    tmp <<= rhs;
    *this = tmp;
    return derived();
  }

  derived_type& operator>>=(value_type const& rhs)
  {
    value_type tmp = *this;
    tmp >>= rhs;
    *this = tmp;
    return derived();
  }

  derived_type& operator&=(value_type const& rhs)
  {
    value_type tmp = *this;
    tmp &= rhs;
    *this = tmp;
    return derived();
  }

  derived_type& operator|=(value_type const& rhs)
  {
    value_type tmp = *this;
    tmp |= rhs;
    *this = tmp;
    return derived();
  }

  derived_type& operator^=(value_type const& rhs)
  {
    value_type tmp = *this;
    tmp ^= rhs;
    *this = tmp;
    return derived();
  }

  template <typename OtherElement, typename OtherPointer, typename OtherDerived>
  [[nodiscard]]
  _CCCL_HOST_DEVICE friend ::cuda::std::enable_if_t<detail::ref_can_compare_equal<Pointer, OtherPointer>, bool>
  operator==(reference const& lhs, reference<OtherElement, OtherPointer, OtherDerived> const& rhs) noexcept(
    ::cuda::std::__is_cpp17_nothrow_equality_comparable_v<value_type, ::cuda::std::remove_cvref_t<OtherElement>>)
  { // MSVC cannot directly compare the references thinking its a recursive function call
    const value_type& lhs_ref                                = *&lhs;
    const ::cuda::std::remove_cvref_t<OtherElement>& rhs_ref = *&rhs;
    return lhs_ref == rhs_ref;
  }

  template <typename OtherElement, typename OtherPointer, typename OtherDerived>
  [[nodiscard]]
  _CCCL_HOST_DEVICE friend ::cuda::std::enable_if_t<!detail::ref_can_compare_equal<Pointer, OtherPointer>, bool>
  operator==(reference const& lhs, reference<OtherElement, OtherPointer, OtherDerived> const& rhs) = delete;

  template <typename OtherElement, typename OtherPointer, typename OtherDerived>
  [[nodiscard]]
  _CCCL_HOST_DEVICE friend ::cuda::std::enable_if_t<detail::ref_can_compare_equal<Pointer, OtherPointer>, bool>
  operator!=(reference const& lhs, reference<OtherElement, OtherPointer, OtherDerived> const& rhs) noexcept(
    ::cuda::std::__is_cpp17_nothrow_equality_comparable_v<value_type, ::cuda::std::remove_cvref_t<OtherElement>>)
  {
    const value_type& lhs_ref                                = *&lhs;
    const ::cuda::std::remove_cvref_t<OtherElement>& rhs_ref = *&rhs;
    return !(lhs_ref == rhs_ref);
  }

  template <typename OtherElement, typename OtherPointer, typename OtherDerived>
  [[nodiscard]]
  _CCCL_HOST_DEVICE friend ::cuda::std::enable_if_t<!detail::ref_can_compare_equal<Pointer, OtherPointer>, bool>
  operator!=(reference const& lhs, reference<OtherElement, OtherPointer, OtherDerived> const& rhs) = delete;

  template <typename OtherElement, typename OtherPointer, typename OtherDerived>
  [[nodiscard]]
  _CCCL_HOST_DEVICE friend ::cuda::std::enable_if_t<detail::ref_can_compare_less_than<Pointer, OtherPointer>, bool>
  operator<(reference const& lhs, reference<OtherElement, OtherPointer, OtherDerived> const& rhs) noexcept(
    ::cuda::std::__is_cpp17_nothrow_less_than_comparable_v<value_type, ::cuda::std::remove_cvref_t<OtherElement>>)
  { // MSVC cannot directly compare the references thinking its a recursive function call
    const value_type& lhs_ref                                = *&lhs;
    const ::cuda::std::remove_cvref_t<OtherElement>& rhs_ref = *&rhs;
    return lhs_ref < rhs_ref;
  }

  template <typename OtherElement, typename OtherPointer, typename OtherDerived>
  [[nodiscard]]
  _CCCL_HOST_DEVICE friend ::cuda::std::enable_if_t<!detail::ref_can_compare_less_than<Pointer, OtherPointer>, bool>
  operator<(reference const& lhs, reference<OtherElement, OtherPointer, OtherDerived> const& rhs) = delete;

  template <typename OtherElement, typename OtherPointer, typename OtherDerived>
  [[nodiscard]]
  _CCCL_HOST_DEVICE friend ::cuda::std::enable_if_t<detail::ref_can_compare_less_than<Pointer, OtherPointer>, bool>
  operator>=(reference const& lhs, reference<OtherElement, OtherPointer, OtherDerived> const& rhs) noexcept(
    ::cuda::std::__is_cpp17_nothrow_less_than_comparable_v<value_type, ::cuda::std::remove_cvref_t<OtherElement>>)
  { // MSVC cannot directly compare the references thinking its a recursive function call
    const value_type& lhs_ref                                = *&lhs;
    const ::cuda::std::remove_cvref_t<OtherElement>& rhs_ref = *&rhs;
    return !(lhs_ref < rhs_ref);
  }

  template <typename OtherElement, typename OtherPointer, typename OtherDerived>
  [[nodiscard]]
  _CCCL_HOST_DEVICE friend ::cuda::std::enable_if_t<!detail::ref_can_compare_less_than<Pointer, OtherPointer>, bool>
  operator>=(reference const& lhs, reference<OtherElement, OtherPointer, OtherDerived> const& rhs) = delete;

  template <typename OtherElement, typename OtherPointer, typename OtherDerived>
  [[nodiscard]]
  _CCCL_HOST_DEVICE friend ::cuda::std::enable_if_t<detail::ref_can_compare_less_than<Pointer, OtherPointer>, bool>
  operator>(reference const& lhs, reference<OtherElement, OtherPointer, OtherDerived> const& rhs) noexcept(
    ::cuda::std::__is_cpp17_nothrow_less_than_comparable_v<value_type, ::cuda::std::remove_cvref_t<OtherElement>>)
  { // MSVC cannot directly compare the references thinking its a recursive function call
    const value_type& lhs_ref                                = *&lhs;
    const ::cuda::std::remove_cvref_t<OtherElement>& rhs_ref = *&rhs;
    return rhs_ref < lhs_ref;
  }

  template <typename OtherElement, typename OtherPointer, typename OtherDerived>
  [[nodiscard]]
  _CCCL_HOST_DEVICE friend ::cuda::std::enable_if_t<!detail::ref_can_compare_less_than<Pointer, OtherPointer>, bool>
  operator>(reference const& lhs, reference<OtherElement, OtherPointer, OtherDerived> const& rhs) = delete;

  template <typename OtherElement, typename OtherPointer, typename OtherDerived>
  [[nodiscard]]
  _CCCL_HOST_DEVICE friend ::cuda::std::enable_if_t<detail::ref_can_compare_less_than<Pointer, OtherPointer>, bool>
  operator<=(reference const& lhs, reference<OtherElement, OtherPointer, OtherDerived> const& rhs) noexcept(
    ::cuda::std::__is_cpp17_nothrow_less_than_comparable_v<value_type, ::cuda::std::remove_cvref_t<OtherElement>>)
  { // MSVC cannot directly compare the references thinking its a recursive function call
    const value_type& lhs_ref                                = *&lhs;
    const ::cuda::std::remove_cvref_t<OtherElement>& rhs_ref = *&rhs;
    return !(rhs_ref < lhs_ref);
  }

  template <typename OtherElement, typename OtherPointer, typename OtherDerived>
  [[nodiscard]]
  _CCCL_HOST_DEVICE friend ::cuda::std::enable_if_t<!detail::ref_can_compare_less_than<Pointer, OtherPointer>, bool>
  operator<=(reference const& lhs, reference<OtherElement, OtherPointer, OtherDerived> const& rhs) = delete;

private:
  pointer const ptr;

  // `thrust::detail::is_wrapped_reference` is a trait that indicates whether
  // a type is a fancy reference. It detects such types by looking for a
  // nested `wrapped_reference_hint` type.
  struct wrapped_reference_hint
  {};
  template <typename>
  friend struct thrust::detail::is_wrapped_reference;

  template <typename OtherElement, typename OtherPointer, typename OtherDerived>
  friend class reference;

  _CCCL_HOST_DEVICE derived_type& derived()
  {
    return static_cast<derived_type&>(*this);
  }

  _CCCL_HOST_DEVICE const derived_type& derived() const
  {
    return static_cast<const derived_type&>(*this);
  }

  template <typename System>
  _CCCL_HOST_DEVICE value_type convert_to_value_type(System* system) const
  {
    using thrust::system::detail::generic::select_system;
    return strip_const_get_value(select_system(*system));
  }

  template <typename System>
  _CCCL_HOST_DEVICE value_type strip_const_get_value(System const& system) const
  {
    // NOLINTNEXTLINE(cppcoreguidelines-pro-type-const-cast)
    System& non_const_system = const_cast<System&>(system);

    using thrust::system::detail::generic::get_value;
    return get_value(thrust::detail::derived_cast(non_const_system), ptr);
  }

  template <typename System0, typename System1, typename OtherPointer>
  _CCCL_HOST_DEVICE void assign_from(System0* system0, System1* system1, OtherPointer src) const
  {
    using thrust::system::detail::generic::select_system;
    strip_const_assign_value(select_system(*system0, *system1), src);
  }

  template <typename OtherPointer>
  _CCCL_HOST_DEVICE void assign_from(OtherPointer src) const
  {
    // we cannot construct a system solely from its type, since it may be stateful, so just use the system's tag
    typename iterator_system_t<pointer>::tag_type tag0;
    typename iterator_system_t<OtherPointer>::tag_type tag1;
    assign_from(&tag0, &tag1, src);
  }

  template <typename System, typename OtherPointer>
  _CCCL_HOST_DEVICE void strip_const_assign_value(System const& system, OtherPointer src) const
  {
    // NOLINTNEXTLINE(cppcoreguidelines-pro-type-const-cast)
    System& non_const_system = const_cast<System&>(system);

    using thrust::system::detail::generic::assign_value;
    assign_value(thrust::detail::derived_cast(non_const_system), ptr, src);
  }

  template <typename System>
  _CCCL_HOST_DEVICE void swap(System* system, derived_type other)
  {
    using thrust::system::detail::generic::iter_swap;
    using thrust::system::detail::generic::select_system;

    iter_swap(select_system(*system, *system), ptr, other.ptr);
  }
};

template <typename Pointer, typename Derived>
class reference<void, Pointer, Derived>
{};

template <typename Pointer, typename Derived>
class reference<void const, Pointer, Derived>
{};

template <typename Element, typename Pointer, typename Derived, typename CharT, typename Traits>
std::basic_ostream<CharT, Traits>&
operator<<(std::basic_ostream<CharT, Traits>& os, reference<Element, Pointer, Derived> const& r)
{
  using value_type = typename reference<Element, Pointer, Derived>::value_type;
  return os << static_cast<value_type>(r); // NOLINT(bugprone-unintended-char-ostream-output)
}

template <typename Element, typename Tag>
class tagged_reference;

/*! \p tagged_reference acts as a reference-like wrapper for an object residing
 *  in memory associated with system \p Tag that a \p pointer refers to.
 */
template <typename Element, typename Tag>
class tagged_reference
    : public thrust::
        reference<Element, thrust::pointer<Element, Tag, tagged_reference<Element, Tag>>, tagged_reference<Element, Tag>>
{
private:
  using base_type = thrust::
    reference<Element, thrust::pointer<Element, Tag, tagged_reference<Element, Tag>>, tagged_reference<Element, Tag>>;

public:
  using value_type = typename base_type::value_type;
  using pointer    = typename base_type::pointer;

  tagged_reference(tagged_reference const&) = default;

  tagged_reference(tagged_reference&&) = default;

  /*! Construct a \p tagged_reference from another \p tagged_reference whose
   *  pointer type is convertible to \p pointer. After this \p tagged_reference
   *  is constructed, it shall refer to the same object as \p other.
   *
   *  \tparam OtherElement The element type of the other \p tagged_reference.
   *  \tparam OtherTag     The tag type of the other \p tagged_reference.
   *  \param  other        A \p tagged_reference to copy from.
   */
  template <typename OtherElement, typename OtherTag>
  _CCCL_HOST_DEVICE tagged_reference(tagged_reference<OtherElement, OtherTag> const& other)
      : base_type(other)
  {}

  /*! Construct a \p tagged_reference that refers to an object pointed to by
   *  the given \p pointer. After this \p tagged_reference is constructed, it
   *  shall refer to the object pointed to by \p ptr.
   *
   *  \param ptr A \p pointer to construct from.
   */
  _CCCL_HOST_DEVICE explicit tagged_reference(pointer const& p)
      : base_type(p)
  {}

  /*! Assign the object referred to \p other to the object referred to by
   *  this \p tagged_reference.
   *
   *  \param other The other \p tagged_reference to assign from.
   *
   *  \return <tt>*this</tt>.
   */
  // A tagged_reference refers to an object elsewhere, so assigning through a const
  // reference writes the referent and not the proxy. This mirrors
  // std::vector<bool>::reference and is what `*it = x` needs for output iterators.
  // NOLINTNEXTLINE(misc-unconventional-assign-operator)
  _CCCL_HOST_DEVICE const tagged_reference& operator=(tagged_reference const& other) const
  {
    return base_type::operator=(other);
  }

  /*! Assign the object referred to by this \p tagged_reference with the object
   *  referred to by another \p tagged_reference whose pointer type is
   *  convertible to \p pointer.
   *
   *  \tparam OtherElement The element type of the other \p tagged_reference.
   *  \tparam OtherTag     The tag type of the other \p tagged_reference.
   *  \param  other        The other \p tagged_reference to assign from.
   *
   *  \return <tt>*this</tt>.
   */
  // NOLINTBEGIN(misc-unconventional-assign-operator): proxy reference, see above
  template <typename OtherElement, typename OtherTag>
  _CCCL_HOST_DEVICE const tagged_reference& operator=(tagged_reference<OtherElement, OtherTag> const& other) const
  {
    return base_type::operator=(other);
  }
  // NOLINTEND(misc-unconventional-assign-operator)

  /*! Assign \p rhs to the object referred to by this \p tagged_reference.
   *
   *  \param rhs The \p value_type to assign from.
   *
   *  \return <tt>*this</tt>.
   */
  // NOLINTNEXTLINE(misc-unconventional-assign-operator): proxy reference, see above
  _CCCL_HOST_DEVICE const tagged_reference& operator=(value_type const& rhs) const
  {
    return base_type::operator=(rhs);
  }
};

template <typename Tag>
class tagged_reference<void, Tag>
{};

template <typename Tag>
class tagged_reference<void const, Tag>
{};

/*! Exchanges the values of two objects referred to by \p tagged_reference.
 *
 *  \param x The first \p tagged_reference of interest.
 *  \param y The second \p tagged_reference of interest.
 */
// note: this is not a hidden friend, because we have template specializations of tagged_reference
template <typename Element, typename Tag>
_CCCL_HOST_DEVICE void
swap(tagged_reference<Element, Tag> x, tagged_reference<Element, Tag> y) noexcept(noexcept(x.swap(y)))
{
  x.swap(y);
}

THRUST_NAMESPACE_END
