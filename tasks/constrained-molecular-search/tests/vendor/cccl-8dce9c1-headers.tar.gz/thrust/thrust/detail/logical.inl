// SPDX-FileCopyrightText: Copyright (c) 2008-2013, NVIDIA Corporation. All rights reserved.
// SPDX-License-Identifier: Apache-2.0

#pragma once

#include <thrust/detail/config.h>

#if defined(_CCCL_IMPLICIT_SYSTEM_HEADER_GCC)
#  pragma GCC system_header
#elif defined(_CCCL_IMPLICIT_SYSTEM_HEADER_CLANG)
#  pragma clang system_header
#elif defined(_CCCL_IMPLICIT_SYSTEM_HEADER_MSVC)
#  pragma system_header
#endif // no system header
#include <thrust/iterator/iterator_traits.h>
#include <thrust/system/detail/generic/select_system.h>

// Include all active backend system implementations (generic, sequential, host and device)
#include <thrust/system/detail/generic/logical.h>
#include <thrust/system/detail/sequential/logical.h>
#include __THRUST_HOST_SYSTEM_ALGORITH_DETAIL_HEADER_INCLUDE(logical.h)
#include __THRUST_DEVICE_SYSTEM_ALGORITH_DETAIL_HEADER_INCLUDE(logical.h)

// Some build systems need a hint to know which files we could include
#if 0
#  include <thrust/system/cpp/detail/logical.h>
#  include <thrust/system/cuda/detail/logical.h>
#  include <thrust/system/omp/detail/logical.h>
#  include <thrust/system/tbb/detail/logical.h>
#endif

THRUST_NAMESPACE_BEGIN

_CCCL_EXEC_CHECK_DISABLE
template <typename DerivedPolicy, typename InputIterator, typename Predicate>
_CCCL_HOST_DEVICE bool
all_of(const thrust::detail::execution_policy_base<DerivedPolicy>& exec,
       InputIterator first,
       InputIterator last,
       Predicate pred)
{
  _CCCL_NVTX_RANGE_SCOPE("all_of");
  using thrust::system::detail::generic::all_of;
  return all_of(thrust::detail::derived_cast(thrust::detail::strip_const(exec)), first, last, pred);
} // end all_of()

_CCCL_EXEC_CHECK_DISABLE
template <typename DerivedPolicy, typename InputIterator, typename Predicate>
_CCCL_HOST_DEVICE bool
any_of(const thrust::detail::execution_policy_base<DerivedPolicy>& exec,
       InputIterator first,
       InputIterator last,
       Predicate pred)
{
  _CCCL_NVTX_RANGE_SCOPE("any_of");
  using thrust::system::detail::generic::any_of;
  return any_of(thrust::detail::derived_cast(thrust::detail::strip_const(exec)), first, last, pred);
} // end any_of()

_CCCL_EXEC_CHECK_DISABLE
template <typename DerivedPolicy, typename InputIterator, typename Predicate>
_CCCL_HOST_DEVICE bool
none_of(const thrust::detail::execution_policy_base<DerivedPolicy>& exec,
        InputIterator first,
        InputIterator last,
        Predicate pred)
{
  _CCCL_NVTX_RANGE_SCOPE("none_of");
  using thrust::system::detail::generic::none_of;
  return none_of(thrust::detail::derived_cast(thrust::detail::strip_const(exec)), first, last, pred);
} // end none_of()

template <typename InputIterator, typename Predicate>
bool all_of(InputIterator first, InputIterator last, Predicate pred)
{
  _CCCL_NVTX_RANGE_SCOPE("all_of");
  using thrust::system::detail::generic::select_system;

  using System = typename thrust::iterator_system<InputIterator>::type;

  System system;

  return thrust::all_of(select_system(system), first, last, pred);
}

template <typename InputIterator, typename Predicate>
bool any_of(InputIterator first, InputIterator last, Predicate pred)
{
  _CCCL_NVTX_RANGE_SCOPE("any_of");
  using thrust::system::detail::generic::select_system;

  using System = typename thrust::iterator_system<InputIterator>::type;

  System system;

  return thrust::any_of(select_system(system), first, last, pred);
}

template <typename InputIterator, typename Predicate>
bool none_of(InputIterator first, InputIterator last, Predicate pred)
{
  _CCCL_NVTX_RANGE_SCOPE("none_of");
  using thrust::system::detail::generic::select_system;

  using System = typename thrust::iterator_system<InputIterator>::type;

  System system;

  return thrust::none_of(select_system(system), first, last, pred);
}

THRUST_NAMESPACE_END
