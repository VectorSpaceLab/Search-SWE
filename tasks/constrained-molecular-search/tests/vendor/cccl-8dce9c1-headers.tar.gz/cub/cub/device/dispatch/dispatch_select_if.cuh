// SPDX-FileCopyrightText: Copyright (c) 2011, Duane Merrill. All rights reserved.
// SPDX-FileCopyrightText: Copyright (c) 2011-2026, NVIDIA CORPORATION. All rights reserved.
// SPDX-License-Identifier: BSD-3

/**
 * @file
 *   cub::DeviceSelect provides device-wide, parallel operations for selecting items from sequences
 *   of data items residing within device-accessible memory.
 */

#pragma once

#include <cub/config.cuh>

#if defined(_CCCL_IMPLICIT_SYSTEM_HEADER_GCC)
#  pragma GCC system_header
#elif defined(_CCCL_IMPLICIT_SYSTEM_HEADER_CLANG)
#  pragma clang system_header
#elif defined(_CCCL_IMPLICIT_SYSTEM_HEADER_MSVC)
#  pragma system_header
#endif // no system header

#include <cub/agent/agent_select_if.cuh>
#include <cub/detail/cc_dispatch.cuh>
#include <cub/detail/it_traits.cuh>
#include <cub/detail/logging.cuh>
#include <cub/device/dispatch/dispatch_common.cuh>
#include <cub/device/dispatch/dispatch_scan.cuh>
#include <cub/device/dispatch/tuning/tuning_select_if.cuh>
#include <cub/thread/thread_operators.cuh>
#include <cub/util_arch.cuh>
#include <cub/util_device.cuh>
#include <cub/util_math.cuh>
#include <cub/util_vsmem.cuh>

#include <thrust/system/cuda/detail/core/triple_chevron_launch.h>

#include <cuda/__cmath/ceil_div.h>
#include <cuda/__type_traits/is_specialization_of.h>
#include <cuda/std/__algorithm/max.h>
#include <cuda/std/__host_stdlib/sstream>
#include <cuda/std/__type_traits/conditional.h>
#include <cuda/std/__utility/swap.h>
#include <cuda/std/cstdint>
#include <cuda/std/limits>

#include <nv/target>

_CCCL_DIAG_PUSH
_CCCL_DIAG_SUPPRESS_GCC("-Wattributes") // __visibility__ attribute ignored
_CCCL_DIAG_SUPPRESS_NVHPC(attribute_requires_external_linkage)

CUB_NAMESPACE_BEGIN

namespace detail::select
{
// Offset type used to instantiate the stream compaction-kernel and agent to index the items within one partition
using per_partition_offset_t = ::cuda::std::int32_t;

template <typename TotalNumItemsT, bool IsStreamingInvocation>
class streaming_context_t
{
private:
  bool first_partition = true;
  bool last_partition  = false;
  TotalNumItemsT total_num_items{};
  TotalNumItemsT total_previous_num_items{};

  // We use a double-buffer for keeping track of the number of previously selected items
  TotalNumItemsT* d_num_selected_in  = nullptr;
  TotalNumItemsT* d_num_selected_out = nullptr;

public:
  using total_num_items_t = TotalNumItemsT;

  _CCCL_HOST_DEVICE _CCCL_FORCEINLINE streaming_context_t(
    TotalNumItemsT* d_num_selected_in,
    TotalNumItemsT* d_num_selected_out,
    TotalNumItemsT total_num_items,
    bool is_last_partition)
      : last_partition(is_last_partition)
      , total_num_items(total_num_items)
      , d_num_selected_in(d_num_selected_in)
      , d_num_selected_out(d_num_selected_out)
  {}

  _CCCL_HOST_DEVICE _CCCL_FORCEINLINE void advance(TotalNumItemsT num_items, bool next_partition_is_the_last)
  {
    using ::cuda::std::swap;
    swap(d_num_selected_in, d_num_selected_out);
    first_partition = false;
    last_partition  = next_partition_is_the_last;
    total_previous_num_items += num_items;
  };

  _CCCL_HOST_DEVICE _CCCL_FORCEINLINE TotalNumItemsT input_offset() const
  {
    return first_partition ? TotalNumItemsT{0} : total_previous_num_items;
  };

  _CCCL_HOST_DEVICE _CCCL_FORCEINLINE TotalNumItemsT is_first_partition() const
  {
    return first_partition;
  };

  _CCCL_DEVICE _CCCL_FORCEINLINE TotalNumItemsT num_previously_selected() const
  {
    return first_partition ? TotalNumItemsT{0} : *d_num_selected_in;
  };

  _CCCL_DEVICE _CCCL_FORCEINLINE TotalNumItemsT num_previously_rejected() const
  {
    return first_partition ? TotalNumItemsT{0} : (total_previous_num_items - num_previously_selected());
  };

  template <typename OffsetT>
  _CCCL_HOST_DEVICE _CCCL_FORCEINLINE TotalNumItemsT num_total_items(OffsetT) const
  {
    return total_num_items;
  }

  template <typename NumSelectedIteratorT, typename OffsetT>
  _CCCL_HOST_DEVICE _CCCL_FORCEINLINE void
  update_num_selected(NumSelectedIteratorT user_num_selected_out_it, OffsetT num_selections) const
  {
    if (last_partition)
    {
      *user_num_selected_out_it = num_previously_selected() + static_cast<TotalNumItemsT>(num_selections);
    }
    else
    {
      *d_num_selected_out = num_previously_selected() + static_cast<TotalNumItemsT>(num_selections);
    }
  }
};

template <typename TotalNumItemsT>
class streaming_context_t<TotalNumItemsT, false>
{
public:
  using total_num_items_t = TotalNumItemsT;

  _CCCL_HOST_DEVICE _CCCL_FORCEINLINE streaming_context_t(TotalNumItemsT*, TotalNumItemsT*, TotalNumItemsT, bool) {}

  _CCCL_HOST_DEVICE _CCCL_FORCEINLINE void advance(TotalNumItemsT, bool) {};

  _CCCL_HOST_DEVICE _CCCL_FORCEINLINE TotalNumItemsT input_offset() const
  {
    return TotalNumItemsT{0};
  };

  _CCCL_HOST_DEVICE _CCCL_FORCEINLINE TotalNumItemsT is_first_partition() const
  {
    return true;
  };

  _CCCL_HOST_DEVICE _CCCL_FORCEINLINE TotalNumItemsT num_previously_selected() const
  {
    return TotalNumItemsT{0};
  };

  _CCCL_HOST_DEVICE _CCCL_FORCEINLINE TotalNumItemsT num_previously_rejected() const
  {
    return TotalNumItemsT{0};
  };

  template <typename OffsetT>
  _CCCL_HOST_DEVICE _CCCL_FORCEINLINE TotalNumItemsT num_total_items(OffsetT num_partition_items) const
  {
    return num_partition_items;
  }

  template <typename NumSelectedIteratorT, typename OffsetT>
  _CCCL_HOST_DEVICE _CCCL_FORCEINLINE void
  update_num_selected(NumSelectedIteratorT user_num_selected_out_it, OffsetT num_selections) const
  {
    *user_num_selected_out_it = num_selections;
  }
};

/**
 * @brief Wrapper that partially specializes the `AgentSelectIf` on the non-type name parameter `KeepRejects`.
 */
template <SelectImpl SelectionOpt>
struct bind_selection_opt
{
  // Using an explicit list of template parameters forwarded to AgentSelectIf, since MSVC complains about a template
  // argument following a parameter pack expansion like `AgentSelectIf<Ts..., KeepRejects, MayAlias>`
  template <typename AgentSelectIfPolicyT,
            typename InputIteratorT,
            typename FlagsInputIteratorT,
            typename SelectedOutputIteratorT,
            typename SelectOpT,
            typename EqualityOpT,
            typename OffsetT,
            typename StreamingContextT>
  using agent_t =
    AgentSelectIf<AgentSelectIfPolicyT,
                  InputIteratorT,
                  FlagsInputIteratorT,
                  SelectedOutputIteratorT,
                  SelectOpT,
                  EqualityOpT,
                  OffsetT,
                  StreamingContextT,
                  SelectionOpt>;
};

template <typename DefaultPolicyGetter,
          SelectImpl SelectionOpt,
          typename InputIteratorT,
          typename FlagsInputIteratorT,
          typename SelectedOutputIteratorT,
          typename SelectOpT,
          typename EqualityOpT,
          typename OffsetT,
          typename StreamingContextT>
struct make_vsmem_helper
{
  static constexpr SelectPolicy active_policy = DefaultPolicyGetter{}();
  using agent_policy_t                        = detail::agent_select_if_policy<
    active_policy.lookback.threads_per_block,
    active_policy.lookback.items_per_thread,
    active_policy.lookback.load_algorithm,
    active_policy.lookback.load_modifier,
    active_policy.lookback.scan_algorithm,
    delay_constructor_t<active_policy.lookback.lookback_delay.kind,
                        active_policy.lookback.lookback_delay.delay,
                        active_policy.lookback.lookback_delay.l2_write_latency>,
    active_policy.lookback._load_prefetch>;
  using type = vsmem_helper_default_fallback_policy_t<
    agent_policy_t,
    bind_selection_opt<SelectionOpt>::template agent_t,
    InputIteratorT,
    FlagsInputIteratorT,
    SelectedOutputIteratorT,
    SelectOpT,
    EqualityOpT,
    OffsetT,
    StreamingContextT>;
};

/******************************************************************************
 * Kernel entry points
 *****************************************************************************/

/**
 * Select kernel entry point (multi-block)
 *
 * Performs functor-based selection if SelectOpT functor type != NullType
 * Otherwise performs flag-based selection if FlagsInputIterator's value type != NullType
 * Otherwise performs discontinuity selection (keep unique)
 *
 * @tparam PolicySelectorT
 *   Selects the tuning policy
 *
 * @tparam InputIteratorT
 *   Random-access input iterator type for reading input items
 *
 * @tparam FlagsInputIteratorT
 *   Random-access input iterator type for reading selection flags (NullType* if a selection functor
 *   or discontinuity flagging is to be used for selection)
 *
 * @tparam SelectedOutputIteratorT
 *   Random-access output iterator type for writing selected items
 *
 * @tparam NumSelectedIteratorT
 *   Output iterator type for recording the number of items selected
 *
 * @tparam ScanTileStateT
 *   Tile status interface type
 *
 * @tparam SelectOpT
 *   Selection operator type (NullType if selection flags or discontinuity flagging is
 *   to be used for selection)
 *
 * @tparam EqualityOpT
 *   Equality operator type (NullType if selection functor or selection flags is
 *   to be used for selection)
 *
 * @tparam OffsetT
 *   Signed integer type for offsets within a partition
 *
 * @tparam StreamingContextT
 *   Type providing the context information for the current partition, with the following member functions:
 *    input_offset() -> base offset for the input (and flags) iterator
 *    num_previously_selected() -> base offset for the output iterator for selected items
 *    num_previously_rejected() -> base offset for the output iterator for rejected items (partition only)
 *    num_total_items() -> total number of items across all partitions (partition only)
 *    update_num_selected(d_num_sel_out, num_selected) -> invoked by last CTA with number of selected
 *
 * @tparam KeepRejects
 *   Whether or not we push rejected items to the back of the output
 *
 * @param[in] d_in
 *   Pointer to the input sequence of data items
 *
 * @param[in] d_flags
 *   Pointer to the input sequence of selection flags (if applicable)
 *
 * @param[out] d_selected_out
 *   Pointer to the output sequence of selected data items
 *
 * @param[out] d_num_selected_out
 *   Pointer to the total number of items selected (i.e., length of \p d_selected_out)
 *
 * @param[in] tile_status
 *   Tile status interface
 *
 * @param[in] select_op
 *   Selection operator
 *
 * @param[in] equality_op
 *   Equality operator
 *
 * @param[in] num_items
 *   Total number of input items (i.e., length of \p d_in)
 *
 * @param[in] num_tiles
 *   Total number of tiles for the entire problem
 *
 * @param[in] streaming_context
 *   The context information for the current partition
 *
 * @param[in] vsmem
 *   Memory to support virtual shared memory
 */
template <typename PolicySelectorT,
          typename InputIteratorT,
          typename FlagsInputIteratorT,
          typename SelectedOutputIteratorT,
          typename NumSelectedIteratorT,
          typename ScanTileStateT,
          typename SelectOpT,
          typename EqualityOpT,
          typename OffsetT,
          typename StreamingContextT,
          SelectImpl SelectionOpt>
#if _CCCL_HAS_CONCEPTS()
  requires select_if_policy_selector<PolicySelectorT>
#endif // _CCCL_HAS_CONCEPTS()
__launch_bounds__(int(
  make_vsmem_helper<device_policy_getter<PolicySelectorT, current_tuning_cc().get()>,
                    SelectionOpt,
                    InputIteratorT,
                    FlagsInputIteratorT,
                    SelectedOutputIteratorT,
                    SelectOpT,
                    EqualityOpT,
                    OffsetT,
                    StreamingContextT>::type::agent_policy_t::BLOCK_THREADS))
  _CCCL_KERNEL_ATTRIBUTES void DeviceSelectSweepKernel(
    const InputIteratorT d_in,
    const FlagsInputIteratorT d_flags,
    const SelectedOutputIteratorT d_selected_out,
    const NumSelectedIteratorT d_num_selected_out,
    ScanTileStateT tile_status,
    SelectOpT select_op,
    EqualityOpT equality_op,
    const OffsetT num_items,
    const int num_tiles,
    _CCCL_GRID_CONSTANT const StreamingContextT streaming_context,
    vsmem_t vsmem)
{
  using VsmemHelperT = typename make_vsmem_helper<
    device_policy_getter<PolicySelectorT, current_tuning_cc().get()>,
    SelectionOpt,
    InputIteratorT,
    FlagsInputIteratorT,
    SelectedOutputIteratorT,
    SelectOpT,
    EqualityOpT,
    OffsetT,
    StreamingContextT>::type;

  // Thread block type for selecting data from input tiles
  using AgentSelectIfT = typename VsmemHelperT::agent_t;

  // Static shared memory allocation
  __shared__ typename VsmemHelperT::static_temp_storage_t static_temp_storage;

  // Get temporary storage
  typename AgentSelectIfT::TempStorage& temp_storage = VsmemHelperT::get_temp_storage(static_temp_storage, vsmem);

  // Process tiles
  AgentSelectIfT(temp_storage, d_in, d_flags, d_selected_out, select_op, equality_op, num_items, streaming_context)
    .ConsumeRange(num_tiles, tile_status, d_num_selected_out);

  // If applicable, hints to discard modified cache lines for vsmem
  VsmemHelperT::discard_temp_storage(temp_storage);
}

// TODO(bgruber): remove in CCCL 4.0
template <typename PolicyHub>
struct policy_selector_from_hub
{
  // this is only called in device code
  [[nodiscard]] _CCCL_DEVICE_API constexpr auto operator()(::cuda::compute_capability /*cc*/) const -> SelectPolicy
  {
    using active_policy = typename PolicyHub::MaxPolicy::ActivePolicy::SelectIfPolicyT;
    return SelectPolicy{
      SelectAlgorithm::lookback,
      {active_policy::BLOCK_THREADS,
       active_policy::ITEMS_PER_THREAD,
       active_policy::LOAD_ALGORITHM,
       active_policy::LOAD_MODIFIER,
       active_policy::SCAN_ALGORITHM,
       lookback_delay_policy_from_type<typename active_policy::detail::delay_constructor_t>}};
  }
};
} // namespace detail::select

/******************************************************************************
 * Dispatch
 ******************************************************************************/

/**
 * Utility class for dispatching the appropriately-tuned kernels for DeviceSelect and DevicePartition
 *
 * Deprecated [Since 3.5]
 *
 * @tparam InputIteratorT
 *   Random-access input iterator type for reading input items
 *
 * @tparam FlagsInputIteratorT
 *   Random-access input iterator type for reading selection flags (NullType* if a selection functor or discontinuity
 *   flagging is used for selection)
 *
 * @tparam SelectedOutputIteratorT
 *   Random-access output iterator type for writing selected items
 *
 * @tparam NumSelectedIteratorT
 *   Output iterator type for recording the number of items selected
 *
 * @tparam SelectOpT
 *   Selection operator type (NullType if selection flags or discontinuity flagging is used for selection)
 *
 * @tparam EqualityOpT
 *   Equality operator type (NullType if selection functor or selection flags are used for selection)
 *
 * @tparam OffsetT
 *   Signed integer type for global offsets
 *
 * @tparam SelectionOpt
 *   SelectImpl indicating whether to partition, just selection or selection where the memory for the input and
 *   output may alias each other.
 */
template <
  typename InputIteratorT,
  typename FlagsInputIteratorT,
  typename SelectedOutputIteratorT,
  typename NumSelectedIteratorT,
  typename SelectOpT,
  typename EqualityOpT,
  typename OffsetT,
  SelectImpl SelectionOpt,
  typename PolicyHub = detail::select::policy_hub<
    detail::it_value_t<InputIteratorT>,
    detail::it_value_t<FlagsInputIteratorT>,
    // if/flagged/unique only have a single code path for different offset types, partition has different code paths
    ::cuda::std::conditional_t<SelectionOpt == SelectImpl::Partition, OffsetT, detail::select::per_partition_offset_t>,
    ::cuda::__is_specialization_of_v<SelectedOutputIteratorT, detail::select::partition_distinct_output_t>,
    SelectionOpt>>
struct CCCL_DEPRECATED_BECAUSE("Use the tuning API for DeviceSelect/DevicePartition") DispatchSelectIf
{
  /******************************************************************************
   * Types and constants
   ******************************************************************************/

  // Offset type used to instantiate the stream compaction-kernel and agent to index the items within one partition
  using per_partition_offset_t = detail::select::per_partition_offset_t;

  // Offset type large enough to represent any index within the input and output iterators
  using num_total_items_t = OffsetT;

  // Whether the algorithm is a partitioning invocation (versus a selection invocation)
  static constexpr bool is_partitioning_invocation = (SelectionOpt == SelectImpl::Partition);

  // We always use a streaming context for selection. However, for a partitioning invocation, we only use a streaming
  // context when necessary. I.e., if the values representable by OffsetT exceed the values representable by
  // per_partition_offset_t.
  static constexpr bool use_streaming_context =
    (!is_partitioning_invocation)
    || (static_cast<::cuda::std::uint64_t>(::cuda::std::numeric_limits<per_partition_offset_t>::max())
        < static_cast<::cuda::std::uint64_t>(::cuda::std::numeric_limits<OffsetT>::max()));

  using streaming_context_t = detail::select::streaming_context_t<num_total_items_t, use_streaming_context>;

  using ScanTileStateT = ScanTileState<per_partition_offset_t>;

  static constexpr int INIT_KERNEL_THREADS = 128;

  /// Device-accessible allocation of temporary storage.
  /// When `nullptr`, the required allocation size is written to `temp_storage_bytes`
  /// and no work is done.
  void* d_temp_storage;

  /// Reference to size in bytes of `d_temp_storage` allocation
  size_t& temp_storage_bytes;

  /// Pointer to the input sequence of data items
  InputIteratorT d_in;

  /// Pointer to the input sequence of selection flags (if applicable)
  FlagsInputIteratorT d_flags;

  /// Pointer to the output sequence of selected data items
  SelectedOutputIteratorT d_selected_out;

  /// Pointer to the total number of items selected (i.e., length of `d_selected_out`)
  NumSelectedIteratorT d_num_selected_out;

  /// Selection operator
  SelectOpT select_op;

  /// Equality operator
  EqualityOpT equality_op;

  /// Total number of input items (i.e., length of `d_in`)
  OffsetT num_items;

  /// CUDA stream to launch kernels within. Default is stream<sub>0</sub>.
  cudaStream_t stream;

  int ptx_version;

  /**
   * @param d_temp_storage
   *   Device-accessible allocation of temporary storage.
   *   When `nullptr`, the required allocation size is written to `temp_storage_bytes`
   *   and no work is done.
   *
   * @param temp_storage_bytes
   *   Reference to size in bytes of `d_temp_storage` allocation
   *
   * @param d_in
   *   Pointer to the input sequence of data items
   *
   * @param d_flags
   *   Pointer to the input sequence of selection flags (if applicable)
   *
   * @param d_selected_out
   *   Pointer to the output sequence of selected data items
   *
   * @param d_num_selected_out
   *  Pointer to the total number of items selected (i.e., length of `d_selected_out`)
   *
   * @param select_op
   *   Selection operator
   *
   * @param equality_op
   *   Equality operator
   *
   * @param num_items
   *   Total number of input items (i.e., length of `d_in`)
   *
   * @param stream
   *   CUDA stream to launch kernels within. Default is stream<sub>0</sub>.
   */
  CUB_RUNTIME_FUNCTION _CCCL_FORCEINLINE DispatchSelectIf(
    void* d_temp_storage,
    size_t& temp_storage_bytes,
    InputIteratorT d_in,
    FlagsInputIteratorT d_flags,
    SelectedOutputIteratorT d_selected_out,
    NumSelectedIteratorT d_num_selected_out,
    SelectOpT select_op,
    EqualityOpT equality_op,
    OffsetT num_items,
    cudaStream_t stream,
    int ptx_version)
      : d_temp_storage(d_temp_storage)
      , temp_storage_bytes(temp_storage_bytes)
      , d_in(d_in)
      , d_flags(d_flags)
      , d_selected_out(d_selected_out)
      , d_num_selected_out(d_num_selected_out)
      , select_op(select_op)
      , equality_op(equality_op)
      , num_items(num_items)
      , stream(stream)
      , ptx_version(ptx_version)
  {}

  /******************************************************************************
   * Dispatch entrypoints
   ******************************************************************************/

  /**
   * Internal dispatch routine for computing a device-wide selection using the
   * specified kernel functions.
   */
  template <typename ActivePolicyT, typename ScanInitKernelPtrT, typename SelectIfKernelPtrT>
  CUB_RUNTIME_FUNCTION _CCCL_FORCEINLINE cudaError_t
  Invoke(ScanInitKernelPtrT scan_init_kernel, SelectIfKernelPtrT select_if_kernel)
  {
    using Policy = typename ActivePolicyT::SelectIfPolicyT;

    using VsmemHelperT = cub::detail::vsmem_helper_default_fallback_policy_t<
      Policy,
      detail::select::bind_selection_opt<SelectionOpt>::template agent_t,
      InputIteratorT,
      FlagsInputIteratorT,
      SelectedOutputIteratorT,
      SelectOpT,
      EqualityOpT,
      per_partition_offset_t,
      streaming_context_t>;
    cudaError error = cudaSuccess;

    constexpr auto threads_per_block = VsmemHelperT::agent_policy_t::BLOCK_THREADS;
    constexpr auto items_per_thread  = VsmemHelperT::agent_policy_t::ITEMS_PER_THREAD;
    constexpr auto tile_size         = OffsetT{threads_per_block * items_per_thread};

    // The maximum number of items per partition
    static constexpr auto max_supported_partition_size = ::cuda::std::numeric_limits<per_partition_offset_t>::max();
    static constexpr auto full_tile_partition_size =
      max_supported_partition_size - (max_supported_partition_size % (threads_per_block * items_per_thread));

    // For partitioning invocations, we cap the partition size to the maximum number of items supported.
    // For selection invocations, we cap at the largest multiple of a full tile. There's a selection-specific bug where
    // we would otherwise overflow indices for the last partial tile, when discounting for the out-of-bounds items.
    static constexpr per_partition_offset_t capped_partition_size =
      is_partitioning_invocation ? max_supported_partition_size : full_tile_partition_size;

    // The maximum number of items for which we will ever invoke the kernel (i.e. largest partition size)
    // The extra check of use_streaming_context ensures that OffsetT is larger than per_partition_offset_t to avoid
    // truncation of partition_size
    auto const max_partition_size =
      (use_streaming_context && num_items > static_cast<OffsetT>(capped_partition_size))
        ? static_cast<OffsetT>(capped_partition_size)
        : num_items;

    // The number of partitions required to "iterate" over the total input (ternary to avoid div-by-zero)
    auto const num_partitions =
      (max_partition_size == 0) ? static_cast<OffsetT>(1) : ::cuda::ceil_div(num_items, max_partition_size);

    // The maximum number of tiles for which we will ever invoke the kernel
    auto const max_num_tiles_per_invocation = static_cast<OffsetT>(::cuda::ceil_div(max_partition_size, tile_size));

    // The amount of virtual shared memory to allocate
    const auto vsmem_size = max_num_tiles_per_invocation * VsmemHelperT::vsmem_per_block;

    do
    {
      // Specify temporary storage allocation requirements
      ::cuda::std::size_t streaming_selection_storage_bytes =
        (num_partitions > 1) ? 2 * sizeof(num_total_items_t) : ::cuda::std::size_t{0};
      ::cuda::std::size_t allocation_sizes[3] = {0ULL, vsmem_size, streaming_selection_storage_bytes};

      // Bytes needed for tile status descriptors
      error =
        CubDebug(ScanTileStateT::AllocationSize(static_cast<int>(max_num_tiles_per_invocation), allocation_sizes[0]));
      if (cudaSuccess != error)
      {
        break;
      }

      // Compute allocation pointers into the single storage blob (or compute the necessary size of the blob)
      void* allocations[3] = {};

      error = CubDebug(detail::alias_temporaries(d_temp_storage, temp_storage_bytes, allocations, allocation_sizes));
      if (cudaSuccess != error)
      {
        break;
      }

      if (d_temp_storage == nullptr)
      {
        // Return if the caller is simply requesting the size of the storage allocation
        break;
      }

      // Initialize the streaming context with the temporary storage for double-buffering the previously selected items
      // and the total number (across all partitions) of items
      num_total_items_t* tmp_num_selected_out = reinterpret_cast<num_total_items_t*>(allocations[2]);
      streaming_context_t streaming_context{
        tmp_num_selected_out, (tmp_num_selected_out + 1), num_items, (num_partitions <= 1)};

      // Iterate over the partitions until all input is processed
      for (OffsetT partition_idx = 0; partition_idx < num_partitions; partition_idx++)
      {
        OffsetT current_partition_offset = partition_idx * max_partition_size;
        OffsetT current_num_items =
          (partition_idx + 1 == num_partitions) ? (num_items - current_partition_offset) : max_partition_size;

        // Construct the tile status interface
        const auto current_num_tiles = static_cast<int>(::cuda::ceil_div(current_num_items, tile_size));
        ScanTileStateT tile_status;
        error = CubDebug(tile_status.Init(current_num_tiles, allocations[0], allocation_sizes[0]));
        if (cudaSuccess != error)
        {
          return error;
        }

        // Log scan_init_kernel configuration
        const int init_grid_size = ::cuda::std::max(1, ::cuda::ceil_div(current_num_tiles, INIT_KERNEL_THREADS));

        _CUB_LOG_KERNEL_LAUNCH("scan_init_kernel", init_grid_size, 1, 1, INIT_KERNEL_THREADS, 0, stream, "");

        // Invoke scan_init_kernel to initialize tile descriptors
        error = CubDebug(
          THRUST_NS_QUALIFIER::cuda_cub::detail::triple_chevron(init_grid_size, INIT_KERNEL_THREADS, 0, stream)
            .doit(scan_init_kernel, tile_status, current_num_tiles, d_num_selected_out));
        if (cudaSuccess != error)
        {
          return error;
        }

        // Sync the stream if specified to flush runtime errors
        error = CubDebug(detail::DebugSyncStream(stream));
        if (cudaSuccess != error)
        {
          return error;
        }

        // No more items to process (note, we do not want to return early for num_items==0, because we need to make sure
        // that `scan_init_kernel` has written '0' to d_num_selected_out)
        if (current_num_items == 0)
        {
          return cudaSuccess;
        }

        // Log select_if_kernel configuration
#ifdef CUB_DEBUG_LOG
        constexpr bool cub_debug_log_select_if_kernel = true;
#else // ^^^ CUB_DEBUG_LOG ^^^ / vvv !CUB_DEBUG_LOG vvv
        const bool cub_debug_log_select_if_kernel = detail::logging_enabled();
#endif // !CUB_DEBUG_LOG
        if (cub_debug_log_select_if_kernel)
        {
          // Get SM occupancy for select_if_kernel
          int range_select_sm_occupancy;
          error = CubDebug(MaxSmOccupancy(range_select_sm_occupancy, // out
                                          select_if_kernel,
                                          threads_per_block));
          if (cudaSuccess != error)
          {
            return error;
          }

          _CUB_LOG_KERNEL_LAUNCH(
            "select_if_kernel",
            current_num_tiles,
            1,
            1,
            threads_per_block,
            0,
            stream,
            ", SM occupancy: %d",
            range_select_sm_occupancy);
        }

        // Invoke select_if_kernel
        error = CubDebug(
          THRUST_NS_QUALIFIER::cuda_cub::detail::triple_chevron(current_num_tiles, threads_per_block, 0, stream)
            .doit(select_if_kernel,
                  d_in,
                  d_flags,
                  d_selected_out,
                  d_num_selected_out,
                  tile_status,
                  select_op,
                  equality_op,
                  static_cast<per_partition_offset_t>(current_num_items),
                  current_num_tiles,
                  streaming_context,
                  cub::detail::vsmem_t{allocations[1]}));
        if (cudaSuccess != error)
        {
          return error;
        }

        // Sync the stream if specified to flush runtime errors
        error = CubDebug(detail::DebugSyncStream(stream));
        if (cudaSuccess != error)
        {
          return error;
        }

        // Prepare streaming context for next partition (swap double buffers, advance number of processed items, etc.)
        streaming_context.advance(current_num_items, (partition_idx + OffsetT{2} == num_partitions));
      }
    } while (false);

    return error;
  }

  template <typename ActivePolicyT>
  CUB_RUNTIME_FUNCTION _CCCL_FORCEINLINE cudaError_t Invoke()
  {
    return Invoke<ActivePolicyT>(
      detail::scan::DeviceCompactInitKernel<ScanTileStateT, NumSelectedIteratorT>,
      detail::select::DeviceSelectSweepKernel<
        detail::select::policy_selector_from_hub<PolicyHub>,
        InputIteratorT,
        FlagsInputIteratorT,
        SelectedOutputIteratorT,
        NumSelectedIteratorT,
        ScanTileStateT,
        SelectOpT,
        EqualityOpT,
        per_partition_offset_t,
        streaming_context_t,
        SelectionOpt>);
  }

  /**
   * Internal dispatch routine
   *
   * @param d_temp_storage
   *   Device-accessible allocation of temporary storage.
   *   When `nullptr`, the required allocation size is written to `temp_storage_bytes`
   *   and no work is done.
   *
   * @param temp_storage_bytes
   *   Reference to size in bytes of `d_temp_storage` allocation
   *
   * @param d_in
   *   Pointer to the input sequence of data items
   *
   * @param d_flags
   *   Pointer to the input sequence of selection flags (if applicable)
   *
   * @param d_selected_out
   *   Pointer to the output sequence of selected data items
   *
   * @param d_num_selected_out
   *  Pointer to the total number of items selected (i.e., length of `d_selected_out`)
   *
   * @param select_op
   *   Selection operator
   *
   * @param equality_op
   *   Equality operator
   *
   * @param num_items
   *   Total number of input items (i.e., length of `d_in`)
   *
   * @param stream
   *   CUDA stream to launch kernels within. Default is stream<sub>0</sub>.
   */
  CUB_RUNTIME_FUNCTION _CCCL_FORCEINLINE static cudaError_t Dispatch(
    void* d_temp_storage,
    size_t& temp_storage_bytes,
    InputIteratorT d_in,
    FlagsInputIteratorT d_flags,
    SelectedOutputIteratorT d_selected_out,
    NumSelectedIteratorT d_num_selected_out,
    SelectOpT select_op,
    EqualityOpT equality_op,
    OffsetT num_items,
    cudaStream_t stream)
  {
    int ptx_version = 0;
    if (const cudaError_t error = CubDebug(PtxVersion(ptx_version)))
    {
      return error;
    }

    DispatchSelectIf dispatch(
      d_temp_storage,
      temp_storage_bytes,
      d_in,
      d_flags,
      d_selected_out,
      d_num_selected_out,
      select_op,
      equality_op,
      num_items,
      stream,
      ptx_version);

    return CubDebug(PolicyHub::MaxPolicy::Invoke(ptx_version, dispatch));
  }
};

namespace detail::select
{
template <SelectImpl SelectionOpt,
          typename PolicyGetter,
          typename InputIteratorT,
          typename FlagsInputIteratorT,
          typename SelectedOutputIteratorT,
          typename NumSelectedIteratorT,
          typename SelectOpT,
          typename EqualityOpT,
          typename OffsetT,
          typename PolicySelector,
          typename KernelLauncherFactory>
CUB_RUNTIME_FUNCTION _CCCL_FORCEINLINE cudaError_t dispatch_policy(
  [[maybe_unused]] PolicyGetter policy_getter,
  void* d_temp_storage,
  size_t& temp_storage_bytes,
  InputIteratorT d_in,
  FlagsInputIteratorT d_flags,
  SelectedOutputIteratorT d_selected_out,
  NumSelectedIteratorT d_num_selected_out,
  SelectOpT select_op,
  EqualityOpT equality_op,
  OffsetT num_items,
  cudaStream_t stream,
  [[maybe_unused]] PolicySelector policy_selector,
  KernelLauncherFactory launcher_factory)
{
  static_assert(::cuda::std::is_empty_v<PolicyGetter>);

  static constexpr bool is_partitioning_invocation = (SelectionOpt == SelectImpl::Partition);
  static constexpr bool use_streaming_context =
    (!is_partitioning_invocation)
    || (static_cast<::cuda::std::uint64_t>(::cuda::std::numeric_limits<per_partition_offset_t>::max())
        < static_cast<::cuda::std::uint64_t>(::cuda::std::numeric_limits<OffsetT>::max()));
  using streaming_context_t                = streaming_context_t<OffsetT, use_streaming_context>;
  using ScanTileStateT                     = ScanTileState<per_partition_offset_t>;
  static constexpr int init_kernel_threads = 128;

  using vsmem_helper_t = typename make_vsmem_helper<
    PolicyGetter,
    SelectionOpt,
    InputIteratorT,
    FlagsInputIteratorT,
    SelectedOutputIteratorT,
    SelectOpT,
    EqualityOpT,
    per_partition_offset_t,
    streaming_context_t>::type;

  constexpr auto threads_per_block = vsmem_helper_t::agent_policy_t::BLOCK_THREADS;
  constexpr auto items_per_thread  = vsmem_helper_t::agent_policy_t::ITEMS_PER_THREAD;
  constexpr auto tile_size         = OffsetT{threads_per_block * items_per_thread};

  static constexpr auto max_supported_partition_size = ::cuda::std::numeric_limits<per_partition_offset_t>::max();
  static constexpr auto full_tile_partition_size =
    max_supported_partition_size - (max_supported_partition_size % (threads_per_block * items_per_thread));
  static constexpr per_partition_offset_t capped_partition_size =
    is_partitioning_invocation ? max_supported_partition_size : full_tile_partition_size;

  const auto max_partition_size =
    (use_streaming_context && num_items > static_cast<OffsetT>(capped_partition_size))
      ? static_cast<OffsetT>(capped_partition_size)
      : num_items;
  const auto num_partitions =
    (max_partition_size == 0) ? static_cast<OffsetT>(1) : ::cuda::ceil_div(num_items, max_partition_size);
  const auto max_num_tiles_per_invocation = static_cast<OffsetT>(::cuda::ceil_div(max_partition_size, tile_size));
  const auto vsmem_size                   = max_num_tiles_per_invocation * vsmem_helper_t::vsmem_per_block;

  ::cuda::std::size_t streaming_selection_storage_bytes =
    (num_partitions > 1) ? 2 * sizeof(OffsetT) : ::cuda::std::size_t{0};
  ::cuda::std::size_t allocation_sizes[3] = {0ULL, vsmem_size, streaming_selection_storage_bytes};

  if (const auto error =
        CubDebug(ScanTileStateT::AllocationSize(static_cast<int>(max_num_tiles_per_invocation), allocation_sizes[0])))
  {
    return error;
  }

  void* allocations[3] = {};
  if (const auto error =
        CubDebug(detail::alias_temporaries(d_temp_storage, temp_storage_bytes, allocations, allocation_sizes)))
  {
    return error;
  }

  if (d_temp_storage == nullptr)
  {
    return cudaSuccess;
  }

  OffsetT* tmp_num_selected_out = reinterpret_cast<OffsetT*>(allocations[2]);
  streaming_context_t streaming_context{
    tmp_num_selected_out, (tmp_num_selected_out + 1), num_items, (num_partitions <= 1)};

  for (OffsetT partition_idx = 0; partition_idx < num_partitions; partition_idx++)
  {
    OffsetT current_partition_offset = partition_idx * max_partition_size;
    OffsetT current_num_items =
      (partition_idx + 1 == num_partitions) ? (num_items - current_partition_offset) : max_partition_size;

    const auto current_num_tiles = static_cast<int>(::cuda::ceil_div(current_num_items, tile_size));
    ScanTileStateT tile_status;
    if (const auto error = CubDebug(tile_status.Init(current_num_tiles, allocations[0], allocation_sizes[0])))
    {
      return error;
    }

    const int init_grid_size = ::cuda::std::max(1, ::cuda::ceil_div(current_num_tiles, init_kernel_threads));

    _CUB_LOG_KERNEL_LAUNCH("scan_init_kernel", init_grid_size, 1, 1, init_kernel_threads, 0, stream, "");

    if (const auto error = CubDebug(
          launcher_factory(init_grid_size, init_kernel_threads, 0, stream)
            .doit(detail::scan::DeviceCompactInitKernel<ScanTileStateT, NumSelectedIteratorT>,
                  tile_status,
                  current_num_tiles,
                  d_num_selected_out)))
    {
      return error;
    }

    if (const auto error = CubDebug(detail::DebugSyncStream(stream)))
    {
      return error;
    }

    if (current_num_items == 0)
    {
      return cudaSuccess;
    }

#ifdef CUB_DEBUG_LOG
    constexpr bool cub_debug_log_select_sweep_kernel = true;
#else // ^^^ CUB_DEBUG_LOG ^^^ / vvv !CUB_DEBUG_LOG vvv
    const bool cub_debug_log_select_sweep_kernel = logging_enabled();
#endif // !CUB_DEBUG_LOG
    if (cub_debug_log_select_sweep_kernel)
    {
      int range_select_sm_occupancy;
      if (const auto error = CubDebug(launcher_factory.MaxSmOccupancy(
            range_select_sm_occupancy,
            DeviceSelectSweepKernel<PolicySelector,
                                    InputIteratorT,
                                    FlagsInputIteratorT,
                                    SelectedOutputIteratorT,
                                    NumSelectedIteratorT,
                                    ScanTileStateT,
                                    SelectOpT,
                                    EqualityOpT,
                                    per_partition_offset_t,
                                    streaming_context_t,
                                    SelectionOpt>,
            threads_per_block)))
      {
        return error;
      }

      _CUB_LOG_KERNEL_LAUNCH(
        "DeviceSelectSweepKernel",
        current_num_tiles,
        1,
        1,
        threads_per_block,
        0,
        stream,
        ", SM occupancy: %d",
        range_select_sm_occupancy);
    }

    if (const auto error = CubDebug(
          launcher_factory(current_num_tiles, threads_per_block, 0, stream)
            .doit(
              DeviceSelectSweepKernel<PolicySelector,
                                      InputIteratorT,
                                      FlagsInputIteratorT,
                                      SelectedOutputIteratorT,
                                      NumSelectedIteratorT,
                                      ScanTileStateT,
                                      SelectOpT,
                                      EqualityOpT,
                                      per_partition_offset_t,
                                      streaming_context_t,
                                      SelectionOpt>,
              d_in,
              d_flags,
              d_selected_out,
              d_num_selected_out,
              tile_status,
              select_op,
              equality_op,
              static_cast<per_partition_offset_t>(current_num_items),
              current_num_tiles,
              streaming_context,
              cub::detail::vsmem_t{allocations[1]})))
    {
      return error;
    }

    if (const auto error = CubDebug(detail::DebugSyncStream(stream)))
    {
      return error;
    }

    streaming_context.advance(current_num_items, (partition_idx + OffsetT{2} == num_partitions));
  }

  return cudaSuccess;
}

template <
  SelectImpl SelectionOpt,
  typename InputIteratorT,
  typename FlagsInputIteratorT,
  typename SelectedOutputIteratorT,
  typename NumSelectedIteratorT,
  typename SelectOpT,
  typename EqualityOpT,
  typename OffsetT,
  typename PolicySelector =
    policy_selector_from_types<InputIteratorT, FlagsInputIteratorT, SelectedOutputIteratorT, OffsetT, SelectionOpt>,
  typename KernelLauncherFactory = CUB_DETAIL_DEFAULT_KERNEL_LAUNCHER_FACTORY>
#if _CCCL_HAS_CONCEPTS()
  requires select_if_policy_selector<PolicySelector>
#endif // _CCCL_HAS_CONCEPTS()
CUB_RUNTIME_FUNCTION _CCCL_FORCEINLINE cudaError_t dispatch(
  void* d_temp_storage,
  size_t& temp_storage_bytes,
  InputIteratorT d_in,
  FlagsInputIteratorT d_flags,
  SelectedOutputIteratorT d_selected_out,
  NumSelectedIteratorT d_num_selected_out,
  SelectOpT select_op,
  EqualityOpT equality_op,
  OffsetT num_items,
  cudaStream_t stream,
  PolicySelector policy_selector         = {},
  KernelLauncherFactory launcher_factory = {})
{
  ::cuda::compute_capability cc{};
  if (const auto error = CubDebug(launcher_factory.PtxComputeCap(cc)))
  {
    return error;
  }

  return dispatch_compute_cap(policy_selector, cc, [&](auto policy_getter) {
    detail::log_dispatch("DeviceSelectIf", cc, policy_getter());

    return dispatch_policy<SelectionOpt, decltype(policy_getter)>(
      policy_getter,
      d_temp_storage,
      temp_storage_bytes,
      d_in,
      d_flags,
      d_selected_out,
      d_num_selected_out,
      select_op,
      equality_op,
      num_items,
      stream,
      policy_selector,
      launcher_factory);
  });
}
} // namespace detail::select

CUB_NAMESPACE_END

_CCCL_DIAG_POP
