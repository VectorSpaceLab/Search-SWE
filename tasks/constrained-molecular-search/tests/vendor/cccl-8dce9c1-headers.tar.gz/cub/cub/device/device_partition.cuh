// SPDX-FileCopyrightText: Copyright (c) 2011, Duane Merrill. All rights reserved.
// SPDX-FileCopyrightText: Copyright (c) 2011-2022, NVIDIA CORPORATION. All rights reserved.
// SPDX-License-Identifier: BSD-3

//! @file
//! cub::DevicePartition provides device-wide, parallel operations for partitioning sequences of data items residing
//! within device-accessible memory.

#pragma once

#include <cub/config.cuh>

#ifndef CCCL_DISABLE_NVRTC_COMPATIBILITY_CHECK
#  if _CCCL_COMPILER(NVRTC)
#    error \
      "Including <cub/device/device_partition.cuh> is not supported when compiling with NVRTC. Include block-, warp-, or thread-level primitives instead (e.g. <cub/block/block_reduce.cuh>). You can define CCCL_DISABLE_NVRTC_COMPATIBILITY_CHECK to disable this warning."
#  endif // _CCCL_COMPILER(NVRTC)
#endif // CCCL_DISABLE_NVRTC_COMPATIBILITY_CHECK

#if defined(_CCCL_IMPLICIT_SYSTEM_HEADER_GCC)
#  pragma GCC system_header
#elif defined(_CCCL_IMPLICIT_SYSTEM_HEADER_CLANG)
#  pragma clang system_header
#elif defined(_CCCL_IMPLICIT_SYSTEM_HEADER_MSVC)
#  pragma system_header
#endif // no system header

#include <cub/detail/choose_offset.cuh>
#include <cub/detail/env_dispatch.cuh>
#include <cub/detail/it_traits.cuh>
#include <cub/detail/null_type.cuh>
#include <cub/device/dispatch/dispatch_select_if.cuh>
#include <cub/device/dispatch/dispatch_three_way_partition.cuh>

#include <cuda/std/__execution/env.h>
#include <cuda/std/__type_traits/enable_if.h>
#include <cuda/std/__type_traits/is_same.h>
#include <cuda/std/cstdint>

CUB_NAMESPACE_BEGIN

//! @rst
//! DevicePartition provides device-wide, parallel operations for
//! partitioning sequences of data items residing within device-accessible memory.
//!
//! Overview
//! ++++++++++++++++++++++++++
//!
//! These operations apply a selection criterion to construct a partitioned
//! output sequence from items selected/unselected from a specified input
//! sequence.
//!
//! Usage Considerations
//! ++++++++++++++++++++++++++
//!
//! @cdp_class{DevicePartition}
//!
//! Performance
//! ++++++++++++++++++++++++++
//!
//! @linear_performance{partition}
//!
//! Tuning
//! +++++++++++++++++++++++++++++++++++++++++++++
//!
//! All algorithms in DevicePartition, except @p If with three partitions, that accept an environment can be tuned by
//! passing a custom :ref:`policy selector <cub-policy-selectors>` that returns a :cpp:struct:`cub::PartitionPolicy`, as
//! shown in the example below:
//!
//!  .. literalinclude:: ../../../cub/test/catch2_test_device_partition_env_api.cu
//!      :language: c++
//!      :dedent:
//!      :start-after: example-begin partition-if-policy-selector
//!      :end-before: example-end partition-if-policy-selector
//!
//!  .. literalinclude:: ../../../cub/test/catch2_test_device_partition_env_api.cu
//!      :language: c++
//!      :dedent:
//!      :start-after: example-begin partition-if-tuning
//!      :end-before: example-end partition-if-tuning
//!
//! The environment overload of the three-way @p If algorithm can be tuned using a
//! :cpp:struct:`cub::ThreeWayPartitionPolicy` instead:
//!
//!  .. literalinclude:: ../../../cub/test/catch2_test_device_partition_env_api.cu
//!      :language: c++
//!      :dedent:
//!      :start-after: example-begin partition-three-way-policy-selector
//!      :end-before: example-end partition-three-way-policy-selector
//!
//!  .. literalinclude:: ../../../cub/test/catch2_test_device_partition_env_api.cu
//!      :language: c++
//!      :dedent:
//!      :start-after: example-begin partition-three-way-tuning
//!      :end-before: example-end partition-three-way-tuning
//!
//! @endrst
struct DevicePartition
{
#ifndef _CCCL_DOXYGEN_INVOKED // Do not document
  // Several algorithms dispatch to DeviceSelect, but we want to have a dedicated PartitionPolicy, so we need to adapt
  // the policy selector to convert the tuning policy
  template <typename PolicySelector>
  struct __policy_selector_adapter
  {
    [[nodiscard]] _CCCL_HOST_DEVICE_API constexpr auto operator()(::cuda::compute_capability cc) const -> SelectPolicy
    {
      // the user-provided policy selector returns a PartitionPolicy, the default one a SelectPolicy
      using policy_t = ::cuda::std::remove_cvref_t<decltype(PolicySelector{}(cc))>;
      static_assert(
        ::cuda::std::is_same_v<policy_t, PartitionPolicy> || ::cuda::std::is_same_v<policy_t, SelectPolicy>);
      const auto policy = PolicySelector{}(cc);
      return SelectPolicy{
        SelectAlgorithm::lookback,
        {policy.lookback.threads_per_block,
         policy.lookback.items_per_thread,
         policy.lookback.load_algorithm,
         policy.lookback.load_modifier,
         policy.lookback.scan_algorithm,
         policy.lookback.lookback_delay}};
    }
  };
#endif // _CCCL_DOXYGEN_INVOKED

  //! @rst
  //! Uses the ``d_flags`` sequence to split the corresponding items from
  //! ``d_in`` into a partitioned sequence ``d_out``.
  //! The total number of items copied into the first partition is written to ``d_num_selected_out``.
  //!
  //! .. versionadded:: 2.2.0
  //!    First appears in CUDA Toolkit 12.3.
  //!
  //! - The value type of ``d_flags`` must be castable to ``bool`` (e.g., ``bool``, ``char``, ``int``, etc.).
  //! - Copies of the selected items are compacted into ``d_out`` and maintain
  //!   their original relative ordering, however copies of the unselected
  //!   items are compacted into the rear of ``d_out`` in reverse order.
  //! - The range ``[d_out, d_out + num_items)`` shall not overlap
  //!   ``[d_in, d_in + num_items)`` nor ``[d_flags, d_flags + num_items)`` in any way.
  //!   The range ``[d_in, d_in + num_items)`` may overlap ``[d_flags, d_flags + num_items)``.
  //! - @devicestorage
  //!
  //! Snippet
  //! ++++++++++++++++++++++++++
  //!
  //! The code snippet below illustrates the compaction of items selected from an ``int`` device vector.
  //!
  //! .. code-block:: c++
  //!
  //!    #include <cub/cub.cuh>
  //!    // or equivalently <cub/device/device_partition.cuh>
  //!
  //!    // Declare, allocate, and initialize device-accessible pointers for
  //!    // input, flags, and output
  //!    int  num_items;              // e.g., 8
  //!    int  *d_in;                  // e.g., [1, 2, 3, 4, 5, 6, 7, 8]
  //!    char *d_flags;               // e.g., [1, 0, 0, 1, 0, 1, 1, 0]
  //!    int  *d_out;                 // e.g., [ ,  ,  ,  ,  ,  ,  ,  ]
  //!    int  *d_num_selected_out;    // e.g., [ ]
  //!    ...
  //!
  //!    // Determine temporary device storage requirements
  //!    void *d_temp_storage = nullptr;
  //!    size_t temp_storage_bytes = 0;
  //!    cub::DevicePartition::Flagged(
  //!      d_temp_storage, temp_storage_bytes,
  //!      d_in, d_flags, d_out, d_num_selected_out, num_items);
  //!
  //!    // Allocate temporary storage
  //!    cudaMalloc(&d_temp_storage, temp_storage_bytes);
  //!
  //!    // Run selection
  //!    cub::DevicePartition::Flagged(
  //!      d_temp_storage, temp_storage_bytes,
  //!      d_in, d_flags, d_out, d_num_selected_out, num_items);
  //!
  //!    // d_out                 <-- [1, 4, 6, 7, 8, 5, 3, 2]
  //!    // d_num_selected_out    <-- [4]
  //!
  //! @endrst
  //!
  //! @tparam InputIteratorT
  //!   **[inferred]** Random-access input iterator type for reading input items @iterator
  //!
  //! @tparam FlagIterator
  //!   **[inferred]** Random-access input iterator type for reading selection flags @iterator
  //!
  //! @tparam OutputIteratorT
  //!   **[inferred]** Random-access output iterator type for writing output items @iterator
  //!
  //! @tparam NumSelectedIteratorT
  //!   **[inferred]** Output iterator type for recording the number of items selected @iterator
  //!
  //! @tparam NumItemsT
  //!   **[inferred]** Type of num_items
  //!
  //! @tparam EnvT
  //!   **[inferred]** Environment type (e.g., `cuda::std::execution::env<...>`)
  //!
  //! @param[in] d_temp_storage
  //!   @devicestorage
  //!
  //! @param[in,out] temp_storage_bytes
  //!   Reference to size in bytes of `d_temp_storage` allocation
  //!
  //! @param[in] d_in
  //!   Pointer to the input sequence of data items
  //!
  //! @param[in] d_flags
  //!   Pointer to the input sequence of selection flags
  //!
  //! @param[out] d_out
  //!   Pointer to the output sequence of partitioned data items
  //!
  //! @param[out] d_num_selected_out
  //!   Pointer to the output total number of items selected (i.e., the
  //!   offset of the unselected partition)
  //!
  //! @param[in] num_items
  //!   Total number of items to select from
  //!
  //! @param[in] env
  //!   **[optional]** Execution environment. Default is ``cuda::std::execution::env{}``.
  template <typename InputIteratorT,
            typename FlagIterator,
            typename OutputIteratorT,
            typename NumSelectedIteratorT,
            typename NumItemsT,
            typename EnvT = ::cuda::std::execution::env<>>
  CUB_RUNTIME_FUNCTION _CCCL_FORCEINLINE static cudaError_t Flagged(
    void* d_temp_storage,
    size_t& temp_storage_bytes,
    InputIteratorT d_in,
    FlagIterator d_flags,
    OutputIteratorT d_out,
    NumSelectedIteratorT d_num_selected_out,
    NumItemsT num_items,
    const EnvT& env = {})
  {
    _CCCL_NVTX_RANGE_SCOPE_IF(d_temp_storage, "cub::DevicePartition::Flagged");
    using choose_offset_t = detail::choose_signed_offset<NumItemsT>;
    using offset_t        = typename choose_offset_t::type;

    // Check if the number of items exceeds the range covered by the selected signed offset type
    if (const auto error = choose_offset_t::is_exceeding_offset_type(num_items))
    {
      return error;
    }

    // we can't use dispatch_with_env_and_tuning, since default_policy_selector uses SelectPolicy, not PartitionPolicy
    return detail::dispatch_with_env(
      d_temp_storage,
      temp_storage_bytes,
      env,
      [&]([[maybe_unused]] auto tuning_env, void* storage, size_t& bytes, cudaStream_t stream) {
        using default_policy_selector = detail::select::
          policy_selector_from_types<InputIteratorT, FlagIterator, OutputIteratorT, offset_t, SelectImpl::Partition>;
        using policy_selector_t =
          ::cuda::std::execution::__query_result_or_t<decltype(tuning_env), PartitionPolicy, default_policy_selector>;
        return detail::select::dispatch<SelectImpl::Partition>(
          storage,
          bytes,
          d_in,
          d_flags,
          d_out,
          d_num_selected_out,
          NullType{},
          NullType{},
          static_cast<offset_t>(num_items),
          stream,
          __policy_selector_adapter<policy_selector_t>{});
      });
  }

  //! @rst
  //! Uses the ``d_flags`` sequence to split the corresponding items from
  //! ``d_in`` into a partitioned sequence ``d_out``.
  //! The total number of items copied into the first partition is written to ``d_num_selected_out``.
  //!
  //! .. versionadded:: 3.4.0
  //!    First appears in CUDA Toolkit 13.4.
  //!
  //! This is an environment-based API that allows customization of:
  //!
  //! - Stream: Query via ``cuda::get_stream``
  //! - Memory resource: Query via ``cuda::mr::get_memory_resource``
  //!
  //! - The value type of ``d_flags`` must be castable to ``bool`` (e.g., ``bool``, ``char``, ``int``, etc.).
  //! - Copies of the selected items are compacted into ``d_out`` and maintain
  //!   their original relative ordering, however copies of the unselected
  //!   items are compacted into the rear of ``d_out`` in reverse order.
  //! - The range ``[d_out, d_out + num_items)`` shall not overlap
  //!   ``[d_in, d_in + num_items)`` nor ``[d_flags, d_flags + num_items)`` in any way.
  //!   The range ``[d_in, d_in + num_items)`` may overlap ``[d_flags, d_flags + num_items)``.
  //!
  //! Snippet
  //! +++++++++++++++++++++++++++++++++++++++++++++
  //!
  //! The code snippet below illustrates the partitioning of flagged items from an ``int`` device vector
  //! using environment-based API:
  //!
  //! .. literalinclude:: ../../../cub/test/catch2_test_device_partition_env_api.cu
  //!     :language: c++
  //!     :dedent:
  //!     :start-after: example-begin partition-flagged-env
  //!     :end-before: example-end partition-flagged-env
  //!
  //! @endrst
  //!
  //! @tparam InputIteratorT
  //!   **[inferred]** Random-access input iterator type for reading input items @iterator
  //!
  //! @tparam FlagIterator
  //!   **[inferred]** Random-access input iterator type for reading selection flags @iterator
  //!
  //! @tparam OutputIteratorT
  //!   **[inferred]** Random-access output iterator type for writing output items @iterator
  //!
  //! @tparam NumSelectedIteratorT
  //!   **[inferred]** Output iterator type for recording the number of items selected @iterator
  //!
  //! @tparam NumItemsT
  //!   **[inferred]** Type of num_items
  //!
  //! @tparam EnvT
  //!   **[inferred]** Environment type (e.g., `cuda::std::execution::env<...>`)
  //!
  //! @param[in] d_in
  //!   Pointer to the input sequence of data items
  //!
  //! @param[in] d_flags
  //!   Pointer to the input sequence of selection flags
  //!
  //! @param[out] d_out
  //!   Pointer to the output sequence of partitioned data items
  //!
  //! @param[out] d_num_selected_out
  //!   Pointer to the output total number of items selected (i.e., the
  //!   offset of the unselected partition)
  //!
  //! @param[in] num_items
  //!   Total number of items to select from
  //!
  //! @param[in] env
  //!   **[optional]** Execution environment. Default is ``cuda::std::execution::env{}``.
  template <typename InputIteratorT,
            typename FlagIterator,
            typename OutputIteratorT,
            typename NumSelectedIteratorT,
            typename NumItemsT,
            typename EnvT = ::cuda::std::execution::env<>>
  [[nodiscard]] CUB_RUNTIME_FUNCTION _CCCL_FORCEINLINE static cudaError_t Flagged(
    InputIteratorT d_in,
    FlagIterator d_flags,
    OutputIteratorT d_out,
    NumSelectedIteratorT d_num_selected_out,
    NumItemsT num_items,
    const EnvT& env = {})
  {
    _CCCL_NVTX_RANGE_SCOPE("cub::DevicePartition::Flagged");

    using choose_offset_t = detail::choose_signed_offset<NumItemsT>;
    using offset_t        = typename choose_offset_t::type;

    // Check if the number of items exceeds the range covered by the selected signed offset type
    if (const auto error = choose_offset_t::is_exceeding_offset_type(num_items))
    {
      return error;
    }

    // we can't use dispatch_with_env_and_tuning, since default_policy_selector uses SelectPolicy, not PartitionPolicy
    return detail::dispatch_with_env(
      env, [&]([[maybe_unused]] auto tuning_env, void* storage, size_t& bytes, cudaStream_t stream) {
        using default_policy_selector = detail::select::
          policy_selector_from_types<InputIteratorT, FlagIterator, OutputIteratorT, offset_t, SelectImpl::Partition>;
        using policy_selector_t =
          ::cuda::std::execution::__query_result_or_t<decltype(tuning_env), PartitionPolicy, default_policy_selector>;
        return detail::select::dispatch<SelectImpl::Partition>(
          storage,
          bytes,
          d_in,
          d_flags,
          d_out,
          d_num_selected_out,
          NullType{},
          NullType{},
          static_cast<offset_t>(num_items),
          stream,
          __policy_selector_adapter<policy_selector_t>{});
      });
  }

  //! @rst
  //! Uses the ``select_op`` functor to split the corresponding items from ``d_in`` into
  //! a partitioned sequence ``d_out``. The total number of items copied into the first partition is written
  //! to ``d_num_selected_out``.
  //!
  //! .. versionadded:: 2.2.0
  //!    First appears in CUDA Toolkit 12.3.
  //!
  //! - Copies of the selected items are compacted into ``d_out`` and maintain
  //!   their original relative ordering, however copies of the unselected
  //!   items are compacted into the rear of ``d_out`` in reverse order.
  //! - The range ``[d_out, d_out + num_items)`` shall not overlap
  //!   ``[d_in, d_in + num_items)`` in any way.
  //! - @devicestorage
  //!
  //! Snippet
  //! +++++++++++++++++++++++++++++++++++++++++++++
  //!
  //! The code snippet below illustrates the compaction of items selected from an ``int`` device vector.
  //!
  //! .. code-block:: c++
  //!
  //!    #include <cub/cub.cuh>
  //!    // or equivalently <cub/device/device_partition.cuh>
  //!
  //!    // Functor type for selecting values less than some criteria
  //!    struct LessThan
  //!    {
  //!        int compare;
  //!
  //!        CUB_RUNTIME_FUNCTION __forceinline__
  //!        explicit LessThan(int compare) : compare(compare) {}
  //!
  //!        CUB_RUNTIME_FUNCTION __forceinline__
  //!        bool operator()(const int &a) const
  //!        {
  //!            return (a < compare);
  //!        }
  //!    };
  //!
  //!    // Declare, allocate, and initialize device-accessible pointers for
  //!    // input and output
  //!    int      num_items;              // e.g., 8
  //!    int      *d_in;                  // e.g., [0, 2, 3, 9, 5, 2, 81, 8]
  //!    int      *d_out;                 // e.g., [ ,  ,  ,  ,  ,  ,  ,  ]
  //!    int      *d_num_selected_out;    // e.g., [ ]
  //!    LessThan select_op(7);
  //!    ...
  //!
  //!    // Determine temporary device storage requirements
  //!    void *d_temp_storage = nullptr;
  //!    size_t temp_storage_bytes = 0;
  //!    cub::DevicePartition::If(
  //!    d_temp_storage, temp_storage_bytes,
  //!    d_in, d_out, d_num_selected_out, num_items, select_op);
  //!
  //!    // Allocate temporary storage
  //!    cudaMalloc(&d_temp_storage, temp_storage_bytes);
  //!
  //!    // Run selection
  //!    cub::DevicePartition::If(
  //!      d_temp_storage, temp_storage_bytes,
  //!      d_in, d_out, d_num_selected_out, num_items, select_op);
  //!
  //!    // d_out                 <-- [0, 2, 3, 5, 2, 8, 81, 9]
  //!    // d_num_selected_out    <-- [5]
  //!
  //! @endrst
  //!
  //! @tparam InputIteratorT
  //!   **[inferred]** Random-access input iterator type for reading input items @iterator
  //!
  //! @tparam OutputIteratorT
  //!   **[inferred]** Random-access output iterator type for writing output items @iterator
  //!
  //! @tparam NumSelectedIteratorT
  //!   **[inferred]** Output iterator type for recording the number of items selected @iterator
  //!
  //! @tparam SelectOp
  //!   **[inferred]** Selection functor type having member `bool operator()(const T &a)`
  //!
  //! @tparam NumItemsT
  //!   **[inferred]** Type of num_items
  //!
  //! @tparam EnvT
  //!   **[inferred]** Environment type (e.g., `cuda::std::execution::env<...>`)
  //!
  //! @param[in] d_temp_storage
  //!   @devicestorage
  //!
  //! @param[in,out] temp_storage_bytes
  //!   Reference to size in bytes of ``d_temp_storage`` allocation
  //!
  //! @param[in] d_in
  //!   Pointer to the input sequence of data items
  //!
  //! @param[out] d_out
  //!   Pointer to the output sequence of partitioned data items
  //!
  //! @param[out] d_num_selected_out
  //!   Pointer to the output total number of items selected (i.e., the offset of the unselected partition)
  //!
  //! @param[in] num_items
  //!   Total number of items to select from
  //!
  //! @param[in] select_op
  //!   Unary selection operator
  //!
  //! @param[in] env
  //!   **[optional]** Execution environment. Default is ``cuda::std::execution::env{}``.
  template <typename InputIteratorT,
            typename OutputIteratorT,
            typename NumSelectedIteratorT,
            typename SelectOp,
            typename NumItemsT,
            typename EnvT = ::cuda::std::execution::env<>>
  CUB_RUNTIME_FUNCTION _CCCL_FORCEINLINE static cudaError_t
  If(void* d_temp_storage,
     size_t& temp_storage_bytes,
     InputIteratorT d_in,
     OutputIteratorT d_out,
     NumSelectedIteratorT d_num_selected_out,
     NumItemsT num_items,
     SelectOp select_op,
     const EnvT& env = {})
  {
    _CCCL_NVTX_RANGE_SCOPE_IF(d_temp_storage, "cub::DevicePartition::If");

    using choose_offset_t = detail::choose_signed_offset<NumItemsT>;
    using offset_t        = typename choose_offset_t::type;

    // Check if the number of items exceeds the range covered by the selected signed offset type
    if (const auto error = choose_offset_t::is_exceeding_offset_type(num_items))
    {
      return error;
    }

    return detail::dispatch_with_env(
      d_temp_storage,
      temp_storage_bytes,
      env,
      [&]([[maybe_unused]] auto tuning_env, void* storage, size_t& bytes, cudaStream_t stream) {
        using default_policy_selector = detail::select::
          policy_selector_from_types<InputIteratorT, NullType*, OutputIteratorT, offset_t, SelectImpl::Partition>;
        using policy_selector_t =
          ::cuda::std::execution::__query_result_or_t<decltype(tuning_env), PartitionPolicy, default_policy_selector>;
        return detail::select::dispatch<SelectImpl::Partition>(
          storage,
          bytes,
          d_in,
          static_cast<NullType*>(nullptr),
          d_out,
          d_num_selected_out,
          select_op,
          NullType{},
          static_cast<offset_t>(num_items),
          stream,
          __policy_selector_adapter<policy_selector_t>{});
      });
  }

  //! @rst
  //! Uses the ``select_op`` functor to split the corresponding items from ``d_in`` into
  //! a partitioned sequence ``d_out``. The total number of items copied into the first partition is written
  //! to ``d_num_selected_out``.
  //!
  //! .. versionadded:: 3.4.0
  //!    First appears in CUDA Toolkit 13.4.
  //!
  //! This is an environment-based API that allows customization of:
  //!
  //! - Stream: Query via ``cuda::get_stream``
  //! - Memory resource: Query via ``cuda::mr::get_memory_resource``
  //!
  //! - Copies of the selected items are compacted into ``d_out`` and maintain
  //!   their original relative ordering, however copies of the unselected
  //!   items are compacted into the rear of ``d_out`` in reverse order.
  //! - The range ``[d_out, d_out + num_items)`` shall not overlap
  //!   ``[d_in, d_in + num_items)`` in any way.
  //!
  //! Snippet
  //! +++++++++++++++++++++++++++++++++++++++++++++
  //!
  //! The code snippet below illustrates the partitioning of items selected from an ``int`` device vector
  //! using environment-based API:
  //!
  //! .. literalinclude:: ../../../cub/test/catch2_test_device_partition_env_api.cu
  //!     :language: c++
  //!     :dedent:
  //!     :start-after: example-begin partition-if-env
  //!     :end-before: example-end partition-if-env
  //!
  //! @endrst
  //!
  //! @tparam InputIteratorT
  //!   **[inferred]** Random-access input iterator type for reading input items @iterator
  //!
  //! @tparam OutputIteratorT
  //!   **[inferred]** Random-access output iterator type for writing output items @iterator
  //!
  //! @tparam NumSelectedIteratorT
  //!   **[inferred]** Output iterator type for recording the number of items selected @iterator
  //!
  //! @tparam SelectOp
  //!   **[inferred]** Selection functor type having member `bool operator()(const T &a)`
  //!
  //! @tparam NumItemsT
  //!   **[inferred]** Type of num_items
  //!
  //! @tparam EnvT
  //!   **[inferred]** Environment type (e.g., `cuda::std::execution::env<...>`)
  //!
  //! @param[in] d_in
  //!   Pointer to the input sequence of data items
  //!
  //! @param[out] d_out
  //!   Pointer to the output sequence of partitioned data items
  //!
  //! @param[out] d_num_selected_out
  //!   Pointer to the output total number of items selected (i.e., the offset of the unselected partition)
  //!
  //! @param[in] num_items
  //!   Total number of items to select from
  //!
  //! @param[in] select_op
  //!   Unary selection operator
  //!
  //! @param[in] env
  //!   **[optional]** Execution environment. Default is ``cuda::std::execution::env{}``.
  template <typename InputIteratorT,
            typename OutputIteratorT,
            typename NumSelectedIteratorT,
            typename SelectOp,
            typename NumItemsT,
            typename EnvT = ::cuda::std::execution::env<>>
  [[nodiscard]] CUB_RUNTIME_FUNCTION _CCCL_FORCEINLINE static cudaError_t
  If(InputIteratorT d_in,
     OutputIteratorT d_out,
     NumSelectedIteratorT d_num_selected_out,
     NumItemsT num_items,
     SelectOp select_op,
     const EnvT& env = {})
  {
    _CCCL_NVTX_RANGE_SCOPE("cub::DevicePartition::If");

    using choose_offset_t = detail::choose_signed_offset<NumItemsT>;
    using offset_t        = typename choose_offset_t::type;

    // Check if the number of items exceeds the range covered by the selected signed offset type
    if (const auto error = choose_offset_t::is_exceeding_offset_type(num_items))
    {
      return error;
    }

    // we can't use dispatch_with_env_and_tuning, since default_policy_selector uses SelectPolicy, not PartitionPolicy
    return detail::dispatch_with_env(
      env, [&]([[maybe_unused]] auto tuning_env, void* storage, size_t& bytes, cudaStream_t stream) {
        using default_policy_selector = detail::select::
          policy_selector_from_types<InputIteratorT, NullType*, OutputIteratorT, offset_t, SelectImpl::Partition>;
        using policy_selector_t =
          ::cuda::std::execution::__query_result_or_t<decltype(tuning_env), PartitionPolicy, default_policy_selector>;
        return detail::select::dispatch<SelectImpl::Partition>(
          storage,
          bytes,
          d_in,
          static_cast<NullType*>(nullptr),
          d_out,
          d_num_selected_out,
          select_op,
          NullType{},
          static_cast<offset_t>(num_items),
          stream,
          __policy_selector_adapter<policy_selector_t>{});
      });
  }

  //! @rst
  //! Uses two functors to split the corresponding items from ``d_in`` into a three partitioned sequences
  //! ``d_first_part_out``, ``d_second_part_out``, and ``d_unselected_out``.
  //! The total number of items copied into the first partition is written
  //! to ``d_num_selected_out[0]``, while the total number of items copied into the second partition is written
  //! to ``d_num_selected_out[1]``.
  //!
  //! .. versionadded:: 2.2.0
  //!    First appears in CUDA Toolkit 12.3.
  //!
  //! - Copies of the items selected by ``select_first_part_op`` are compacted
  //!   into ``d_first_part_out`` and maintain their original relative ordering.
  //! - Copies of the items selected by ``select_second_part_op`` are compacted
  //!   into ``d_second_part_out`` and maintain their original relative ordering.
  //! - Copies of the unselected items are compacted into the ``d_unselected_out`` in reverse order.
  //! - The ranges ``[d_out, d_out + num_items)``,
  //!   ``[d_first_part_out, d_first_part_out + d_num_selected_out[0])``,
  //!   ``[d_second_part_out, d_second_part_out + d_num_selected_out[1])``,
  //!   ``[d_unselected_out, d_unselected_out + num_items - d_num_selected_out[0] - d_num_selected_out[1])``,
  //!   shall not overlap in any way.
  //!
  //! Snippet
  //! +++++++++++++++++++++++++++++++++++++++++++++
  //!
  //! The code snippet below illustrates how this algorithm can partition an
  //! input vector into small, medium, and large items so that the relative
  //! order of items remain deterministic.
  //!
  //! Let's consider any value that doesn't exceed six a small one. On the
  //! other hand, any value that exceeds 50 will be considered a large one.
  //! Since the value used to define a small part doesn't match one that
  //! defines the large part, the intermediate segment is implied.
  //!
  //! These definitions partition a value space into three categories. We want
  //! to preserve the order of items in which they appear in the input vector.
  //! Since the algorithm provides stable partitioning, this is possible.
  //!
  //! Since the number of items in each category is unknown beforehand, we need
  //! three output arrays of num_items elements each. To reduce the memory
  //! requirements, we can combine the output storage for two categories.
  //!
  //! Since each value falls precisely in one category, it's safe to add
  //! "large" values into the head of the shared output vector and the "middle"
  //! values into its tail. To add items into the tail of the output array, we
  //! can use ``cuda::std::reverse_iterator``.
  //!
  //! .. code-block:: c++
  //!
  //!    #include <cub/cub.cuh>
  //!    // or equivalently <cub/device/device_partition.cuh>
  //!
  //!    // Functor type for selecting values less than some criteria
  //!    struct LessThan
  //!    {
  //!        int compare;
  //!
  //!        __host__ __device__ __forceinline__
  //!        explicit LessThan(int compare) : compare(compare) {}
  //!
  //!        __host__ __device__ __forceinline__
  //!        bool operator()(const int &a) const
  //!        {
  //!            return a < compare;
  //!        }
  //!    };
  //!
  //!    // Functor type for selecting values greater than some criteria
  //!    struct GreaterThan
  //!    {
  //!        int compare;
  //!
  //!        __host__ __device__ __forceinline__
  //!        explicit GreaterThan(int compare) : compare(compare) {}
  //!
  //!        __host__ __device__ __forceinline__
  //!        bool operator()(const int &a) const
  //!        {
  //!            return a > compare;
  //!        }
  //!    };
  //!
  //!    // Declare, allocate, and initialize device-accessible pointers for
  //!    // input and output
  //!    int      num_items;                   // e.g., 8
  //!    int      *d_in;                       // e.g., [0, 2, 3, 9, 5, 2, 81, 8]
  //!    int      *d_large_and_unselected_out; // e.g., [ ,  ,  ,  ,  ,  ,  ,  ]
  //!    int      *d_small_out;                // e.g., [ ,  ,  ,  ,  ,  ,  ,  ]
  //!    int      *d_num_selected_out;         // e.g., [ , ]
  //!    cud::std::reverse_iterator<T> unselected_out(d_large_and_unselected_out + num_items);
  //!    LessThan small_items_selector(7);
  //!    GreaterThan large_items_selector(50);
  //!    ...
  //!
  //!    // Determine temporary device storage requirements
  //!    void *d_temp_storage = nullptr;
  //!    size_t temp_storage_bytes = 0;
  //!    cub::DevicePartition::If(
  //!         d_temp_storage, temp_storage_bytes,
  //!         d_in, d_large_and_medium_out, d_small_out, unselected_out,
  //!         d_num_selected_out, num_items,
  //!         large_items_selector, small_items_selector);
  //!
  //!    // Allocate temporary storage
  //!    cudaMalloc(&d_temp_storage, temp_storage_bytes);
  //!
  //!    // Run selection
  //!    cub::DevicePartition::If(
  //!         d_temp_storage, temp_storage_bytes,
  //!         d_in, d_large_and_medium_out, d_small_out, unselected_out,
  //!         d_num_selected_out, num_items,
  //!         large_items_selector, small_items_selector);
  //!
  //!    // d_large_and_unselected_out  <-- [ 81,  ,  ,  ,  ,  , 8, 9 ]
  //!    // d_small_out                 <-- [  0, 2, 3, 5, 2,  ,  ,   ]
  //!    // d_num_selected_out          <-- [  1, 5 ]
  //!
  //! @endrst
  //!
  //! @tparam InputIteratorT
  //!   **[inferred]** Random-access input iterator type for reading input items @iterator
  //!
  //! @tparam FirstOutputIteratorT
  //!   **[inferred]** Random-access output iterator type for writing output
  //!   items selected by first operator @iterator
  //!
  //! @tparam SecondOutputIteratorT
  //!   **[inferred]** Random-access output iterator type for writing output
  //!   items selected by second operator @iterator
  //!
  //! @tparam UnselectedOutputIteratorT
  //!   **[inferred]** Random-access output iterator type for writing
  //!   unselected items @iterator
  //!
  //! @tparam NumSelectedIteratorT
  //!   **[inferred]** Output iterator type for recording the number of items
  //!   selected @iterator
  //!
  //! @tparam SelectFirstPartOp
  //!   **[inferred]** Selection functor type having member `bool operator()(const T &a)`
  //!
  //! @tparam SelectSecondPartOp
  //!   **[inferred]** Selection functor type having member `bool operator()(const T &a)`
  //!
  //! @tparam NumItemsT
  //!   **[inferred]** Type of num_items
  //!
  //! @tparam EnvT
  //!   **[inferred]** Environment type (e.g., `cuda::std::execution::env<...>`)
  //!
  //! @param[in] d_temp_storage
  //!   @devicestorage
  //!
  //! @param[in,out] temp_storage_bytes
  //!   Reference to size in bytes of `d_temp_storage` allocation
  //!
  //! @param[in] d_in
  //!   Pointer to the input sequence of data items
  //!
  //! @param[out] d_first_part_out
  //!   Pointer to the output sequence of data items selected by `select_first_part_op`
  //!
  //! @param[out] d_second_part_out
  //!   Pointer to the output sequence of data items selected by `select_second_part_op`
  //!
  //! @param[out] d_unselected_out
  //!   Pointer to the output sequence of unselected data items
  //!
  //! @param[out] d_num_selected_out
  //!   Pointer to the output array with two elements, where total number of
  //!   items selected by `select_first_part_op` is stored as
  //!   `d_num_selected_out[0]` and total number of items selected by
  //!   `select_second_part_op` is stored as `d_num_selected_out[1]`,
  //!   respectively
  //!
  //! @param[in] num_items
  //!   Total number of items to select from
  //!
  //! @param[in] select_first_part_op
  //!   Unary selection operator to select `d_first_part_out`
  //!
  //! @param[in] select_second_part_op
  //!   Unary selection operator to select `d_second_part_out`
  //!
  //! @param[in] env
  //!   **[optional]** Execution environment. Default is ``cuda::std::execution::env{}``.
  template <typename InputIteratorT,
            typename FirstOutputIteratorT,
            typename SecondOutputIteratorT,
            typename UnselectedOutputIteratorT,
            typename NumSelectedIteratorT,
            typename SelectFirstPartOp,
            typename SelectSecondPartOp,
            typename NumItemsT,
            typename EnvT = ::cuda::std::execution::env<>>
  CUB_RUNTIME_FUNCTION _CCCL_FORCEINLINE static cudaError_t
  If(void* d_temp_storage,
     size_t& temp_storage_bytes,
     InputIteratorT d_in,
     FirstOutputIteratorT d_first_part_out,
     SecondOutputIteratorT d_second_part_out,
     UnselectedOutputIteratorT d_unselected_out,
     NumSelectedIteratorT d_num_selected_out,
     NumItemsT num_items,
     SelectFirstPartOp select_first_part_op,
     SelectSecondPartOp select_second_part_op,
     const EnvT& env = {})
  {
    _CCCL_NVTX_RANGE_SCOPE_IF(d_temp_storage, "cub::DevicePartition::If");
    using choose_offset_t = detail::choose_signed_offset<NumItemsT>;

    // Check if the number of items exceeds the range covered by the selected signed offset type
    if (const auto error = choose_offset_t::is_exceeding_offset_type(num_items))
    {
      return error;
    }

    using offset_t = typename choose_offset_t::type;
    using default_policy_selector =
      detail::three_way_partition::policy_selector_from_types<detail::it_value_t<InputIteratorT>,
                                                              detail::three_way_partition::per_partition_offset_t>;

    return detail::dispatch_with_env_and_tuning<default_policy_selector>(
      d_temp_storage, temp_storage_bytes, env, [&](auto policy_selector, void* storage, size_t& bytes, auto stream) {
        return detail::three_way_partition::dispatch(
          storage,
          bytes,
          d_in,
          d_first_part_out,
          d_second_part_out,
          d_unselected_out,
          d_num_selected_out,
          select_first_part_op,
          select_second_part_op,
          static_cast<offset_t>(num_items),
          stream,
          policy_selector);
      });
  }

  //! @rst
  //! Uses two functors to split the corresponding items from ``d_in`` into three partitioned sequences
  //! ``d_first_part_out``, ``d_second_part_out``, and ``d_unselected_out``.
  //! The total number of items copied into the first partition is written
  //! to ``d_num_selected_out[0]``, while the total number of items copied into the second partition is written
  //! to ``d_num_selected_out[1]``.
  //!
  //! .. versionadded:: 3.4.0
  //!    First appears in CUDA Toolkit 13.4.
  //!
  //! This is an environment-based API that allows customization of:
  //!
  //! - Stream: Query via ``cuda::get_stream``
  //! - Memory resource: Query via ``cuda::mr::get_memory_resource``
  //!
  //! - Copies of the items selected by ``select_first_part_op`` are compacted
  //!   into ``d_first_part_out`` and maintain their original relative ordering.
  //! - Copies of the items selected by ``select_second_part_op`` are compacted
  //!   into ``d_second_part_out`` and maintain their original relative ordering.
  //! - Copies of the unselected items are compacted into the ``d_unselected_out`` in reverse order.
  //! - The ranges ``[d_out, d_out + num_items)``,
  //!   ``[d_first_part_out, d_first_part_out + d_num_selected_out[0])``,
  //!   ``[d_second_part_out, d_second_part_out + d_num_selected_out[1])``,
  //!   ``[d_unselected_out, d_unselected_out + num_items - d_num_selected_out[0] - d_num_selected_out[1])``,
  //!   shall not overlap in any way.
  //!
  //! Snippet
  //! +++++++++++++++++++++++++++++++++++++++++++++
  //!
  //! The code snippet below illustrates three-way partitioning.
  //!
  //! .. literalinclude:: ../../../cub/test/catch2_test_device_partition_env_api.cu
  //!     :language: c++
  //!     :dedent:
  //!     :start-after: example-begin partition-three-way-env
  //!     :end-before: example-end partition-three-way-env
  //!
  //! @endrst
  //!
  //! @tparam InputIteratorT
  //!   **[inferred]** Random-access input iterator type for reading input items @iterator
  //!
  //! @tparam FirstOutputIteratorT
  //!   **[inferred]** Random-access output iterator type for writing output
  //!   items selected by first operator @iterator
  //!
  //! @tparam SecondOutputIteratorT
  //!   **[inferred]** Random-access output iterator type for writing output
  //!   items selected by second operator @iterator
  //!
  //! @tparam UnselectedOutputIteratorT
  //!   **[inferred]** Random-access output iterator type for writing
  //!   unselected items @iterator
  //!
  //! @tparam NumSelectedIteratorT
  //!   **[inferred]** Output iterator type for recording the number of items
  //!   selected @iterator
  //!
  //! @tparam SelectFirstPartOp
  //!   **[inferred]** Selection functor type having member `bool operator()(const T &a)`
  //!
  //! @tparam SelectSecondPartOp
  //!   **[inferred]** Selection functor type having member `bool operator()(const T &a)`
  //!
  //! @tparam NumItemsT
  //!   **[inferred]** Type of num_items
  //!
  //! @tparam EnvT
  //!   **[inferred]** Environment type (e.g., ``cuda::std::execution::env<...>``)
  //!
  //! @param[in] d_in
  //!   Pointer to the input sequence of data items
  //!
  //! @param[out] d_first_part_out
  //!   Pointer to the output sequence of data items selected by `select_first_part_op`
  //!
  //! @param[out] d_second_part_out
  //!   Pointer to the output sequence of data items selected by `select_second_part_op`
  //!
  //! @param[out] d_unselected_out
  //!   Pointer to the output sequence of unselected data items
  //!
  //! @param[out] d_num_selected_out
  //!   Pointer to the output array with two elements, where total number of
  //!   items selected by `select_first_part_op` is stored as
  //!   `d_num_selected_out[0]` and total number of items selected by
  //!   `select_second_part_op` is stored as `d_num_selected_out[1]`,
  //!   respectively
  //!
  //! @param[in] num_items
  //!   Total number of items to select from
  //!
  //! @param[in] select_first_part_op
  //!   Unary selection operator to select `d_first_part_out`
  //!
  //! @param[in] select_second_part_op
  //!   Unary selection operator to select `d_second_part_out`
  //!
  //! @param[in] env
  //!   @rst
  //!   **[optional]** Execution environment. Default is ``cuda::std::execution::env{}``.
  //!   @endrst
  template <typename InputIteratorT,
            typename FirstOutputIteratorT,
            typename SecondOutputIteratorT,
            typename UnselectedOutputIteratorT,
            typename NumSelectedIteratorT,
            typename SelectFirstPartOp,
            typename SelectSecondPartOp,
            typename NumItemsT,
            typename EnvT = ::cuda::std::execution::env<>,
            ::cuda::std::enable_if_t<!::cuda::std::is_same_v<FirstOutputIteratorT, size_t>, int> = 0>
  [[nodiscard]] CUB_RUNTIME_FUNCTION _CCCL_FORCEINLINE static cudaError_t
  If(InputIteratorT d_in,
     FirstOutputIteratorT d_first_part_out,
     SecondOutputIteratorT d_second_part_out,
     UnselectedOutputIteratorT d_unselected_out,
     NumSelectedIteratorT d_num_selected_out,
     NumItemsT num_items,
     SelectFirstPartOp select_first_part_op,
     SelectSecondPartOp select_second_part_op,
     const EnvT& env = {})
  {
    _CCCL_NVTX_RANGE_SCOPE("cub::DevicePartition::If");

    using choose_offset_t = detail::choose_signed_offset<NumItemsT>;
    if (const auto error = choose_offset_t::is_exceeding_offset_type(num_items))
    {
      return error;
    }

    using offset_t = typename choose_offset_t::type;
    using default_policy_selector =
      detail::three_way_partition::policy_selector_from_types<detail::it_value_t<InputIteratorT>,
                                                              detail::three_way_partition::per_partition_offset_t>;

    return detail::dispatch_with_env_and_tuning<default_policy_selector>(
      env, [&](auto policy_selector, void* storage, size_t& bytes, auto stream) {
        return detail::three_way_partition::dispatch(
          storage,
          bytes,
          d_in,
          d_first_part_out,
          d_second_part_out,
          d_unselected_out,
          d_num_selected_out,
          select_first_part_op,
          select_second_part_op,
          static_cast<offset_t>(num_items),
          stream,
          policy_selector);
      });
  }
};

CUB_NAMESPACE_END
