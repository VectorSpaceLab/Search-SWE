// SPDX-FileCopyrightText: Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.
// SPDX-License-Identifier: BSD-3

#pragma once

#include <cub/config.cuh>

#if defined(_CCCL_IMPLICIT_SYSTEM_HEADER_GCC)
#  pragma GCC system_header
#elif defined(_CCCL_IMPLICIT_SYSTEM_HEADER_CLANG)
#  pragma clang system_header
#elif defined(_CCCL_IMPLICIT_SYSTEM_HEADER_MSVC)
#  pragma system_header
#endif // no system header

#include <cub/agent/agent_reduce_by_key.cuh>
#include <cub/agent/single_pass_scan_operators.cuh>
#include <cub/block/block_load.cuh>
#include <cub/block/block_scan.cuh>
#include <cub/detail/delay_constructor.cuh>
#include <cub/detail/numeric_traits.cuh>
#include <cub/device/dispatch/tuning/common.cuh>
#include <cub/util_device.cuh>

#include <cuda/__cmath/ceil_div.h>
#include <cuda/__device/compute_capability.h>
#include <cuda/__type_traits/is_trivially_copyable.h>
#include <cuda/std/__algorithm/clamp.h>
#include <cuda/std/__host_stdlib/ostream>
#include <cuda/std/concepts>

CUB_NAMESPACE_BEGIN

//! The lookback tuning policy for `DeviceReduce::ReduceByKey`
struct ReduceByKeyLookbackPolicy
{
  int threads_per_block; //!< Number of threads in a CUDA block
  int items_per_thread; //!< Number of items processed per thread
  BlockLoadAlgorithm load_algorithm; //!< The @ref BlockLoadAlgorithm used for loading items from global memory
  CacheLoadModifier load_modifier; //!< The @ref CacheLoadModifier used for loading items from global memory
  BlockScanAlgorithm scan_algorithm; //!< The @ref BlockScanAlgorithm used for the prefix scan
  LookbackDelayPolicy lookback_delay; //!< The @ref LookbackDelayPolicy used for the lookback delay

  [[nodiscard]] _CCCL_HOST_DEVICE_API friend constexpr bool
  operator==(const ReduceByKeyLookbackPolicy& lhs, const ReduceByKeyLookbackPolicy& rhs) noexcept
  {
    return lhs.threads_per_block == rhs.threads_per_block && lhs.items_per_thread == rhs.items_per_thread
        && lhs.load_algorithm == rhs.load_algorithm && lhs.load_modifier == rhs.load_modifier
        && lhs.scan_algorithm == rhs.scan_algorithm && lhs.lookback_delay == rhs.lookback_delay;
  }

  [[nodiscard]] _CCCL_HOST_DEVICE_API friend constexpr bool
  operator!=(const ReduceByKeyLookbackPolicy& lhs, const ReduceByKeyLookbackPolicy& rhs) noexcept
  {
    return !(lhs == rhs);
  }

#if _CCCL_HOSTED()
  friend ::std::ostream& operator<<(::std::ostream& os, const ReduceByKeyLookbackPolicy& p)
  {
    return os
        << "ReduceByKeyLookbackPolicy { .threads_per_block = " << p.threads_per_block << ", .items_per_thread = "
        << p.items_per_thread << ", .load_algorithm = " << p.load_algorithm << ", .load_modifier = " << p.load_modifier
        << ", .scan_algorithm = " << p.scan_algorithm << ", .lookback_delay = " << p.lookback_delay << " }";
  }
#endif // _CCCL_HOSTED()
};

//! The algorithm used by the reduce-by-key policy.
enum class ReduceByKeyAlgorithm
{
  lookback
};

#if _CCCL_HOSTED()
namespace detail
{
[[nodiscard]] _CCCL_HOST_DEVICE_API constexpr const char* to_string(ReduceByKeyAlgorithm algo) noexcept
{
  switch (algo)
  {
    case ReduceByKeyAlgorithm::lookback:
      return "ReduceByKeyAlgorithm::lookback";
  }
  return "<unknown ReduceByKeyAlgorithm>";
}
} // namespace detail

inline ::std::ostream& operator<<(::std::ostream& os, ReduceByKeyAlgorithm algo)
{
  return os << CUB_NS_QUALIFIER::detail::to_string(algo);
}
#endif // _CCCL_HOSTED()

//! The tuning policy for `DeviceReduce::ReduceByKey`
struct ReduceByKeyPolicy
{
  ReduceByKeyAlgorithm algorithm; //!< The reduce-by-key algorithm to use
  ReduceByKeyLookbackPolicy lookback; //!< The policy for the reduce-by-key algorithm based on decoupled-lookback. Only
                                      //!< used when @p algorithm is @lookback.

  [[nodiscard]] _CCCL_HOST_DEVICE_API friend constexpr bool
  operator==(const ReduceByKeyPolicy& lhs, const ReduceByKeyPolicy& rhs) noexcept
  {
    return lhs.algorithm == rhs.algorithm && lhs.lookback == rhs.lookback;
  }

  [[nodiscard]] _CCCL_HOST_DEVICE_API friend constexpr bool
  operator!=(const ReduceByKeyPolicy& lhs, const ReduceByKeyPolicy& rhs) noexcept
  {
    return !(lhs == rhs);
  }

#if _CCCL_HOSTED()
  friend ::std::ostream& operator<<(::std::ostream& os, const ReduceByKeyPolicy& p)
  {
    return os << "ReduceByKeyPolicy { .algorithm = " << p.algorithm << ", .lookback = " << p.lookback << " }";
  }
#endif // _CCCL_HOSTED()
};

namespace detail::reduce_by_key
{
// TODO(bgruber): remove in CCCL 4.0 when we drop the reduce-by-key dispatchers
enum class primitive_key
{
  no,
  yes
};

// TODO(bgruber): remove in CCCL 4.0 when we drop the reduce-by-key dispatchers
enum class primitive_accum
{
  no,
  yes
};

// TODO(bgruber): remove in CCCL 4.0 when we drop the reduce-by-key dispatchers
enum class primitive_op
{
  no,
  yes
};

// TODO(bgruber): remove in CCCL 4.0 when we drop the reduce-by-key dispatchers
enum class key_size
{
  _1,
  _2,
  _4,
  _8,
  _16,
  unknown
};

// TODO(bgruber): remove in CCCL 4.0 when we drop the reduce-by-key dispatchers
enum class accum_size
{
  _1,
  _2,
  _4,
  _8,
  _16,
  unknown
};

// TODO(bgruber): remove in CCCL 4.0 when we drop the reduce-by-key dispatchers
template <class T>
_CCCL_HOST_DEVICE_API constexpr primitive_key is_primitive_key()
{
  return detail::is_primitive<T>::value ? primitive_key::yes : primitive_key::no;
}

// TODO(bgruber): remove in CCCL 4.0 when we drop the reduce-by-key dispatchers
template <class T>
_CCCL_HOST_DEVICE_API constexpr primitive_accum is_primitive_accum()
{
  return detail::is_primitive<T>::value ? primitive_accum::yes : primitive_accum::no;
}

// TODO(bgruber): remove in CCCL 4.0 when we drop the reduce-by-key dispatchers
template <class ReductionOpT>
_CCCL_HOST_DEVICE_API constexpr primitive_op is_primitive_op()
{
  return basic_binary_op_v<ReductionOpT> ? primitive_op::yes : primitive_op::no;
}

// TODO(bgruber): remove in CCCL 4.0 when we drop the reduce-by-key dispatchers
template <class KeyT>
_CCCL_HOST_DEVICE_API constexpr key_size classify_key_size()
{
  return sizeof(KeyT) == 1 ? key_size::_1
       : sizeof(KeyT) == 2 ? key_size::_2
       : sizeof(KeyT) == 4 ? key_size::_4
       : sizeof(KeyT) == 8 ? key_size::_8
       : sizeof(KeyT) == 16
         ? key_size::_16
         : key_size::unknown;
}

// TODO(bgruber): remove in CCCL 4.0 when we drop the reduce-by-key dispatchers
template <class AccumT>
_CCCL_HOST_DEVICE_API constexpr accum_size classify_accum_size()
{
  return sizeof(AccumT) == 1 ? accum_size::_1
       : sizeof(AccumT) == 2 ? accum_size::_2
       : sizeof(AccumT) == 4 ? accum_size::_4
       : sizeof(AccumT) == 8 ? accum_size::_8
       : sizeof(AccumT) == 16
         ? accum_size::_16
         : accum_size::unknown;
}

// TODO(bgruber): remove in CCCL 4.0 when we drop the reduce-by-key dispatchers
template <class KeyT,
          class AccumT,
          primitive_op PrimitiveOp,
          primitive_key PrimitiveKey     = is_primitive_key<KeyT>(),
          primitive_accum PrimitiveAccum = is_primitive_accum<AccumT>(),
          key_size KeySize               = classify_key_size<KeyT>(),
          accum_size AccumSize           = classify_accum_size<AccumT>()>
struct sm80_tuning;

// 8-bit key
template <class KeyT, class AccumT>
struct sm80_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::yes, key_size::_1, accum_size::_1>
{
  static constexpr int threads                       = 256;
  static constexpr int items                         = 13;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_DIRECT;
  using delay_constructor                            = detail::no_delay_constructor_t<975>;
};

template <class KeyT, class AccumT>
struct sm80_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::yes, key_size::_1, accum_size::_2>
{
  static constexpr int threads                       = 224;
  static constexpr int items                         = 12;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_DIRECT;
  using delay_constructor                            = detail::no_delay_constructor_t<840>;
};

template <class KeyT, class AccumT>
struct sm80_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::yes, key_size::_1, accum_size::_4>
{
  static constexpr int threads                       = 256;
  static constexpr int items                         = 15;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_WARP_TRANSPOSE;
  using delay_constructor                            = detail::no_delay_constructor_t<760>;
};

template <class KeyT, class AccumT>
struct sm80_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::yes, key_size::_1, accum_size::_8>
{
  static constexpr int threads                       = 224;
  static constexpr int items                         = 7;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_DIRECT;
  using delay_constructor                            = detail::no_delay_constructor_t<1070>;
};

template <class KeyT, class AccumT>
struct sm80_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::no, key_size::_1, accum_size::_16>
{
  static constexpr int threads                       = 128;
  static constexpr int items                         = 9;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_WARP_TRANSPOSE;
  using delay_constructor                            = detail::no_delay_constructor_t<1175>;
};

// 16-bit key
template <class KeyT, class AccumT>
struct sm80_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::yes, key_size::_2, accum_size::_1>
{
  static constexpr int threads                       = 256;
  static constexpr int items                         = 11;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_DIRECT;
  using delay_constructor                            = detail::no_delay_constructor_t<620>;
};

template <class KeyT, class AccumT>
struct sm80_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::yes, key_size::_2, accum_size::_2>
{
  static constexpr int threads                       = 224;
  static constexpr int items                         = 14;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_WARP_TRANSPOSE;
  using delay_constructor                            = detail::no_delay_constructor_t<640>;
};

template <class KeyT, class AccumT>
struct sm80_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::yes, key_size::_2, accum_size::_4>
{
  static constexpr int threads                       = 256;
  static constexpr int items                         = 14;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_WARP_TRANSPOSE;
  using delay_constructor                            = detail::no_delay_constructor_t<905>;
};

template <class KeyT, class AccumT>
struct sm80_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::yes, key_size::_2, accum_size::_8>
{
  static constexpr int threads                       = 224;
  static constexpr int items                         = 9;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_WARP_TRANSPOSE;
  using delay_constructor                            = detail::no_delay_constructor_t<810>;
};

template <class KeyT, class AccumT>
struct sm80_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::no, key_size::_2, accum_size::_16>
{
  static constexpr int threads                       = 160;
  static constexpr int items                         = 9;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_WARP_TRANSPOSE;
  using delay_constructor                            = detail::no_delay_constructor_t<1115>;
};

// 32-bit key
template <class KeyT, class AccumT>
struct sm80_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::yes, key_size::_4, accum_size::_1>
{
  static constexpr int threads                       = 288;
  static constexpr int items                         = 11;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_DIRECT;
  using delay_constructor                            = detail::no_delay_constructor_t<1110>;
};

template <class KeyT, class AccumT>
struct sm80_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::yes, key_size::_4, accum_size::_2>
{
  static constexpr int threads                       = 192;
  static constexpr int items                         = 15;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_WARP_TRANSPOSE;
  using delay_constructor                            = detail::no_delay_constructor_t<1200>;
};

template <class KeyT, class AccumT>
struct sm80_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::yes, key_size::_4, accum_size::_4>
{
  static constexpr int threads                       = 256;
  static constexpr int items                         = 15;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_DIRECT;
  using delay_constructor                            = detail::no_delay_constructor_t<1110>;
};

template <class KeyT, class AccumT>
struct sm80_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::yes, key_size::_4, accum_size::_8>
{
  static constexpr int threads                       = 224;
  static constexpr int items                         = 9;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_WARP_TRANSPOSE;
  using delay_constructor                            = detail::no_delay_constructor_t<1165>;
};

template <class KeyT, class AccumT>
struct sm80_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::no, key_size::_4, accum_size::_16>
{
  static constexpr int threads                       = 160;
  static constexpr int items                         = 9;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_WARP_TRANSPOSE;
  using delay_constructor                            = detail::no_delay_constructor_t<1100>;
};

// 64-bit key
template <class KeyT, class AccumT>
struct sm80_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::yes, key_size::_8, accum_size::_1>
{
  static constexpr int threads                       = 192;
  static constexpr int items                         = 10;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_WARP_TRANSPOSE;
  using delay_constructor                            = detail::no_delay_constructor_t<1175>;
};

template <class KeyT, class AccumT>
struct sm80_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::yes, key_size::_8, accum_size::_2>
{
  static constexpr int threads                       = 224;
  static constexpr int items                         = 7;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_DIRECT;
  using delay_constructor                            = detail::no_delay_constructor_t<1075>;
};

template <class KeyT, class AccumT>
struct sm80_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::yes, key_size::_8, accum_size::_4>
{
  static constexpr int threads                       = 384;
  static constexpr int items                         = 7;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_DIRECT;
  using delay_constructor                            = detail::no_delay_constructor_t<1040>;
};

template <class KeyT, class AccumT>
struct sm80_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::yes, key_size::_8, accum_size::_8>
{
  static constexpr int threads                       = 128;
  static constexpr int items                         = 14;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_WARP_TRANSPOSE;
  using delay_constructor                            = detail::no_delay_constructor_t<1080>;
};

template <class KeyT, class AccumT>
struct sm80_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::no, key_size::_8, accum_size::_16>
{
  static constexpr int threads                       = 128;
  static constexpr int items                         = 11;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_WARP_TRANSPOSE;
  using delay_constructor                            = detail::no_delay_constructor_t<430>;
};

// 128-bit key
template <class KeyT, class AccumT>
struct sm80_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::no, primitive_accum::yes, key_size::_16, accum_size::_1>
{
  static constexpr int threads                       = 192;
  static constexpr int items                         = 7;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_DIRECT;
  using delay_constructor                            = detail::no_delay_constructor_t<1105>;
};

template <class KeyT, class AccumT>
struct sm80_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::no, primitive_accum::yes, key_size::_16, accum_size::_2>
{
  static constexpr int threads                       = 192;
  static constexpr int items                         = 7;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_WARP_TRANSPOSE;
  using delay_constructor                            = detail::no_delay_constructor_t<755>;
};

template <class KeyT, class AccumT>
struct sm80_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::no, primitive_accum::yes, key_size::_16, accum_size::_4>
{
  static constexpr int threads                       = 192;
  static constexpr int items                         = 7;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_WARP_TRANSPOSE;
  using delay_constructor                            = detail::no_delay_constructor_t<535>;
};

template <class KeyT, class AccumT>
struct sm80_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::no, primitive_accum::yes, key_size::_16, accum_size::_8>
{
  static constexpr int threads                       = 192;
  static constexpr int items                         = 7;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_DIRECT;
  using delay_constructor                            = detail::no_delay_constructor_t<1035>;
};

template <class KeyT, class AccumT>
struct sm80_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::no, primitive_accum::no, key_size::_16, accum_size::_16>
{
  static constexpr int threads                       = 128;
  static constexpr int items                         = 11;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_WARP_TRANSPOSE;
  using delay_constructor                            = detail::no_delay_constructor_t<1090>;
};

// TODO(bgruber): remove in CCCL 4.0 when we drop the reduce-by-key dispatchers
template <class KeyT,
          class AccumT,
          primitive_op PrimitiveOp,
          primitive_key PrimitiveKey     = is_primitive_key<KeyT>(),
          primitive_accum PrimitiveAccum = is_primitive_accum<AccumT>(),
          key_size KeySize               = classify_key_size<KeyT>(),
          accum_size AccumSize           = classify_accum_size<AccumT>()>
struct sm90_tuning;

// 8-bit key
template <class KeyT, class AccumT>
struct sm90_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::yes, key_size::_1, accum_size::_1>
{
  static constexpr int threads                       = 256;
  static constexpr int items                         = 13;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_DIRECT;
  using delay_constructor                            = detail::no_delay_constructor_t<720>;
};

template <class KeyT, class AccumT>
struct sm90_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::yes, key_size::_1, accum_size::_2>
{
  static constexpr int threads                       = 320;
  static constexpr int items                         = 23;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_DIRECT;
  using delay_constructor                            = detail::no_delay_constructor_t<865>;
};

template <class KeyT, class AccumT>
struct sm90_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::yes, key_size::_1, accum_size::_4>
{
  static constexpr int threads                       = 192;
  static constexpr int items                         = 14;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_WARP_TRANSPOSE;
  using delay_constructor                            = detail::no_delay_constructor_t<735>;
};

template <class KeyT, class AccumT>
struct sm90_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::yes, key_size::_1, accum_size::_8>
{
  static constexpr int threads                       = 128;
  static constexpr int items                         = 13;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_WARP_TRANSPOSE;
  using delay_constructor                            = detail::no_delay_constructor_t<580>;
};

template <class KeyT, class AccumT>
struct sm90_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::no, key_size::_1, accum_size::_16>
{
  static constexpr int threads                       = 128;
  static constexpr int items                         = 11;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_WARP_TRANSPOSE;
  using delay_constructor                            = detail::no_delay_constructor_t<1100>;
};

// 16-bit key
template <class KeyT, class AccumT>
struct sm90_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::yes, key_size::_2, accum_size::_1>
{
  static constexpr int threads                       = 128;
  static constexpr int items                         = 23;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_DIRECT;
  using delay_constructor                            = detail::no_delay_constructor_t<985>;
};

template <class KeyT, class AccumT>
struct sm90_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::yes, key_size::_2, accum_size::_2>
{
  static constexpr int threads                       = 256;
  static constexpr int items                         = 11;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_DIRECT;
  using delay_constructor                            = detail::fixed_delay_constructor_t<276, 650>;
};

template <class KeyT, class AccumT>
struct sm90_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::yes, key_size::_2, accum_size::_4>
{
  static constexpr int threads                       = 256;
  static constexpr int items                         = 14;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_WARP_TRANSPOSE;
  using delay_constructor                            = detail::fixed_delay_constructor_t<240, 765>;
};

template <class KeyT, class AccumT>
struct sm90_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::yes, key_size::_2, accum_size::_8>
{
  static constexpr int threads                       = 128;
  static constexpr int items                         = 19;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_WARP_TRANSPOSE;
  using delay_constructor                            = detail::no_delay_constructor_t<1190>;
};

template <class KeyT, class AccumT>
struct sm90_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::no, key_size::_2, accum_size::_16>
{
  static constexpr int threads                       = 128;
  static constexpr int items                         = 11;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_WARP_TRANSPOSE;
  using delay_constructor                            = detail::no_delay_constructor_t<1175>;
};

// 32-bit key
template <class KeyT, class AccumT>
struct sm90_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::yes, key_size::_4, accum_size::_1>
{
  static constexpr int threads                       = 256;
  static constexpr int items                         = 13;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_DIRECT;
  using delay_constructor                            = detail::fixed_delay_constructor_t<404, 645>;
};

template <class KeyT, class AccumT>
struct sm90_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::yes, key_size::_4, accum_size::_2>
{
  static constexpr int threads                       = 256;
  static constexpr int items                         = 18;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_WARP_TRANSPOSE;
  using delay_constructor                            = detail::no_delay_constructor_t<1160>;
};

template <class KeyT, class AccumT>
struct sm90_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::yes, key_size::_4, accum_size::_4>
{
  static constexpr int threads                       = 256;
  static constexpr int items                         = 18;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_WARP_TRANSPOSE;
  using delay_constructor                            = detail::no_delay_constructor_t<1170>;
};

template <class KeyT, class AccumT>
struct sm90_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::yes, key_size::_4, accum_size::_8>
{
  static constexpr int threads                       = 128;
  static constexpr int items                         = 13;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_WARP_TRANSPOSE;
  using delay_constructor                            = detail::no_delay_constructor_t<1055>;
};

template <class KeyT, class AccumT>
struct sm90_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::no, key_size::_4, accum_size::_16>
{
  static constexpr int threads                       = 128;
  static constexpr int items                         = 11;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_WARP_TRANSPOSE;
  using delay_constructor                            = detail::no_delay_constructor_t<1195>;
};

// 64-bit key
template <class KeyT, class AccumT>
struct sm90_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::yes, key_size::_8, accum_size::_1>
{
  static constexpr int threads                       = 256;
  static constexpr int items                         = 10;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_DIRECT;
  using delay_constructor                            = detail::no_delay_constructor_t<1170>;
};

template <class KeyT, class AccumT>
struct sm90_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::yes, key_size::_8, accum_size::_2>
{
  static constexpr int threads                       = 256;
  static constexpr int items                         = 9;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_DIRECT;
  using delay_constructor                            = detail::fixed_delay_constructor_t<236, 1030>;
};

template <class KeyT, class AccumT>
struct sm90_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::yes, key_size::_8, accum_size::_4>
{
  static constexpr int threads                       = 128;
  static constexpr int items                         = 13;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_WARP_TRANSPOSE;
  using delay_constructor                            = detail::fixed_delay_constructor_t<152, 560>;
};

template <class KeyT, class AccumT>
struct sm90_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::yes, key_size::_8, accum_size::_8>
{
  static constexpr int threads                       = 128;
  static constexpr int items                         = 23;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_WARP_TRANSPOSE;
  using delay_constructor                            = detail::no_delay_constructor_t<1030>;
};

template <class KeyT, class AccumT>
struct sm90_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::no, key_size::_8, accum_size::_16>
{
  static constexpr int threads                       = 128;
  static constexpr int items                         = 11;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_WARP_TRANSPOSE;
  using delay_constructor                            = detail::no_delay_constructor_t<1125>;
};

// 128-bit key
template <class KeyT, class AccumT>
struct sm90_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::no, primitive_accum::yes, key_size::_16, accum_size::_1>
{
  static constexpr int threads                       = 128;
  static constexpr int items                         = 11;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_WARP_TRANSPOSE;
  using delay_constructor                            = detail::no_delay_constructor_t<1080>;
};

template <class KeyT, class AccumT>
struct sm90_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::no, primitive_accum::yes, key_size::_16, accum_size::_2>
{
  static constexpr int threads                       = 128;
  static constexpr int items                         = 11;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_WARP_TRANSPOSE;
  using delay_constructor                            = detail::fixed_delay_constructor_t<320, 1005>;
};

template <class KeyT, class AccumT>
struct sm90_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::no, primitive_accum::yes, key_size::_16, accum_size::_4>
{
  static constexpr int threads                       = 128;
  static constexpr int items                         = 11;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_WARP_TRANSPOSE;
  using delay_constructor                            = detail::fixed_delay_constructor_t<232, 1100>;
};

template <class KeyT, class AccumT>
struct sm90_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::no, primitive_accum::yes, key_size::_16, accum_size::_8>
{
  static constexpr int threads                       = 128;
  static constexpr int items                         = 11;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_WARP_TRANSPOSE;
  using delay_constructor                            = detail::no_delay_constructor_t<1195>;
};

template <class KeyT, class AccumT>
struct sm90_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::no, primitive_accum::no, key_size::_16, accum_size::_16>
{
  static constexpr int threads                       = 128;
  static constexpr int items                         = 11;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_WARP_TRANSPOSE;
  using delay_constructor                            = detail::no_delay_constructor_t<1150>;
};

// TODO(bgruber): remove in CCCL 4.0 when we drop the reduce-by-key dispatchers
template <class KeyT,
          class AccumT,
          primitive_op PrimitiveOp,
          primitive_key PrimitiveKey     = is_primitive_key<KeyT>(),
          primitive_accum PrimitiveAccum = is_primitive_accum<AccumT>(),
          key_size KeySize               = classify_key_size<KeyT>(),
          accum_size AccumSize           = classify_accum_size<AccumT>()>
struct sm100_tuning;

// 8-bit key
template <class KeyT, class AccumT>
struct sm100_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::yes, key_size::_1, accum_size::_1>
{
  // ipt_13.tpb_576.trp_0.ld_1.ns_2044.dcid_5.l2w_240 1.161888  0.848558  1.134941  1.299109
  static constexpr int items                         = 13;
  static constexpr int threads                       = 576;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_DIRECT;
  using delay_constructor                            = exponential_backon_jitter_window_constructor_t<2044, 240>;
  static constexpr CacheLoadModifier load_modifier   = LOAD_CA;
};

template <class KeyT, class AccumT>
struct sm100_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::yes, key_size::_1, accum_size::_2>
{
  // ipt_10.tpb_224.trp_0.ld_0.ns_244.dcid_4.l2w_390 1.313932  1.260540  1.319588  1.427374
  static constexpr int items                         = 10;
  static constexpr int threads                       = 224;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_DIRECT;
  using delay_constructor                            = exponential_backoff_jitter_window_constructor_t<224, 390>;
  static constexpr CacheLoadModifier load_modifier   = LOAD_DEFAULT;
};

template <class KeyT, class AccumT>
struct sm100_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::yes, key_size::_1, accum_size::_4>
{
  // ipt_14.tpb_128.trp_0.ld_0.ns_248.dcid_2.l2w_285  1.118109  1.051534  1.134336  1.326788
  static constexpr int items                         = 14;
  static constexpr int threads                       = 128;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_DIRECT;
  using delay_constructor                            = exponential_backoff_constructor_t<248, 285>;
  static constexpr CacheLoadModifier load_modifier   = LOAD_DEFAULT;
};

template <class KeyT, class AccumT>
struct sm100_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::yes, key_size::_1, accum_size::_8>
{
  // ipt_19.tpb_128.trp_1.ld_0.ns_132.dcid_1.l2w_540 1.113820  1.002404  1.105014  1.202296
  static constexpr int items                         = 19;
  static constexpr int threads                       = 128;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_WARP_TRANSPOSE;
  using delay_constructor                            = fixed_delay_constructor_t<132, 540>;
  static constexpr CacheLoadModifier load_modifier   = LOAD_DEFAULT;
};

// todo(gonidelis): Add tunings for I128.
// template <class KeyT, class AccumT>
// struct sm100_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::no, key_size::_1,
// accum_size::_16>
// {
// static constexpr int threads                       = 128;
// static constexpr int items                         = 11;
// static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_WARP_TRANSPOSE;
// using delay_constructor                            = detail::no_delay_constructor_t<1100>;
// };

// 16-bit key
template <class KeyT, class AccumT>
struct sm100_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::yes, key_size::_2, accum_size::_1>
{
  // ipt_14.tpb_128.trp_1.ld_0.ns_164.dcid_2.l2w_290 1.239579  1.119705  1.239111  1.313112
  static constexpr int items                         = 14;
  static constexpr int threads                       = 128;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_WARP_TRANSPOSE;
  using delay_constructor                            = detail::exponential_backoff_constructor_t<164, 290>;
  static constexpr CacheLoadModifier load_modifier   = LOAD_DEFAULT;
};

template <class KeyT, class AccumT>
struct sm100_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::yes, key_size::_2, accum_size::_2>
{
  // ipt_14.tpb_256.trp_1.ld_0.ns_180.dcid_2.l2w_975 1.145635  1.012658  1.139956  1.251546
  static constexpr int items                         = 14;
  static constexpr int threads                       = 256;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_WARP_TRANSPOSE;
  using delay_constructor                            = exponential_backoff_constructor_t<180, 975>;
  static constexpr CacheLoadModifier load_modifier   = LOAD_DEFAULT;
};

template <class KeyT, class AccumT>
struct sm100_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::yes, key_size::_2, accum_size::_4>
{
  // ipt_11.tpb_256.trp_0.ld_0.ns_224.dcid_2.l2w_550 1.066293  1.000109  1.073092  1.181818
  static constexpr int items                         = 11;
  static constexpr int threads                       = 256;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_DIRECT;
  using delay_constructor                            = exponential_backoff_constructor_t<224, 550>;
  static constexpr CacheLoadModifier load_modifier   = LOAD_DEFAULT;
};

template <class KeyT, class AccumT>
struct sm100_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::yes, key_size::_2, accum_size::_8>
{
  // ipt_10.tpb_160.trp_1.ld_0.ns_156.dcid_1.l2w_725 1.045007  1.002105  1.049690  1.141827
  static constexpr int items                         = 10;
  static constexpr int threads                       = 160;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_WARP_TRANSPOSE;
  using delay_constructor                            = fixed_delay_constructor_t<156, 725>;
  static constexpr CacheLoadModifier load_modifier   = LOAD_DEFAULT;
};

// I16, F32, I32 regresses, default it back.
template <class KeyT>
struct sm100_tuning<KeyT, float, primitive_op::yes, primitive_key::yes, primitive_accum::yes, key_size::_2, accum_size::_4>
{};

// todo(gonidelis): Add tunings for I128.
// template <class KeyT, class AccumT>
// struct sm100_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::no, key_size::_2,
// accum_size::_16>
// {
// static constexpr int threads                       = 128;
// static constexpr int items                         = 11;
// static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_WARP_TRANSPOSE;
// using delay_constructor                            = detail::no_delay_constructor_t<1100>;
// };

// 32-bit key
template <class KeyT, class AccumT>
struct sm100_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::yes, key_size::_4, accum_size::_1>
{
  // ipt_10.tpb_224.trp_0.ld_0.ns_324.dcid_2.l2w_285 1.157217  1.073724  1.166510  1.356940
  static constexpr int items                         = 10;
  static constexpr int threads                       = 224;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_DIRECT;
  using delay_constructor                            = exponential_backoff_constructor_t<324, 285>;
  static constexpr CacheLoadModifier load_modifier   = LOAD_DEFAULT;
};

template <class KeyT, class AccumT>
struct sm100_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::yes, key_size::_4, accum_size::_2>
{
  // ipt_11.tpb_256.trp_0.ld_0.ns_1984.dcid_5.l2w_115 1.214155  1.128842  1.214093  1.364476
  static constexpr int items                         = 11;
  static constexpr int threads                       = 256;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_DIRECT;
  using delay_constructor                            = exponential_backon_jitter_window_constructor_t<1984, 115>;
  static constexpr CacheLoadModifier load_modifier   = LOAD_DEFAULT;
};

template <class KeyT, class AccumT>
struct sm100_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::yes, key_size::_4, accum_size::_4>
{
  // ipt_14.tpb_224.trp_1.ld_0.ns_476.dcid_5.l2w_1005 1.187378  1.119705  1.185397  1.258420
  static constexpr int items                         = 14;
  static constexpr int threads                       = 224;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_WARP_TRANSPOSE;
  using delay_constructor                            = exponential_backon_jitter_window_constructor_t<476, 1005>;
  static constexpr CacheLoadModifier load_modifier   = LOAD_DEFAULT;
};

template <class KeyT, class AccumT>
struct sm100_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::yes, key_size::_4, accum_size::_8>
{
  // ipt_10.tpb_256.trp_1.ld_0.ns_1868.dcid_7.l2w_145 1.142915  1.020581  1.137459  1.237913
  static constexpr int items                         = 10;
  static constexpr int threads                       = 256;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_WARP_TRANSPOSE;
  using delay_constructor                            = exponential_backon_constructor_t<1868, 145>;
  static constexpr CacheLoadModifier load_modifier   = LOAD_DEFAULT;
};

// todo(gonidelis): Add tunings for I128.
// template <class KeyT, class AccumT>
// struct sm100_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::no, key_size::_4,
// accum_size::_16>
// {
// static constexpr int threads                       = 128;
// static constexpr int items                         = 11;
// static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_WARP_TRANSPOSE;
// using delay_constructor                            = detail::no_delay_constructor_t<1100>;
// };

// 64-bit key
template <class KeyT, class AccumT>
struct sm100_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::yes, key_size::_8, accum_size::_1>
{
  // ipt_9.tpb_224.trp_1.ld_0.ns_1940.dcid_5.l2w_460 1.157294  1.075650  1.153566  1.250729
  static constexpr int items                         = 9;
  static constexpr int threads                       = 224;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_WARP_TRANSPOSE;
  using delay_constructor                            = exponential_backon_jitter_window_constructor_t<1940, 460>;
  static constexpr CacheLoadModifier load_modifier   = LOAD_DEFAULT;
};

template <class KeyT, class AccumT>
struct sm100_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::yes, key_size::_8, accum_size::_2>
{
  // ipt_11.tpb_224.trp_1.ld_1.ns_392.dcid_2.l2w_550 1.104034  1.007212  1.099543  1.220401
  static constexpr int items                         = 11;
  static constexpr int threads                       = 224;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_WARP_TRANSPOSE;
  using delay_constructor                            = exponential_backoff_constructor_t<392, 550>;
  static constexpr CacheLoadModifier load_modifier   = LOAD_CA;
};

template <class KeyT, class AccumT>
struct sm100_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::yes, key_size::_8, accum_size::_4>
{
  // ipt_9.tpb_224.trp_1.ld_0.ns_244.dcid_2.l2w_475 1.130098  1.000000  1.130661  1.215722
  static constexpr int items                         = 9;
  static constexpr int threads                       = 224;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_WARP_TRANSPOSE;
  using delay_constructor                            = exponential_backoff_constructor_t<244, 475>;
  static constexpr CacheLoadModifier load_modifier   = LOAD_DEFAULT;
};

template <class KeyT, class AccumT>
struct sm100_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::yes, key_size::_8, accum_size::_8>
{
  // ipt_9.tpb_224.trp_1.ld_0.ns_196.dcid_2.l2w_340 1.272056  1.142857  1.262499  1.352941
  static constexpr int items                         = 9;
  static constexpr int threads                       = 224;
  static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_WARP_TRANSPOSE;
  using delay_constructor                            = exponential_backoff_constructor_t<196, 340>;
  static constexpr CacheLoadModifier load_modifier   = LOAD_DEFAULT;
};

// todo(gonidelis): Add tunings for I128.
// template <class KeyT, class AccumT>
// struct sm100_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::no, key_size::_8,
// accum_size::_16>
// {
//   static constexpr int threads                       = 128;
//   static constexpr int items                         = 11;
//   static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_WARP_TRANSPOSE;
//   using delay_constructor                            = detail::no_delay_constructor_t<1125>;
// };

// todo(gonidelis): Add tunings for 128-bit key.
// 128-bit key
// template <class KeyT, class AccumT>
// struct sm90_tuning<KeyT, AccumT, primitive_op::yes, primitive_key::yes, primitive_accum::no, key_size::_16,
// accum_size::_1>
// {
//   static constexpr int threads                       = 128;
//   static constexpr int items                         = 11;
//   static constexpr BlockLoadAlgorithm load_algorithm = BLOCK_LOAD_WARP_TRANSPOSE;
//   using delay_constructor                            = detail::no_delay_constructor_t<1125>;
// };

// TODO(bgruber): remove in CCCL 4.0 when we drop the reduce-by-key dispatchers
template <class ReductionOpT, class AccumT, class KeyT>
struct policy_hub
{
  static constexpr int max_input_bytes      = static_cast<int>((::cuda::std::max) (sizeof(KeyT), sizeof(AccumT)));
  static constexpr int combined_input_bytes = sizeof(KeyT) + sizeof(AccumT);

  template <CacheLoadModifier LoadModifier>
  struct DefaultPolicy
  {
    static constexpr int nominal_4B_items_per_thread = 6;
    static constexpr int items_per_thread =
      (max_input_bytes <= 8)
        ? 6
        : ::cuda::std::clamp(
            ::cuda::ceil_div(nominal_4B_items_per_thread * 8, combined_input_bytes), 1, nominal_4B_items_per_thread);

    using ReduceByKeyPolicyT =
      agent_reduce_by_key_policy<128,
                                 items_per_thread,
                                 BLOCK_LOAD_DIRECT,
                                 LoadModifier,
                                 BLOCK_SCAN_WARP_SCANS,
                                 default_reduce_by_key_delay_constructor_t<AccumT, int>>;
  };

  // nvbug5935129: GCC-11.2 cannot directly use DefaultPolicy inside Policy500
  using DefaultPolicy500 = DefaultPolicy<LOAD_LDG>;

  struct Policy500
      : DefaultPolicy500
      , detail::chained_policy<500, Policy500, Policy500>
  {};

  // Use values from tuning if a specialization exists, otherwise pick DefaultPolicy
  template <typename Tuning>
  static auto select_agent_policy(int)
    -> agent_reduce_by_key_policy<Tuning::threads,
                                  Tuning::items,
                                  Tuning::load_algorithm,
                                  LOAD_DEFAULT,
                                  BLOCK_SCAN_WARP_SCANS,
                                  typename Tuning::delay_constructor>;

  template <typename Tuning>
  static auto select_agent_policy(long) -> typename DefaultPolicy<LOAD_DEFAULT>::ReduceByKeyPolicyT;

  struct Policy800 : detail::chained_policy<800, Policy800, Policy500>
  {
    using ReduceByKeyPolicyT =
      decltype(select_agent_policy<sm80_tuning<KeyT, AccumT, is_primitive_op<ReductionOpT>()>>(0));
  };

  // nvbug5935129: GCC-11.2 cannot directly use DefaultPolicy inside Policy860
  using DefaultPolicy860 = DefaultPolicy<LOAD_LDG>;

  struct Policy860
      : DefaultPolicy860
      , detail::chained_policy<860, Policy860, Policy800>
  {};

  struct Policy900 : detail::chained_policy<900, Policy900, Policy860>
  {
    using ReduceByKeyPolicyT =
      decltype(select_agent_policy<sm90_tuning<KeyT, AccumT, is_primitive_op<ReductionOpT>()>>(0));
  };

  struct Policy1000 : detail::chained_policy<1000, Policy1000, Policy900>
  {
    // Use values from tuning if a specialization exists, otherwise fall back to SM90
    template <typename Tuning>
    static auto select_agent_policy(int)
      -> agent_reduce_by_key_policy<Tuning::threads,
                                    Tuning::items,
                                    Tuning::load_algorithm,
                                    Tuning::load_modifier,
                                    BLOCK_SCAN_WARP_SCANS,
                                    typename Tuning::delay_constructor>;

    template <typename Tuning>
    static auto select_agent_policy(long) -> typename Policy900::ReduceByKeyPolicyT;

    using ReduceByKeyPolicyT =
      decltype(select_agent_policy<sm100_tuning<KeyT, AccumT, is_primitive_op<ReductionOpT>()>>(0));
  };
  using MaxPolicy = Policy1000;
};

#if _CCCL_HAS_CONCEPTS()
template <typename T>
concept reduce_by_key_policy_selector = detail::policy_selector<T, ReduceByKeyPolicy>;
#endif // _CCCL_HAS_CONCEPTS()

struct policy_selector
{
  int key_size;
  int accum_size;
  type_t accum_t;

  // TODO(bgruber): we want to get rid of the following four and just assume by default that types behave "primitive".
  // This opts a lot more types into the tunings we have. We can do this when we publish the public tuning API, because
  // then users can opt-out of tunings again
  bool key_is_primitive;
  bool key_is_trivially_copyable;
  bool accum_is_primitive;
  bool op_is_primitive;

private:
  [[nodiscard]] _CCCL_HOST_DEVICE_API constexpr auto __make_default_policy(CacheLoadModifier load_mod) const
    -> ReduceByKeyLookbackPolicy
  {
    constexpr int nominal_4B_items_per_thread = 6;
    const int combined_input_bytes            = key_size + accum_size;
    const int max_input_bytes                 = (::cuda::std::max) (key_size, accum_size);
    const int items_per_thread =
      (max_input_bytes <= 8)
        ? 6
        : ::cuda::std::clamp(
            ::cuda::ceil_div(nominal_4B_items_per_thread * 8, combined_input_bytes), 1, nominal_4B_items_per_thread);
    return ReduceByKeyLookbackPolicy{
      128,
      items_per_thread,
      BLOCK_LOAD_DIRECT,
      load_mod,
      BLOCK_SCAN_WARP_SCANS,
      default_reduce_by_key_delay_constructor_policy(
        accum_size, sizeof(int), key_is_primitive || key_is_trivially_copyable, true)};
  }

  [[nodiscard]] _CCCL_HOST_DEVICE_API constexpr auto get_lookback_policy(::cuda::compute_capability cc) const
    -> ReduceByKeyLookbackPolicy
  {
    // bail out if we don't know the operation. TODO(bgruber): drop this check when we make the tuning API public
    if (!op_is_primitive)
    {
      return __make_default_policy(LOAD_LDG);
    }

    const bool use_tuning = (key_is_primitive || key_size == 16) && (accum_is_primitive || accum_size == 16);

    if (cc >= ::cuda::compute_capability{10, 7} && cc < ::cuda::compute_capability{11, 0} && use_tuning)
    {
      if (key_size == 1 && accum_size == 4 && (accum_t == type_t::int32 || accum_t == type_t::uint32))
      {
        // ipt_13.tpb_256.trp_0.ld_1.ns_824.dcid_7.l2w_380 1.203  1.206  1.190  1.190
        return {256,
                13,
                BLOCK_LOAD_DIRECT,
                LOAD_CA,
                BLOCK_SCAN_WARP_SCANS,
                {LookbackDelayAlgorithm::exponential_backon, 824, 380}};
      }
      if (key_size == 2 && accum_size == 4 && (accum_t == type_t::int32 || accum_t == type_t::uint32))
      {
        // ipt_14.tpb_224.trp_0.ld_1.ns_336.dcid_0.l2w_515 1.121  1.112  1.153  1.155
        return {224, 14, BLOCK_LOAD_DIRECT, LOAD_CA, BLOCK_SCAN_WARP_SCANS, {LookbackDelayAlgorithm::no_delay, 0, 515}};
      }
      if (key_size == 4 && accum_size == 4 && accum_t == type_t::float32)
      {
        // ipt_23.tpb_192.trp_1.ld_0.ns_1176.dcid_0.l2w_740 1.015  1.051  1.143  1.141
        return {192,
                23,
                BLOCK_LOAD_WARP_TRANSPOSE,
                LOAD_DEFAULT,
                BLOCK_SCAN_WARP_SCANS,
                {LookbackDelayAlgorithm::no_delay, 0, 740}};
      }
      if (key_size == 4 && accum_size == 4 && (accum_t == type_t::int32 || accum_t == type_t::uint32))
      {
        // ipt_22.tpb_128.trp_1.ld_0.ns_24.dcid_0.l2w_875 1.034  1.005  1.080  1.100
        // ipt_22.tpb_128.trp_1.ld_0.ns_952.dcid_0.l2w_955 0.984  0.986  1.251  1.330
        return {128,
                22,
                BLOCK_LOAD_WARP_TRANSPOSE,
                LOAD_DEFAULT,
                BLOCK_SCAN_WARP_SCANS,
                {LookbackDelayAlgorithm::no_delay, 0, 875}};
      }
      if (key_size == 4 && accum_size == 8 && (accum_t == type_t::int64 || accum_t == type_t::uint64))
      {
        // ipt_22.tpb_128.trp_1.ld_1.ns_144.dcid_5.l2w_795 0.982  1.004  1.212  1.259
        return {128,
                22,
                BLOCK_LOAD_WARP_TRANSPOSE,
                LOAD_CA,
                BLOCK_SCAN_WARP_SCANS,
                {LookbackDelayAlgorithm::exponential_backon_jitter_window, 144, 795}};
      }
      if (key_size == 8 && accum_size == 4 && (accum_t == type_t::int32 || accum_t == type_t::uint32))
      {
        // ipt_23.tpb_128.trp_1.ld_0.ns_132.dcid_0.l2w_960 0.970  1.040  1.245  1.316
        return {128,
                23,
                BLOCK_LOAD_WARP_TRANSPOSE,
                LOAD_DEFAULT,
                BLOCK_SCAN_WARP_SCANS,
                {LookbackDelayAlgorithm::no_delay, 0, 960}};
      }
      if (key_size == 8 && accum_size == 8 && accum_t == type_t::float64)
      {
        // ipt_15.tpb_192.trp_1.ld_1.ns_1996.dcid_0.l2w_645 0.994  1.068  1.083  1.118
        return {192,
                15,
                BLOCK_LOAD_WARP_TRANSPOSE,
                LOAD_CA,
                BLOCK_SCAN_WARP_SCANS,
                {LookbackDelayAlgorithm::no_delay, 0, 645}};
      }
      if (key_size == 8 && accum_size == 8 && (accum_t == type_t::int64 || accum_t == type_t::uint64))
      {
        // ipt_21.tpb_128.trp_1.ld_0.ns_528.dcid_0.l2w_895 0.964  1.053  1.199  1.255
        return {128,
                21,
                BLOCK_LOAD_WARP_TRANSPOSE,
                LOAD_DEFAULT,
                BLOCK_SCAN_WARP_SCANS,
                {LookbackDelayAlgorithm::no_delay, 0, 895}};
      }
      // no tuning found (e.g. 16-byte keys), fall through to the SM100 tunings
    }

    if (cc >= ::cuda::compute_capability{10, 0} && use_tuning) // if we don't have a tuning, fall back to SM90
    {
      if (key_size == 1 && accum_size == 1)
      {
        // ipt_13.tpb_576.trp_0.ld_1.ns_2044.dcid_5.l2w_240 1.161888  0.848558  1.134941  1.299109
        return {576,
                13,
                BLOCK_LOAD_DIRECT,
                LOAD_CA,
                BLOCK_SCAN_WARP_SCANS,
                {LookbackDelayAlgorithm::exponential_backon_jitter_window, 2044, 240}};
      }
      if (key_size == 1 && accum_size == 2)
      {
        // ipt_10.tpb_224.trp_0.ld_0.ns_244.dcid_4.l2w_390 1.313932  1.260540  1.319588  1.427374
        return {224,
                10,
                BLOCK_LOAD_DIRECT,
                LOAD_DEFAULT,
                BLOCK_SCAN_WARP_SCANS,
                {LookbackDelayAlgorithm::exponential_backoff_jitter_window, 224, 390}};
      }
      if (key_size == 1 && accum_size == 4)
      {
        // ipt_14.tpb_128.trp_0.ld_0.ns_248.dcid_2.l2w_285  1.118109  1.051534  1.134336  1.326788
        return {128,
                14,
                BLOCK_LOAD_DIRECT,
                LOAD_DEFAULT,
                BLOCK_SCAN_WARP_SCANS,
                {LookbackDelayAlgorithm::exponential_backoff, 248, 285}};
      }
      if (key_size == 1 && accum_size == 8)
      {
        // ipt_19.tpb_128.trp_1.ld_0.ns_132.dcid_1.l2w_540 1.113820  1.002404  1.105014  1.202296
        return {128,
                19,
                BLOCK_LOAD_WARP_TRANSPOSE,
                LOAD_DEFAULT,
                BLOCK_SCAN_WARP_SCANS,
                {LookbackDelayAlgorithm::fixed_delay, 132, 540}};
      }
      if (key_size == 2 && accum_size == 1)
      {
        // ipt_14.tpb_128.trp_1.ld_0.ns_164.dcid_2.l2w_290 1.239579  1.119705  1.239111  1.313112
        return {128,
                14,
                BLOCK_LOAD_WARP_TRANSPOSE,
                LOAD_DEFAULT,
                BLOCK_SCAN_WARP_SCANS,
                {LookbackDelayAlgorithm::exponential_backoff, 164, 290}};
      }
      if (key_size == 2 && accum_size == 2)
      {
        // ipt_14.tpb_256.trp_1.ld_0.ns_180.dcid_2.l2w_975 1.145635  1.012658  1.139956  1.251546
        return {256,
                14,
                BLOCK_LOAD_WARP_TRANSPOSE,
                LOAD_DEFAULT,
                BLOCK_SCAN_WARP_SCANS,
                {LookbackDelayAlgorithm::exponential_backoff, 180, 975}};
      }
      if (key_size == 2 && accum_size == 4 && accum_t != type_t::float32) // I16, F32, I32 regressed, fall back to SM90
      {
        // ipt_11.tpb_256.trp_0.ld_0.ns_224.dcid_2.l2w_550 1.066293  1.000109  1.073092  1.181818
        return {256,
                11,
                BLOCK_LOAD_DIRECT,
                LOAD_DEFAULT,
                BLOCK_SCAN_WARP_SCANS,
                {LookbackDelayAlgorithm::exponential_backoff, 224, 550}};
      }
      if (key_size == 2 && accum_size == 8)
      {
        // ipt_10.tpb_160.trp_1.ld_0.ns_156.dcid_1.l2w_725 1.045007  1.002105  1.049690  1.141827
        return {160,
                10,
                BLOCK_LOAD_WARP_TRANSPOSE,
                LOAD_DEFAULT,
                BLOCK_SCAN_WARP_SCANS,
                {LookbackDelayAlgorithm::fixed_delay, 156, 725}};
      }
      if (key_size == 4 && accum_size == 1)
      {
        // ipt_10.tpb_224.trp_0.ld_0.ns_324.dcid_2.l2w_285 1.157217  1.073724  1.166510  1.356940
        return {224,
                10,
                BLOCK_LOAD_DIRECT,
                LOAD_DEFAULT,
                BLOCK_SCAN_WARP_SCANS,
                {LookbackDelayAlgorithm::exponential_backoff, 324, 285}};
      }
      if (key_size == 4 && accum_size == 2)
      {
        // ipt_11.tpb_256.trp_0.ld_0.ns_1984.dcid_5.l2w_115 1.214155  1.128842  1.214093  1.364476
        return {256,
                11,
                BLOCK_LOAD_DIRECT,
                LOAD_DEFAULT,
                BLOCK_SCAN_WARP_SCANS,
                {LookbackDelayAlgorithm::exponential_backon_jitter_window, 1984, 115}};
      }
      if (key_size == 4 && accum_size == 4)
      {
        // ipt_14.tpb_224.trp_1.ld_0.ns_476.dcid_5.l2w_1005 1.187378  1.119705  1.185397  1.258420
        return {224,
                14,
                BLOCK_LOAD_WARP_TRANSPOSE,
                LOAD_DEFAULT,
                BLOCK_SCAN_WARP_SCANS,
                {LookbackDelayAlgorithm::exponential_backon_jitter_window, 476, 1005}};
      }
      if (key_size == 4 && accum_size == 8)
      {
        // ipt_10.tpb_256.trp_1.ld_0.ns_1868.dcid_7.l2w_145 1.142915  1.020581  1.137459  1.237913
        return {256,
                10,
                BLOCK_LOAD_WARP_TRANSPOSE,
                LOAD_DEFAULT,
                BLOCK_SCAN_WARP_SCANS,
                {LookbackDelayAlgorithm::exponential_backon, 1868, 145}};
      }
      if (key_size == 8 && accum_size == 1)
      {
        // ipt_9.tpb_224.trp_1.ld_0.ns_1940.dcid_5.l2w_460 1.157294  1.075650  1.153566  1.250729
        return {224,
                9,
                BLOCK_LOAD_WARP_TRANSPOSE,
                LOAD_DEFAULT,
                BLOCK_SCAN_WARP_SCANS,
                {LookbackDelayAlgorithm::exponential_backon_jitter_window, 1940, 460}};
      }
      if (key_size == 8 && accum_size == 2)
      {
        // ipt_11.tpb_224.trp_1.ld_1.ns_392.dcid_2.l2w_550 1.104034  1.007212  1.099543  1.220401
        return {224,
                11,
                BLOCK_LOAD_WARP_TRANSPOSE,
                LOAD_CA,
                BLOCK_SCAN_WARP_SCANS,
                {LookbackDelayAlgorithm::exponential_backoff, 392, 550}};
      }
      if (key_size == 8 && accum_size == 4)
      {
        // ipt_9.tpb_224.trp_1.ld_0.ns_244.dcid_2.l2w_475 1.130098  1.000000  1.130661  1.215722
        return {224,
                9,
                BLOCK_LOAD_WARP_TRANSPOSE,
                LOAD_DEFAULT,
                BLOCK_SCAN_WARP_SCANS,
                {LookbackDelayAlgorithm::exponential_backoff, 244, 475}};
      }
      if (key_size == 8 && accum_size == 8)
      {
        // ipt_9.tpb_224.trp_1.ld_0.ns_196.dcid_2.l2w_340 1.272056  1.142857  1.262499  1.352941
        return {224,
                9,
                BLOCK_LOAD_WARP_TRANSPOSE,
                LOAD_DEFAULT,
                BLOCK_SCAN_WARP_SCANS,
                {LookbackDelayAlgorithm::exponential_backoff, 196, 340}};
      }
    }

    if (cc >= ::cuda::compute_capability{9, 0})
    {
      if (use_tuning)
      {
        if (key_size == 1 && accum_size == 1)
        {
          return {
            256, 13, BLOCK_LOAD_DIRECT, LOAD_DEFAULT, BLOCK_SCAN_WARP_SCANS, {LookbackDelayAlgorithm::no_delay, 0, 720}};
        }
        if (key_size == 1 && accum_size == 2)
        {
          return {
            320, 23, BLOCK_LOAD_DIRECT, LOAD_DEFAULT, BLOCK_SCAN_WARP_SCANS, {LookbackDelayAlgorithm::no_delay, 0, 865}};
        }
        if (key_size == 1 && accum_size == 4)
        {
          return {192,
                  14,
                  BLOCK_LOAD_WARP_TRANSPOSE,
                  LOAD_DEFAULT,
                  BLOCK_SCAN_WARP_SCANS,
                  {LookbackDelayAlgorithm::no_delay, 0, 735}};
        }
        if (key_size == 1 && accum_size == 8)
        {
          return {128,
                  13,
                  BLOCK_LOAD_WARP_TRANSPOSE,
                  LOAD_DEFAULT,
                  BLOCK_SCAN_WARP_SCANS,
                  {LookbackDelayAlgorithm::no_delay, 0, 580}};
        }
        if (key_size == 1 && accum_size == 16)
        {
          return {128,
                  11,
                  BLOCK_LOAD_WARP_TRANSPOSE,
                  LOAD_DEFAULT,
                  BLOCK_SCAN_WARP_SCANS,
                  {LookbackDelayAlgorithm::no_delay, 0, 1100}};
        }
        if (key_size == 2 && accum_size == 1)
        {
          return {
            128, 23, BLOCK_LOAD_DIRECT, LOAD_DEFAULT, BLOCK_SCAN_WARP_SCANS, {LookbackDelayAlgorithm::no_delay, 0, 985}};
        }
        if (key_size == 2 && accum_size == 2)
        {
          return {256,
                  11,
                  BLOCK_LOAD_DIRECT,
                  LOAD_DEFAULT,
                  BLOCK_SCAN_WARP_SCANS,
                  {LookbackDelayAlgorithm::fixed_delay, 276, 650}};
        }
        if (key_size == 2 && accum_size == 4)
        {
          return {256,
                  14,
                  BLOCK_LOAD_WARP_TRANSPOSE,
                  LOAD_DEFAULT,
                  BLOCK_SCAN_WARP_SCANS,
                  {LookbackDelayAlgorithm::fixed_delay, 240, 765}};
        }
        if (key_size == 2 && accum_size == 8)
        {
          return {128,
                  19,
                  BLOCK_LOAD_WARP_TRANSPOSE,
                  LOAD_DEFAULT,
                  BLOCK_SCAN_WARP_SCANS,
                  {LookbackDelayAlgorithm::no_delay, 0, 1190}};
        }
        if (key_size == 2 && accum_size == 16)
        {
          return {128,
                  11,
                  BLOCK_LOAD_WARP_TRANSPOSE,
                  LOAD_DEFAULT,
                  BLOCK_SCAN_WARP_SCANS,
                  {LookbackDelayAlgorithm::no_delay, 0, 1175}};
        }
        if (key_size == 4 && accum_size == 1)
        {
          return {256,
                  13,
                  BLOCK_LOAD_DIRECT,
                  LOAD_DEFAULT,
                  BLOCK_SCAN_WARP_SCANS,
                  {LookbackDelayAlgorithm::fixed_delay, 404, 645}};
        }
        if (key_size == 4 && accum_size == 2)
        {
          return {256,
                  18,
                  BLOCK_LOAD_WARP_TRANSPOSE,
                  LOAD_DEFAULT,
                  BLOCK_SCAN_WARP_SCANS,
                  {LookbackDelayAlgorithm::no_delay, 0, 1160}};
        }
        if (key_size == 4 && accum_size == 4)
        {
          return {256,
                  18,
                  BLOCK_LOAD_WARP_TRANSPOSE,
                  LOAD_DEFAULT,
                  BLOCK_SCAN_WARP_SCANS,
                  {LookbackDelayAlgorithm::no_delay, 0, 1170}};
        }
        if (key_size == 4 && accum_size == 8)
        {
          return {128,
                  13,
                  BLOCK_LOAD_WARP_TRANSPOSE,
                  LOAD_DEFAULT,
                  BLOCK_SCAN_WARP_SCANS,
                  {LookbackDelayAlgorithm::no_delay, 0, 1055}};
        }
        if (key_size == 4 && accum_size == 16)
        {
          return {128,
                  11,
                  BLOCK_LOAD_WARP_TRANSPOSE,
                  LOAD_DEFAULT,
                  BLOCK_SCAN_WARP_SCANS,
                  {LookbackDelayAlgorithm::no_delay, 0, 1195}};
        }
        if (key_size == 8 && accum_size == 1)
        {
          return {256,
                  10,
                  BLOCK_LOAD_DIRECT,
                  LOAD_DEFAULT,
                  BLOCK_SCAN_WARP_SCANS,
                  {LookbackDelayAlgorithm::no_delay, 0, 1170}};
        }
        if (key_size == 8 && accum_size == 2)
        {
          return {256,
                  9,
                  BLOCK_LOAD_DIRECT,
                  LOAD_DEFAULT,
                  BLOCK_SCAN_WARP_SCANS,
                  {LookbackDelayAlgorithm::fixed_delay, 236, 1030}};
        }
        if (key_size == 8 && accum_size == 4)
        {
          return {128,
                  13,
                  BLOCK_LOAD_WARP_TRANSPOSE,
                  LOAD_DEFAULT,
                  BLOCK_SCAN_WARP_SCANS,
                  {LookbackDelayAlgorithm::fixed_delay, 152, 560}};
        }
        if (key_size == 8 && accum_size == 8)
        {
          return {128,
                  23,
                  BLOCK_LOAD_WARP_TRANSPOSE,
                  LOAD_DEFAULT,
                  BLOCK_SCAN_WARP_SCANS,
                  {LookbackDelayAlgorithm::no_delay, 0, 1030}};
        }
        if (key_size == 8 && accum_size == 16)
        {
          return {128,
                  11,
                  BLOCK_LOAD_WARP_TRANSPOSE,
                  LOAD_DEFAULT,
                  BLOCK_SCAN_WARP_SCANS,
                  {LookbackDelayAlgorithm::no_delay, 0, 1125}};
        }
        if (key_size == 16 && accum_size == 1)
        {
          return {128,
                  11,
                  BLOCK_LOAD_WARP_TRANSPOSE,
                  LOAD_DEFAULT,
                  BLOCK_SCAN_WARP_SCANS,
                  {LookbackDelayAlgorithm::no_delay, 0, 1080}};
        }
        if (key_size == 16 && accum_size == 2)
        {
          return {128,
                  11,
                  BLOCK_LOAD_WARP_TRANSPOSE,
                  LOAD_DEFAULT,
                  BLOCK_SCAN_WARP_SCANS,
                  {LookbackDelayAlgorithm::fixed_delay, 320, 1005}};
        }
        if (key_size == 16 && accum_size == 4)
        {
          return {128,
                  11,
                  BLOCK_LOAD_WARP_TRANSPOSE,
                  LOAD_DEFAULT,
                  BLOCK_SCAN_WARP_SCANS,
                  {LookbackDelayAlgorithm::fixed_delay, 232, 1100}};
        }
        if (key_size == 16 && accum_size == 8)
        {
          return {128,
                  11,
                  BLOCK_LOAD_WARP_TRANSPOSE,
                  LOAD_DEFAULT,
                  BLOCK_SCAN_WARP_SCANS,
                  {LookbackDelayAlgorithm::no_delay, 0, 1195}};
        }
        if (key_size == 16 && accum_size == 16)
        {
          return {128,
                  11,
                  BLOCK_LOAD_WARP_TRANSPOSE,
                  LOAD_DEFAULT,
                  BLOCK_SCAN_WARP_SCANS,
                  {LookbackDelayAlgorithm::no_delay, 0, 1150}};
        }
      }

      // no tuning, use a default one
      return __make_default_policy(LOAD_DEFAULT);
    }

    if (cc >= ::cuda::compute_capability{8, 6})
    {
      return __make_default_policy(LOAD_LDG);
    }

    if (cc >= ::cuda::compute_capability{8, 0})
    {
      if (use_tuning)
      {
        if (key_size == 1 && accum_size == 1)
        {
          return {
            256, 13, BLOCK_LOAD_DIRECT, LOAD_DEFAULT, BLOCK_SCAN_WARP_SCANS, {LookbackDelayAlgorithm::no_delay, 0, 975}};
        }
        if (key_size == 1 && accum_size == 2)
        {
          return {
            224, 12, BLOCK_LOAD_DIRECT, LOAD_DEFAULT, BLOCK_SCAN_WARP_SCANS, {LookbackDelayAlgorithm::no_delay, 0, 840}};
        }
        if (key_size == 1 && accum_size == 4)
        {
          return {256,
                  15,
                  BLOCK_LOAD_WARP_TRANSPOSE,
                  LOAD_DEFAULT,
                  BLOCK_SCAN_WARP_SCANS,
                  {LookbackDelayAlgorithm::no_delay, 0, 760}};
        }
        if (key_size == 1 && accum_size == 8)
        {
          return {
            224, 7, BLOCK_LOAD_DIRECT, LOAD_DEFAULT, BLOCK_SCAN_WARP_SCANS, {LookbackDelayAlgorithm::no_delay, 0, 1070}};
        }
        if (key_size == 1 && accum_size == 16)
        {
          return {128,
                  9,
                  BLOCK_LOAD_WARP_TRANSPOSE,
                  LOAD_DEFAULT,
                  BLOCK_SCAN_WARP_SCANS,
                  {LookbackDelayAlgorithm::no_delay, 0, 1175}};
        }
        if (key_size == 2 && accum_size == 1)
        {
          return {
            256, 11, BLOCK_LOAD_DIRECT, LOAD_DEFAULT, BLOCK_SCAN_WARP_SCANS, {LookbackDelayAlgorithm::no_delay, 0, 620}};
        }
        if (key_size == 2 && accum_size == 2)
        {
          return {224,
                  14,
                  BLOCK_LOAD_WARP_TRANSPOSE,
                  LOAD_DEFAULT,
                  BLOCK_SCAN_WARP_SCANS,
                  {LookbackDelayAlgorithm::no_delay, 0, 640}};
        }
        if (key_size == 2 && accum_size == 4)
        {
          return {256,
                  14,
                  BLOCK_LOAD_WARP_TRANSPOSE,
                  LOAD_DEFAULT,
                  BLOCK_SCAN_WARP_SCANS,
                  {LookbackDelayAlgorithm::no_delay, 0, 905}};
        }
        if (key_size == 2 && accum_size == 8)
        {
          return {224,
                  9,
                  BLOCK_LOAD_WARP_TRANSPOSE,
                  LOAD_DEFAULT,
                  BLOCK_SCAN_WARP_SCANS,
                  {LookbackDelayAlgorithm::no_delay, 0, 810}};
        }
        if (key_size == 2 && accum_size == 16)
        {
          return {160,
                  9,
                  BLOCK_LOAD_WARP_TRANSPOSE,
                  LOAD_DEFAULT,
                  BLOCK_SCAN_WARP_SCANS,
                  {LookbackDelayAlgorithm::no_delay, 0, 1115}};
        }
        if (key_size == 4 && accum_size == 1)
        {
          return {288,
                  11,
                  BLOCK_LOAD_DIRECT,
                  LOAD_DEFAULT,
                  BLOCK_SCAN_WARP_SCANS,
                  {LookbackDelayAlgorithm::no_delay, 0, 1110}};
        }
        if (key_size == 4 && accum_size == 2)
        {
          return {192,
                  15,
                  BLOCK_LOAD_WARP_TRANSPOSE,
                  LOAD_DEFAULT,
                  BLOCK_SCAN_WARP_SCANS,
                  {LookbackDelayAlgorithm::no_delay, 0, 1200}};
        }
        if (key_size == 4 && accum_size == 4)
        {
          return {256,
                  15,
                  BLOCK_LOAD_DIRECT,
                  LOAD_DEFAULT,
                  BLOCK_SCAN_WARP_SCANS,
                  {LookbackDelayAlgorithm::no_delay, 0, 1110}};
        }
        if (key_size == 4 && accum_size == 8)
        {
          return {224,
                  9,
                  BLOCK_LOAD_WARP_TRANSPOSE,
                  LOAD_DEFAULT,
                  BLOCK_SCAN_WARP_SCANS,
                  {LookbackDelayAlgorithm::no_delay, 0, 1165}};
        }
        if (key_size == 4 && accum_size == 16)
        {
          return {160,
                  9,
                  BLOCK_LOAD_WARP_TRANSPOSE,
                  LOAD_DEFAULT,
                  BLOCK_SCAN_WARP_SCANS,
                  {LookbackDelayAlgorithm::no_delay, 0, 1100}};
        }
        if (key_size == 8 && accum_size == 1)
        {
          return {192,
                  10,
                  BLOCK_LOAD_WARP_TRANSPOSE,
                  LOAD_DEFAULT,
                  BLOCK_SCAN_WARP_SCANS,
                  {LookbackDelayAlgorithm::no_delay, 0, 1175}};
        }
        if (key_size == 8 && accum_size == 2)
        {
          return {
            224, 7, BLOCK_LOAD_DIRECT, LOAD_DEFAULT, BLOCK_SCAN_WARP_SCANS, {LookbackDelayAlgorithm::no_delay, 0, 1075}};
        }
        if (key_size == 8 && accum_size == 4)
        {
          return {
            384, 7, BLOCK_LOAD_DIRECT, LOAD_DEFAULT, BLOCK_SCAN_WARP_SCANS, {LookbackDelayAlgorithm::no_delay, 0, 1040}};
        }
        if (key_size == 8 && accum_size == 8)
        {
          return {128,
                  14,
                  BLOCK_LOAD_WARP_TRANSPOSE,
                  LOAD_DEFAULT,
                  BLOCK_SCAN_WARP_SCANS,
                  {LookbackDelayAlgorithm::no_delay, 0, 1080}};
        }
        if (key_size == 8 && accum_size == 16)
        {
          return {128,
                  11,
                  BLOCK_LOAD_WARP_TRANSPOSE,
                  LOAD_DEFAULT,
                  BLOCK_SCAN_WARP_SCANS,
                  {LookbackDelayAlgorithm::no_delay, 0, 430}};
        }
        if (key_size == 16 && accum_size == 1)
        {
          return {
            192, 7, BLOCK_LOAD_DIRECT, LOAD_DEFAULT, BLOCK_SCAN_WARP_SCANS, {LookbackDelayAlgorithm::no_delay, 0, 1105}};
        }
        if (key_size == 16 && accum_size == 2)
        {
          return {192,
                  7,
                  BLOCK_LOAD_WARP_TRANSPOSE,
                  LOAD_DEFAULT,
                  BLOCK_SCAN_WARP_SCANS,
                  {LookbackDelayAlgorithm::no_delay, 0, 755}};
        }
        if (key_size == 16 && accum_size == 4)
        {
          return {192,
                  7,
                  BLOCK_LOAD_WARP_TRANSPOSE,
                  LOAD_DEFAULT,
                  BLOCK_SCAN_WARP_SCANS,
                  {LookbackDelayAlgorithm::no_delay, 0, 535}};
        }
        if (key_size == 16 && accum_size == 8)
        {
          return {
            192, 7, BLOCK_LOAD_DIRECT, LOAD_DEFAULT, BLOCK_SCAN_WARP_SCANS, {LookbackDelayAlgorithm::no_delay, 0, 1035}};
        }
        if (key_size == 16 && accum_size == 16)
        {
          return {128,
                  11,
                  BLOCK_LOAD_WARP_TRANSPOSE,
                  LOAD_DEFAULT,
                  BLOCK_SCAN_WARP_SCANS,
                  {LookbackDelayAlgorithm::no_delay, 0, 1090}};
        }
      }

      // no tuning, use a default one
      return __make_default_policy(LOAD_DEFAULT);
    }

    // for SM50
    return __make_default_policy(LOAD_LDG);
  }

public:
  [[nodiscard]] _CCCL_HOST_DEVICE_API constexpr auto operator()(::cuda::compute_capability cc) const
    -> ReduceByKeyPolicy
  {
    return ReduceByKeyPolicy{ReduceByKeyAlgorithm::lookback, get_lookback_policy(cc)};
  }
};

#if _CCCL_HAS_CONCEPTS()
static_assert(reduce_by_key_policy_selector<policy_selector>);
#endif // _CCCL_HAS_CONCEPTS()

// TODO(bgruber): remove in CCCL 4.0 when we drop the reduce-by-key dispatchers
template <typename PolicyHub>
struct policy_selector_from_hub
{
  [[nodiscard]] _CCCL_DEVICE_API constexpr auto operator()(::cuda::compute_capability /*cc*/) const -> ReduceByKeyPolicy
  {
    using ReduceByKeyPolicyT = typename PolicyHub::MaxPolicy::ReduceByKeyPolicyT;
    return ReduceByKeyPolicy{
      ReduceByKeyAlgorithm::lookback,
      {
        ReduceByKeyPolicyT::BLOCK_THREADS,
        ReduceByKeyPolicyT::ITEMS_PER_THREAD,
        ReduceByKeyPolicyT::LOAD_ALGORITHM,
        ReduceByKeyPolicyT::LOAD_MODIFIER,
        ReduceByKeyPolicyT::SCAN_ALGORITHM,
        lookback_delay_policy_from_type<typename ReduceByKeyPolicyT::detail::delay_constructor_t>,
      },
    };
  }
};

template <class ReductionOpT, class AccumT, class KeyT>
struct policy_selector_from_types
{
  [[nodiscard]] _CCCL_HOST_DEVICE_API constexpr auto operator()(::cuda::compute_capability cc) const
    -> ReduceByKeyPolicy
  {
    return policy_selector{
      int{sizeof(KeyT)},
      int{sizeof(AccumT)},
      classify_type<AccumT>,
      is_primitive_v<KeyT>,
      ::cuda::is_trivially_copyable_v<KeyT>,
      is_primitive_v<AccumT>,
      basic_binary_op_v<ReductionOpT>}(cc);
  }
};
} // namespace detail::reduce_by_key

CUB_NAMESPACE_END
