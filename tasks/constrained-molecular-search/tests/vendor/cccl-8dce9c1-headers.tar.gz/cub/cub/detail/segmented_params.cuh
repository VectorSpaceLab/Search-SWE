// SPDX-FileCopyrightText: Copyright (c) 2026, NVIDIA CORPORATION. All rights reserved.
// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception

#pragma once

#include <cub/config.cuh>

#if defined(_CCCL_IMPLICIT_SYSTEM_HEADER_GCC)
#  pragma GCC system_header
#elif defined(_CCCL_IMPLICIT_SYSTEM_HEADER_CLANG)
#  pragma clang system_header
#elif defined(_CCCL_IMPLICIT_SYSTEM_HEADER_MSVC)
#  pragma system_header
#endif // no system header

#include <cub/detail/choose_offset.cuh>

#include <cuda/argument>
#include <cuda/std/__algorithm/max.h>
#include <cuda/std/__iterator/concepts.h> // indirectly_readable, random_access_iterator
#include <cuda/std/__type_traits/conditional.h>
#include <cuda/std/__type_traits/integral_constant.h>
#include <cuda/std/__type_traits/is_integer.h> // __cccl_is_integer_v
#include <cuda/std/__type_traits/is_integral.h>
#include <cuda/std/__type_traits/is_same.h>
#include <cuda/std/__type_traits/is_signed.h>
#include <cuda/std/__type_traits/remove_cv.h>
#include <cuda/std/__type_traits/remove_cvref.h>
#include <cuda/std/__utility/cmp.h> // cmp_greater_equal, cmp_less_equal
#include <cuda/std/__utility/forward.h>
#include <cuda/std/cstddef>
#include <cuda/std/cstdint>

CUB_NAMESPACE_BEGIN

namespace detail::params
{
// =====================================================================
// Deferred handle requirements
// =====================================================================

// Rejecting range/container arguments (span, array, ...) is a deliberate narrowing of CUB's API surface, not a
// limitation of the cuda::args annotation framework (which accepts ranges by design): no CUB device API takes a range
// today, and annotating one would be unclear to users (does a bound constrain the element values or the range's
// size?). A revisitable decision -- the traits below accept only dereferenceable handles / random-access iterators.

// A `deferred` is read by dereferencing its handle (`*handle`, see the get_param overload below), so the handle must
// be indirectly readable (a pointer or other dereferenceable handle); use `deferred_sequence` for per-segment values.
template <typename Handle>
inline constexpr bool __is_valid_deferred_handle_v = ::cuda::std::indirectly_readable<Handle>;

// A `deferred_sequence` is indexed per segment (`handle[index]`), so its handle must be a random-access iterator.
template <typename Handle>
inline constexpr bool __is_valid_deferred_sequence_handle_v = ::cuda::std::random_access_iterator<Handle>;

// =====================================================================
// Argument-form validation (compile-time)
// =====================================================================

// Compile-time validation of an integer argument that may be supplied uniformly or per segment (e.g.
// segment_sizes, k), matching how get_param reads it: a deferred handle or a sequence is read element-wise, so its
// `element_type` is the value; a plain value / `constant` / `immediate` is used directly, so its `value_type` is the
// value (which also rejects a handle wrongly wrapped as a single value, e.g. a pointer in `immediate`). Instantiating
// the struct runs the layered static_asserts below (each gated on the previous so a single misuse yields one targeted
// diagnostic); `all_ok` lets the caller gate the downstream dispatch to avoid follow-on cascades. Any argument-specific
// range/bound check is left to the caller.
template <typename Param>
struct __validate_uniform_or_per_segment_integral_param
{
  using args_traits = ::cuda::args::__traits<Param>;

  static constexpr bool is_valid_type = ::cuda::args::__is_wrapper_v<Param> || ::cuda::std::is_integral_v<Param>;

  using __value_t = ::cuda::std::conditional_t<args_traits::is_deferred || !args_traits::is_single_value,
                                               typename args_traits::element_type,
                                               typename args_traits::value_type>;
  static constexpr bool is_integral =
    ::cuda::std::is_integral_v<__value_t> && !::cuda::std::is_same_v<::cuda::std::remove_cvref_t<__value_t>, bool>;

  static constexpr bool is_deferred_single = args_traits::is_deferred && args_traits::is_single_value;
  static constexpr bool is_deferred_seq    = args_traits::is_deferred && !args_traits::is_single_value;
  static constexpr bool handle_ok =
    (!is_deferred_single || __is_valid_deferred_handle_v<typename args_traits::value_type>)
    && (!is_deferred_seq || __is_valid_deferred_sequence_handle_v<typename args_traits::value_type>);

  static constexpr bool all_ok = is_valid_type && is_integral && handle_ok;

  static_assert(is_valid_type,
                "cub: a uniform-or-per-segment integer argument (e.g. cub::DeviceBatchedTopK segment_sizes or k) must "
                "be a cuda::args annotation or a plain integral value (taken as a uniform immediate). A raw pointer or "
                "iterator is not interpreted as a sequence. Wrap per-segment values in cuda::args::deferred_sequence, "
                "or a single device-side value in cuda::args::deferred.");
  static_assert(!is_valid_type || is_integral,
                "cub: a uniform-or-per-segment integer argument (e.g. cub::DeviceBatchedTopK segment_sizes or k) must "
                "have an integral (non-bool) element type (it is a count of items).");
  static_assert(
    !is_valid_type || !is_integral || !is_deferred_single
      || __is_valid_deferred_handle_v<typename args_traits::value_type>,
    "cub: a uniform-or-per-segment integer argument passed via cuda::args::deferred must wrap a pointer or "
    "other dereferenceable handle to a single device-side integral value (it is read via *handle); a range "
    "or container such as span / array is not accepted -- use cuda::args::deferred_sequence for per-segment "
    "values.");
  static_assert(!is_valid_type || !is_integral || !is_deferred_seq
                  || __is_valid_deferred_sequence_handle_v<typename args_traits::value_type>,
                "cub: a uniform-or-per-segment integer argument passed via cuda::args::deferred_sequence must wrap a "
                "random-access iterator (a pointer qualifies) over the per-segment integral values (it is indexed per "
                "segment).");
};

// Compile-time validation of an integer argument that must be a single value, uniform across all segments (e.g.
// num_segments): a per-segment sequence (`deferred_sequence`) is rejected, but a single `deferred` (device-resident)
// value is allowed here. Read like the single-value forms above: a single deferred via *handle (`element_type`),
// everything else directly (`value_type`). A caller that additionally needs the value on the host (e.g. num_segments,
// which sizes the launch) checks `!args_traits::is_deferred` separately. Instantiating the struct runs the layered
// static_asserts (one diagnostic per misuse).
template <typename Param>
struct __validate_uniform_integral_param
{
  using args_traits = ::cuda::args::__traits<Param>;

  static constexpr bool is_valid_type = ::cuda::args::__is_wrapper_v<Param> || ::cuda::std::is_integral_v<Param>;

  static constexpr bool is_single_value    = args_traits::is_single_value;
  static constexpr bool is_deferred_single = args_traits::is_deferred && args_traits::is_single_value;

  using __value_t = ::cuda::std::conditional_t<args_traits::is_deferred || !args_traits::is_single_value,
                                               typename args_traits::element_type,
                                               typename args_traits::value_type>;
  static constexpr bool is_integral =
    ::cuda::std::is_integral_v<__value_t> && !::cuda::std::is_same_v<::cuda::std::remove_cvref_t<__value_t>, bool>;

  static constexpr bool handle_ok =
    !is_deferred_single || __is_valid_deferred_handle_v<typename args_traits::value_type>;

  static constexpr bool all_ok = is_valid_type && is_single_value && is_integral && handle_ok;

  static_assert(is_valid_type,
                "cub: a uniform integer argument (e.g. cub::DeviceBatchedTopK num_segments) must be a cuda::args "
                "annotation or a plain integral value. A raw pointer or iterator is not accepted.");
  static_assert(!is_valid_type || is_single_value,
                "cub: a uniform integer argument (e.g. cub::DeviceBatchedTopK num_segments) must be a single value "
                "(the same for every segment); a per-segment sequence (cuda::args::deferred_sequence) is not "
                "accepted.");
  static_assert(!is_valid_type || !is_single_value || is_integral,
                "cub: a uniform integer argument (e.g. cub::DeviceBatchedTopK num_segments) must have an integral "
                "(non-bool) type.");
  static_assert(!is_valid_type || !is_single_value || !is_integral || handle_ok,
                "cub: a uniform integer argument passed via cuda::args::deferred must wrap a pointer or other "
                "dereferenceable handle to a single device-side integral value (it is read via *handle).");
};

// =====================================================================
// Argument contract checks (debug-only)
// =====================================================================

// Shared debug-only contract check for the argument reads the host cannot validate at call time: a value read on the
// device in stream order from a `deferred`/`deferred_sequence` handle must lie within that argument's *effective*
// bounds -- the intersection of its static `cuda::args::bounds` and any runtime bounds, as computed by
// ::cuda::args::__lowest_/__highest_. A value outside them breaks the caller's promise and is otherwise undefined
// behavior. Compiled out when assertions are disabled (the bounds are not even computed). Gated on the argument's
// integer element type: `bool` and character types are excluded, matching the `cmp_*` comparators.
template <typename Arg, typename Value>
_CCCL_HOST_DEVICE constexpr void
__assert_param_in_bounds([[maybe_unused]] const Arg& __arg, [[maybe_unused]] const Value& __value) noexcept
{
  using __element_t = typename ::cuda::args::__traits<Arg>::element_type;
  if constexpr (::cuda::std::__cccl_is_integer_v<__element_t>)
  {
    const __element_t __checked = static_cast<__element_t>(__value);
    _CCCL_ASSERT(::cuda::std::cmp_greater_equal(__checked, ::cuda::args::__lowest_(__arg))
                   && ::cuda::std::cmp_less_equal(__checked, ::cuda::args::__highest_(__arg)),
                 "cub argument value is outside its declared bounds");
  }
}

// =====================================================================
// get_param — unified segment parameter access
// =====================================================================

//! @brief Returns the value of an argument for a given segment index.
//!
//! @param[in] __arg Argument or argument wrapper to read.
//! @param[in] __index Segment index to read for sequence arguments.
//! @return The single argument value, or the sequence element at the given index.
_CCCL_TEMPLATE(class Tp, class SegmentIndexT)
_CCCL_REQUIRES((!::cuda::args::__is_wrapper_v<::cuda::std::remove_cvref_t<Tp>>) )
[[nodiscard]] _CCCL_HOST_DEVICE constexpr auto get_param(Tp&& __arg, [[maybe_unused]] SegmentIndexT __index) noexcept
{
  if constexpr (::cuda::args::__traits<::cuda::std::remove_cvref_t<Tp>>::is_single_value)
  {
    return __arg;
  }
  else
  {
    return __arg[__index];
  }
}

template <auto Value, typename Tp, typename SegmentIndexT>
[[nodiscard]] _CCCL_HOST_DEVICE constexpr auto
get_param(const ::cuda::args::constant<Value, Tp>& __arg, [[maybe_unused]] SegmentIndexT __index) noexcept
{
  return ::cuda::args::__unwrap(__arg);
}

template <typename Arg, typename StaticBounds, typename SegmentIndexT>
[[nodiscard]] _CCCL_HOST_DEVICE constexpr auto
get_param(const ::cuda::args::immediate<Arg, StaticBounds>& __arg, [[maybe_unused]] SegmentIndexT __index) noexcept
{
  return ::cuda::args::__unwrap(__arg);
}

template <typename Arg, typename StaticBounds, typename SegmentIndexT>
[[nodiscard]] _CCCL_HOST_DEVICE constexpr auto
get_param(const ::cuda::args::deferred<Arg, StaticBounds>& __arg, [[maybe_unused]] SegmentIndexT __index) noexcept
{
  // A single `deferred` wraps a handle to a device-side value (a pointer or input iterator), not the value itself;
  // the value is read on the device by dereferencing the handle. Materialize into the scalar element type: `*handle`
  // may yield a proxy reference that must not leak into the deduced return type (downstream `max`/comparisons would
  // otherwise bind to the proxy).
  using __element_t         = typename ::cuda::args::__traits<::cuda::args::deferred<Arg, StaticBounds>>::element_type;
  const __element_t __value = *::cuda::args::__unwrap(__arg);
  __assert_param_in_bounds(__arg, __value);
  return __value;
}

template <typename Arg, typename StaticBounds, typename SegmentIndexT>
[[nodiscard]] _CCCL_HOST_DEVICE constexpr auto
get_param(const ::cuda::args::deferred_sequence<Arg, StaticBounds>& __arg, SegmentIndexT __index) noexcept
{
  // Materialize into the scalar element type: `handle[index]` may yield a proxy reference that must not leak into the
  // deduced return type.
  using __element_t = typename ::cuda::args::__traits<::cuda::args::deferred_sequence<Arg, StaticBounds>>::element_type;
  const __element_t __value = ::cuda::args::__unwrap(__arg)[__index];
  __assert_param_in_bounds(__arg, __value);
  return __value;
}

// Reads parameter `__index` and, when the argument's static lower bound is negative (e.g. an un-annotated `int16_t` or
// an explicit `bounds` with a negative lower end), clamps a negative runtime value up to 0 in the argument's own
// element type -- before any widening/narrowing cast, so a caller that later widens the result cannot reinterpret a
// negative value as a huge unsigned one. A negative count thus becomes "no work". Deferred forms are range-checked
// against their declared bounds by `get_param` in debug builds.
template <typename Arg, typename SegmentIndexT>
[[nodiscard]] _CCCL_HOST_DEVICE constexpr auto
__get_and_clamp_param_to_nonnegative(const Arg& __arg, SegmentIndexT __index) noexcept
{
  // Materialize into the scalar element type: the generic `get_param` may yield a proxy reference for fancy iterators,
  // and the clamp must act on a real value (a `static_cast<proxy>(0)` would form a null proxy that `max` then
  // dereferences).
  using __element_t         = typename ::cuda::args::__traits<Arg>::element_type;
  const __element_t __value = get_param(__arg, __index);
  constexpr auto __lowest   = ::cuda::args::__traits<Arg>::lowest;
  // Use a plain `<` against a same-typed zero, not the integer-only `cmp_*` comparators (which reject character element
  // types, see `__assert_param_in_bounds`); the `is_signed_v` guard skips the test for unsigned types, whose lower
  // bound is never negative.
  if constexpr (::cuda::std::is_signed_v<__element_t> && __lowest < __element_t{0})
  {
    return (::cuda::std::max) (__value, __element_t{0});
  }
  else
  {
    return __value;
  }
}

//! Smallest unsigned CUB offset type (>= 32-bit) covering @p ParamT's declared static upper bound (from
//! @c cuda::args), via @c detail::choose_offset_for_max_t. The bound is taken as given, never clamped: a bound the
//! algorithm cannot support is a caller contract violation for its own static/runtime checks to surface.
template <typename ParamT>
using bounded_offset_t =
  detail::choose_offset_for_max_t<static_cast<::cuda::std::uint64_t>(::cuda::args::__traits<ParamT>::highest)>;

// =====================================================================
// TODO(gevtushenko): drop this once we drop support for CTK 12.6
//
// Kernel-identity normalization of annotated parameters
// =====================================================================
// nvcc 12.4 to 12.6 re-emit the host translation unit with a defect: the argument of an `auto` non-type template
// parameter is printed as the untyped initializer of the variable that first named the specialization in the TU. With
// `constexpr int64_t n = 384;`, `cuda::args::constant<n>` reaches the host compiler as `constant<384>` and deduces
// `int`, while the device pass deduced `long`. A kernel whose identity contains such a type then has a host stub
// without device code and fails to launch with cudaErrorInvalidDeviceFunction. The *value* of the argument and all
// *type* template arguments survive the re-emission intact. The overloads below rebuild every wrapper that may reach a
// kernel or policy-selector type from that surviving information only:
//   * a `constant`'s element type is chosen from its value (the smallest of int32_t, int64_t, uint64_t that holds it),
//     never from the deduced type of the argument,
//   * static bounds are re-typed with the element type of the wrapped argument, which is a type argument.
// Both compilation passes then name the same kernel. On unaffected toolkits this only makes `constant<int64_t{384}>`
// and `constant<384>` select the same 32-bit kernel instead of two different ones.

template <auto Value>
using __static_value_type_t = ::cuda::std::conditional_t<
  ::cuda::std::in_range<::cuda::std::int32_t>(Value),
  ::cuda::std::int32_t,
  ::cuda::std::
    conditional_t<::cuda::std::in_range<::cuda::std::int64_t>(Value), ::cuda::std::int64_t, ::cuda::std::uint64_t>>;

template <class ElementT, class StaticBounds>
struct __retype_static_bounds
{
  using type = StaticBounds; // no_bounds
};

template <class ElementT, auto Lowest, auto Highest>
struct __retype_static_bounds<ElementT, ::cuda::args::static_bounds<Lowest, Highest>>
{
  using type = ::cuda::args::static_bounds<static_cast<ElementT>(Lowest), static_cast<ElementT>(Highest)>;
};

template <class ElementT, class StaticBounds>
using __retype_static_bounds_t = typename __retype_static_bounds<ElementT, StaticBounds>::type;

//! @brief Plain values carry no `auto` NTTP and pass through unchanged.
_CCCL_TEMPLATE(class Tp)
_CCCL_REQUIRES((!::cuda::args::__is_wrapper_v<::cuda::std::remove_cvref_t<Tp>>) )
[[nodiscard]] _CCCL_HOST_DEVICE constexpr ::cuda::std::remove_cvref_t<Tp> normalize_param(Tp&& __arg) noexcept
{
  return ::cuda::std::forward<Tp>(__arg);
}

//! @brief Compile-time constants: integer values are re-wrapped with a value-chosen element type. Everything else
//! (enumerators, pointers) already spells its type in any constant expression and is kept as is.
template <auto Value, class Tp>
[[nodiscard]] _CCCL_HOST_DEVICE constexpr auto
normalize_param([[maybe_unused]] ::cuda::args::constant<Value, Tp> __arg) noexcept
{
  if constexpr (::cuda::std::__cccl_is_integer_v<::cuda::std::remove_cv_t<decltype(Value)>>)
  {
    // For integral types, we discard the `Tp` type and normalize the type based on the `Value`'s value
    return ::cuda::args::constant<static_cast<__static_value_type_t<Value>>(Value)>{};
  }
  else
  {
    return __arg;
  }
}

template <auto Value>
[[nodiscard]] _CCCL_HOST_DEVICE constexpr auto normalize_param(::cuda::args::__constant_sequence<Value> __arg) noexcept
{
  return __arg;
}

template <class Arg, class StaticBounds>
[[nodiscard]] _CCCL_HOST_DEVICE constexpr auto
normalize_param(const ::cuda::args::immediate<Arg, StaticBounds>& __arg) noexcept
{
  using __bounds_t = __retype_static_bounds_t<::cuda::args::__element_type_of_t<Arg>, StaticBounds>;
  return ::cuda::args::immediate<Arg, __bounds_t>{::cuda::args::__access::__arg(__arg)};
}

template <class Arg, class StaticBounds>
[[nodiscard]] _CCCL_HOST_DEVICE constexpr auto
normalize_param(const ::cuda::args::__immediate_sequence<Arg, StaticBounds>& __arg) noexcept
{
  using __bounds_t = __retype_static_bounds_t<::cuda::args::__element_type_of_t<Arg>, StaticBounds>;
  return ::cuda::args::__immediate_sequence<Arg, __bounds_t>{
    ::cuda::args::__access::__arg(__arg), ::cuda::args::__access::__runtime_bounds(__arg)};
}

template <class Arg, class StaticBounds>
[[nodiscard]] _CCCL_HOST_DEVICE constexpr auto
normalize_param(const ::cuda::args::deferred<Arg, StaticBounds>& __arg) noexcept
{
  using __bounds_t = __retype_static_bounds_t<::cuda::args::__element_type_of_t<Arg>, StaticBounds>;
  return ::cuda::args::deferred<Arg, __bounds_t>{
    ::cuda::args::__access::__arg(__arg), ::cuda::args::__access::__runtime_bounds(__arg)};
}

template <class Arg, class StaticBounds>
[[nodiscard]] _CCCL_HOST_DEVICE constexpr auto
normalize_param(const ::cuda::args::deferred_sequence<Arg, StaticBounds>& __arg) noexcept
{
  using __bounds_t = __retype_static_bounds_t<::cuda::args::__element_type_of_t<Arg>, StaticBounds>;
  return ::cuda::args::deferred_sequence<Arg, __bounds_t>{
    ::cuda::args::__access::__arg(__arg), ::cuda::args::__access::__runtime_bounds(__arg)};
}

// =====================================================================
// Discrete parameter support
// =====================================================================

//! @brief Specifies a list of supported options for a parameter.
template <typename T, T... Options>
struct supported_options
{
  static constexpr ::cuda::std::size_t count = sizeof...(Options);
};

//! @brief Static discrete parameter — a single compile-time value that is also its only supported option.
//!
//! Holds no runtime value, so it cannot be put into a state that disagrees with its supported option, and
//! @c dispatch_impl therefore always matches it. This is the safe representation for a compile-time-fixed discrete
//! parameter (e.g. a statically known top-k selection direction): modeling such a parameter with a runtime value
//! instead would risk that value silently disagreeing with the supported option (a no-op dispatch unless
//! @c CCCL_ENABLE_ASSERTIONS is set).
template <typename T, T Value>
struct static_discrete_param
{
  using value_type          = T;
  using supported_options_t = supported_options<T, Value>;

  template <typename SegmentIndexT>
  [[nodiscard]] _CCCL_HOST_DEVICE constexpr T get_param(SegmentIndexT) const noexcept
  {
    return Value;
  }
};

// =====================================================================
// Discrete dispatch
// =====================================================================

//! @brief Translates a runtime parameter value into a compile-time constant by matching
//!        against a list of supported options.
//!
//! @param[in] val Runtime value to match.
//! @param[in] __supported_options Supported values for the parameter.
//! @param[in] f Functor invoked with the matched compile-time constant.
//! @return `true` if the value matches one of the supported options.
template <typename T, T... Opts, typename Functor>
[[nodiscard]] _CCCL_HOST_DEVICE bool
dispatch_impl(T val, [[maybe_unused]] supported_options<T, Opts...> __supported_options, Functor&& f)
{
  const bool match_found =
    ((val == Opts ? (::cuda::std::forward<Functor>(f)(::cuda::std::integral_constant<T, Opts>{}), true) : false)
     || ...);
  _CCCL_ASSERT(match_found, "The given runtime parameter value is not in the supported list");
  return match_found;
}

//! @brief Dispatcher that resolves a discrete parameter to a compile-time constant
//!        and invokes a functor with the matched option.
//!
//! @param[in] param Discrete parameter to resolve.
//! @param[in] segment_id Segment index to read from `param`.
//! @param[in] f Functor invoked with the matched compile-time constant.
//! @return `true` if the parameter value matches one of its supported options.
template <typename ParamT, typename SegmentIndexT, typename Functor>
[[nodiscard]] _CCCL_HOST_DEVICE bool dispatch_discrete(ParamT param, SegmentIndexT segment_id, Functor&& f)
{
  using supported_list = typename ParamT::supported_options_t;
  auto param_value     = param.get_param(segment_id);
  return CUB_NS_QUALIFIER::detail::params::dispatch_impl(
    param_value, supported_list{}, ::cuda::std::forward<Functor>(f));
}
} // namespace detail::params

CUB_NAMESPACE_END
