// SPDX-FileCopyrightText: Copyright (c) 2026, NVIDIA CORPORATION. All rights reserved.
// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception

//! @file
//! Cluster-based per-segment top-k agent.
//!
//! Prototype that exercises CUDA thread block clusters as a replacement for
//! the multi-kernel + global histogram pipeline used by cub::DeviceTopK. Each
//! cluster processes exactly one segment.
//!
//! Histogram strategy (block-private accumulation, then DSMEM merge into the leader):
//!   1. Every block lays out `hist[num_buckets]` at the same offset in its own
//!      shared memory. Each block accumulates a block-private histogram with a
//!      shared `atomicAdd` (cheap, SMEM-local), which stays mutually atomic with
//!      the DSMEM reductions below (see `load_and_histogram_first_pass`).
//!   2. After a cluster-wide barrier, every non-leader block walks its
//!      histogram and reduces its bucket counts into the leader block's `hist`
//!      via cluster-scope DSMEM atomics. The leader's `hist` therefore plays
//!      a dual role: its own block-private histogram in step 1, then the
//!      cluster-merged histogram after the second cluster sync.
//!   3. The leader block prefix-scans `hist` (a block-wide scan) and identifies
//!      the bucket of the k-th key; its owning lane updates the cluster-shared
//!      `state`. Every block
//!      reads the leader's `state.result` pair (splitter bucket plus
//!      early-stop flag) from the leader via DSMEM at the end of each pass and
//!      folds the bucket into its own local splitter key.
//!
//! The final filter places each block's output through per-CTA shared-memory
//! atomics, seeded by a cross-CTA prefix scan of two independent 32-bit DSMEM
//! reductions (each block's selected-front and candidate-back base offsets)
//! fused directly into the placement counters; no cluster-wide output cursor is
//! kept in `state`.

#pragma once

#include <cub/config.cuh>

#if defined(_CCCL_IMPLICIT_SYSTEM_HEADER_GCC)
#  pragma GCC system_header
#elif defined(_CCCL_IMPLICIT_SYSTEM_HEADER_CLANG)
#  pragma clang system_header
#elif defined(_CCCL_IMPLICIT_SYSTEM_HEADER_MSVC)
#  pragma system_header
#endif // no system header

#include <cub/agent/agent_topk.cuh>
#include <cub/block/block_scan.cuh>
#include <cub/block/radix_rank_sort_operations.cuh>
#include <cub/detail/it_traits.cuh>
#include <cub/detail/null_type.cuh>
#include <cub/detail/segmented_params.cuh>
#include <cub/detail/uninitialized.cuh>
#include <cub/detail/warpspeed/optimize_smem_ptr.cuh>
#include <cub/device/dispatch/dispatch_common.cuh>
#include <cub/device/dispatch/dispatch_topk.cuh>
#include <cub/util_device.cuh>

#include <thrust/type_traits/is_contiguous_iterator.h>
#include <thrust/type_traits/is_trivially_relocatable.h>

#include <cuda/__cmath/ceil_div.h>
#include <cuda/__cmath/pow2.h>
#include <cuda/__cmath/round_down.h>
#include <cuda/__execution/determinism.h>
#include <cuda/__execution/tie_break.h>
#include <cuda/__memcpy_async/elect_one.h>
#include <cuda/__memory/align_up.h>
#include <cuda/__memory/ptr_rebind.h>
#include <cuda/__ptx/instructions/cp_async_bulk.h>
#include <cuda/__ptx/instructions/get_sreg.h>
#include <cuda/__ptx/instructions/mbarrier_arrive.h>
#include <cuda/__ptx/instructions/mbarrier_init.h>
#include <cuda/__ptx/instructions/mbarrier_wait.h>
#include <cuda/argument>
#include <cuda/std/__algorithm/clamp.h>
#include <cuda/std/__algorithm/max.h>
#include <cuda/std/__algorithm/min.h>
#include <cuda/std/__bit/bit_cast.h>
#include <cuda/std/__bit/countr.h>
#include <cuda/std/__memory/pointer_traits.h>
#include <cuda/std/__type_traits/integral_constant.h>
#include <cuda/std/__type_traits/is_same.h>
#include <cuda/std/__utility/forward.h>
#include <cuda/std/cstddef>
#include <cuda/std/cstdint>
#include <cuda/std/limits>
#include <cuda/std/span>

#include <nv/target>

CUB_NAMESPACE_BEGIN

namespace detail::batched_topk_cluster
{
// Dynamic-SMEM layout shared by dispatch and the agent. `max_block_resident_items` is the physical per-CTA resident
// capacity. The unaligned head is staged as an edge in static SMEM (`edge_keys`), not a chunk slot, so the full
// physical capacity is usable (no head reservation).
template <typename KeyT, int ChunkBytes, int LoadAlignBytes>
struct smem_block_tile_layout
{
  static constexpr int chunk_bytes          = ChunkBytes; // one chunk == one slot; this is the slot stride
  static constexpr int max_chunk_items      = ChunkBytes / int{sizeof(KeyT)};
  static constexpr int num_load_align_items = LoadAlignBytes / int{sizeof(KeyT)};
  // Base/slot alignment: at least the load alignment, bumped up for over-aligned key types. The slot stride is exactly
  // one chunk (`ChunkBytes`), so `ChunkBytes` must be a multiple of this for consecutive slots to stay aligned, which
  // also rejects a key alignment larger than a whole chunk at compile time (it makes no sense).
  static constexpr int slot_alignment = (::cuda::std::max) (LoadAlignBytes, int{alignof(KeyT)});
  // Reserve one alignment quantum so the agent can round the dynamic-SMEM base up to `slot_alignment` (>= LoadAlign),
  // giving every bulk-copy destination the same `load_align` alignment the gmem sources already have.
  static constexpr int base_padding_bytes = slot_alignment;
  static_assert(ChunkBytes % slot_alignment == 0, "ChunkBytes must be a multiple of the load and key alignment");

  [[nodiscard]] _CCCL_HOST_DEVICE static constexpr ::cuda::std::uint32_t
  max_block_resident_items(int num_dynamic_smem_bytes) noexcept
  {
    const int num_usable_bytes = (::cuda::std::max) (0, num_dynamic_smem_bytes - base_padding_bytes);
    const int num_slots        = num_usable_bytes / ChunkBytes;
    return static_cast<::cuda::std::uint32_t>(num_slots * max_chunk_items);
  }

  // Number of chunk-sized slots spanned by `num_items` keys (the segment's chunk count). Encapsulates the
  // `max_chunk_items` granularity so callers size segments/clusters without inlining chunk arithmetic.
  [[nodiscard]] _CCCL_HOST_DEVICE static constexpr ::cuda::std::uint64_t
  num_chunks_from_num_items(::cuda::std::uint64_t num_items) noexcept
  {
    return ::cuda::ceil_div(num_items, max_chunk_items);
  }

  // Dynamic-SMEM byte count for `chunks` chunk-sized slots plus the base-alignment padding.
  [[nodiscard]] _CCCL_HOST_DEVICE static constexpr int
  min_smem_bytes_from_num_chunks(::cuda::std::uint64_t num_chunks) noexcept
  {
    _CCCL_ASSERT(base_padding_bytes + num_chunks * static_cast<::cuda::std::uint64_t>(chunk_bytes)
                   <= static_cast<::cuda::std::uint64_t>((::cuda::std::numeric_limits<int>::max)()),
                 "dynamic SMEM byte count exceeds int range");
    return base_padding_bytes + static_cast<int>(num_chunks) * chunk_bytes;
  }

  // Smallest dynamic-SMEM byte count whose per-CTA capacity (`max_block_resident_items`) reaches `items` keys
  // (rounding up to whole chunks). Inverse of `max_block_resident_items`.
  [[nodiscard]] _CCCL_HOST_DEVICE static constexpr int
  min_smem_bytes_from_num_items(::cuda::std::uint64_t num_items) noexcept
  {
    return min_smem_bytes_from_num_chunks(num_chunks_from_num_items(num_items));
  }
};

// Whether a segment takes the cluster-barrier-free single-CTA path.
[[nodiscard]] _CCCL_HOST_DEVICE constexpr bool is_single_cta_eligible(
  ::cuda::std::uint32_t segment_size,
  ::cuda::std::uint32_t max_block_resident_items,
  int single_block_max_seg_size) noexcept
{
  return segment_size <= max_block_resident_items
      && segment_size <= static_cast<::cuda::std::uint32_t>(single_block_max_seg_size);
}

// Logical cluster blocks implied by a chunk count: a CTA joins the logical cluster iff it would own at least
// `min_chunks_per_block` chunks, clamped to `[1, max_cluster_blocks]`. Identical arithmetic on both sides; only
// the cap differs (the live cluster size on the device, max launchable blocks on the host). `min_chunks_per_block` is
// `static_assert`ed positive, so the divide is well-defined. 32-bit: a segment holds at most 2^21 chunks.
[[nodiscard]] _CCCL_HOST_DEVICE constexpr ::cuda::std::uint32_t compute_num_logical_cluster_blocks(
  ::cuda::std::uint32_t num_chunks, int min_chunks_per_block, ::cuda::std::uint32_t max_cluster_blocks) noexcept
{
  const auto num_blocks = num_chunks / static_cast<::cuda::std::uint32_t>(min_chunks_per_block);
  return ::cuda::std::clamp(num_blocks, ::cuda::std::uint32_t{1}, max_cluster_blocks);
}

// `Determinism` / `TieBreak` carry the requested `cuda::execution` requirements down from the dispatch layer. Any
// deterministic guarantee selects the cluster-wide, index-ordered tie-break scan (and the blocked chunk partition it
// depends on) over the nondeterministic racing atomics; `not_guaranteed` keeps the atomics. On the deterministic path
// `prefer_larger_index` reverses the scan order so the largest-index ties win (else the smallest).
template <typename PolicyGetter, // TODO(bgruber): pass cluster_topk_policy as NTTP in C++20
          ::cuda::execution::determinism::__determinism_t Determinism,
          ::cuda::execution::tie_break::__tie_break_t TieBreak,
          typename KeyInputItItT,
          typename KeyOutputItItT,
          typename ValueInputItItT,
          typename ValueOutputItItT,
          typename SegmentSizeParameterT,
          typename KParameterT,
          typename SelectDirectionParameterT,
          typename NumSegmentsParameterT>
struct agent_batched_topk_cluster
{
  // ---------------------------------------------------------------------------
  // Types / constants
  // ---------------------------------------------------------------------------
  static constexpr auto policy = PolicyGetter{}();

  using key_it_t   = it_value_t<KeyInputItItT>;
  using key_t      = it_value_t<key_it_t>;
  using value_it_t = it_value_t<ValueInputItItT>;
  using value_t    = it_value_t<value_it_t>;

  // Keys-only when the value payload type is `cub::NullType` (mirrors the baseline batched top-k agent). The value
  // iterators are then never dereferenced and the final filter's value writes are compiled out.
  static constexpr bool is_keys_only = ::cuda::std::is_same_v<value_t, cub::NullType>;

  // Segment-size type: the smallest unsigned offset type (>= 32-bit) covering the parameter's declared upper bound. The
  // public entry caps that bound at 2^21, so this is always 32-bit.
  using segment_size_val_t = detail::params::bounded_offset_t<SegmentSizeParameterT>;

  // Fixed 32-bit: the segment (grid) index is a CUDA cluster id, and dispatch rejects `num_segments` > INT_MAX before
  // launch. Not derived from the caller's `num_segments` type, so a wide type does not widen the grid math.
  using num_segments_val_t = ::cuda::std::uint32_t;

  // Unsigned because all offsets, ranks, and block counts are non-negative (segment sizes are clamped to >= 0
  // upstream).
  using offset_t     = ::cuda::std::uint32_t;
  using out_offset_t = ::cuda::std::uint32_t;
  using key_prefix_t = detail::topk::key_prefix_storage_t<key_t>;

  // Cluster-shared state: lives in the leader block's shared memory and is reached from every block of the cluster
  // through DSMEM. Nested here so its counters reuse the kernel's fixed 32-bit `offset_t`/`out_offset_t` directly.
  struct state_t
  {
    // Remaining problem size for the running pass: the candidate count `num_cluster_candidates` and the still-wanted
    // rank `leftover_k`. The two 32-bit fields live in an 8-byte-aligned pair so every block can pull both from the
    // leader cluster-wide in one naturally-aligned 64-bit DSMEM load (`bit_cast` from the loaded `u64`) rather than two
    // separate reads.
    struct alignas(8) size_state
    {
      offset_t num_cluster_candidates;
      out_offset_t leftover_k;
    };

    // Per-pass leader result, likewise an 8-byte-aligned pair pulled cluster-wide in one 64-bit DSMEM load.
    // `kth_bucket` is the splitter digit every block folds into its own `kth_key_bits_local` (so the full splitter key
    // is never broadcast); `early_stop` (0/1) is set when that bucket holds exactly the remaining `k` -- every
    // candidate wins, so further passes cannot change the result.
    struct alignas(8) pass_result
    {
      ::cuda::std::uint32_t kth_bucket;
      ::cuda::std::uint32_t early_stop;
    };

    static_assert(sizeof(size_state) == 8 && sizeof(pass_result) == 8,
                  "cluster state relies on 8-byte size/result pairs for single 64-bit DSMEM loads");

    size_state size;
    pass_result result;
  };
  using size_state_t  = typename state_t::size_state;
  using pass_result_t = typename state_t::pass_result;

  // See the class comment: deterministic guarantees select the index-ordered scan; `is_tie_reversed` flips its order.
  static constexpr bool needs_set_determinism =
    Determinism != ::cuda::execution::determinism::__determinism_t::__not_guaranteed;
  static constexpr bool is_tie_reversed =
    TieBreak == ::cuda::execution::tie_break::__tie_break_t::__prefer_larger_index;

  // An explicit index tie-break picks among keys that compare equal, so -0.0 and +0.0 must rank equal. Without one,
  // any set of tied keys is a valid result and the extra normalization is skipped.
  static constexpr bool normalize_minus_zero = TieBreak != ::cuda::execution::tie_break::__tie_break_t::__unspecified;

  // Push direction of the cross-CTA prefix scan (`prime_placement_counters`). The leader must be *last* in scan
  // order so it derives its own (merged-away) counts from the predecessor sum: deterministic-prefer-smaller puts the
  // leader at the last logical rank and scans ascending; every other config (deterministic-prefer-larger and the
  // whole non-deterministic path) keeps the leader at rank 0 and scans descending, which makes rank 0 last. Matches the
  // `leader_rank` computed in `compute_segment_layout`.
  static constexpr bool is_scan_descending = !(needs_set_determinism && !is_tie_reversed);

  // The deterministic final scan visits chunks in global-index order and bails early (`final_filter_should_stop`), so
  // keeping the *first-visited* chunks resident lets it skip re-reading the streamed overflow. Ascending visits low
  // indices first (the default low-resident split); descending (prefer-larger) visits high indices first, so we flip
  // the split to keep the high-index chunks resident (see `run`), restoring symmetry. Never set on the
  // non-deterministic path.
  static constexpr bool is_residency_reversed = needs_set_determinism && is_tie_reversed;

  // Divisor in `compute_num_logical_cluster_blocks`, and a zero-chunk CTA has no work, so it must be positive.
  static_assert(policy.min_chunks_per_block >= 1, "min_chunks_per_block must be positive");

  // Enable the per-segment logical-single-CTA runtime path only when the host could not size the launch to each
  // segment's exact size: any per-segment sequence (`!is_single_value`) or a `deferred` single value. For host-exact
  // `immediate`/`constant` singles the dispatch already picks the matching cluster blocks, so the logic is compiled
  // out.
  static constexpr bool enable_runtime_single_cta =
    (!::cuda::args::__traits<SegmentSizeParameterT>::is_single_value)
    || ::cuda::args::__traits<SegmentSizeParameterT>::is_deferred;

  // Radix passes for this key type (compile-time). The overflow stream flips direction each pass; `run` primes the
  // first wave in `first_wave_is_forward` so the leftover after `num_passes` matches the deterministic filter
  // (non-deterministic keeps the forward default).
  static constexpr int num_passes = detail::topk::calc_num_passes<key_t>(policy.bits_per_pass);
  static constexpr bool first_wave_is_forward =
    !needs_set_determinism || ((!is_tie_reversed) ^ ((num_passes & 1) != 0));

  // Static upper bound on segment size: exact for constant/immediate sizes, the type maximum for runtime sizes. The
  // public entry caps this at 2^21, so it fits `int`.
  static constexpr int static_max_segment_size = ::cuda::args::__traits<SegmentSizeParameterT>::highest;

  // Segments small enough to always be single-CTA resident (one contiguous SMEM span, see `run`) need at most
  // `ceil(static_max_segment_size / policy.threads_per_block)` sweep rounds. We clamp each per-thread unroll down to
  // that bound to trim predication/registers on sub-tile segments. Larger segments keep the full unroll (codegen
  // unchanged).
  static constexpr bool should_clamp_items_to_segment =
    static_max_segment_size > 0 && static_max_segment_size < policy.single_block_max_seg_size;
  static constexpr int segment_rounds_ceil =
    should_clamp_items_to_segment ? ::cuda::ceil_div(static_max_segment_size, policy.threads_per_block) : 0;
  static constexpr int segment_rounds_floor =
    should_clamp_items_to_segment ? static_max_segment_size / policy.threads_per_block : 0;

  // Clamp a per-thread unroll down to the segment's bounded round count (only when `should_clamp_items_to_segment`);
  // larger/unbounded segments keep the full tuning width, and the guard keeps the rounds arithmetic in `int`.
  [[nodiscard]] static _CCCL_CONSTEVAL int clamp_unroll(int rounds, int tuning)
  {
    return should_clamp_items_to_segment ? ::cuda::std::clamp(rounds, 1, tuning) : tuning;
  }

  // Two clamp flavors. The `floor` clamp pairs with an unpredicated main loop over full tiles plus a single
  // remainder loop (the chunk helper `for_each_chunk_key_impl` and the copy fast path); the `ceil` clamp
  // keeps the whole resident segment inside one tile for fully-predicated loops (the final filters' `process_tiles`).
  static constexpr int histogram_items_per_thread_clamped =
    clamp_unroll(segment_rounds_floor, policy.histogram_items_per_thread);
  static constexpr int tie_break_items_per_thread_clamped =
    clamp_unroll(segment_rounds_ceil, policy.tie_break_items_per_thread);
  static constexpr int copy_items_per_thread_clamped = clamp_unroll(segment_rounds_floor, policy.copy_items_per_thread);
  static_assert(histogram_items_per_thread_clamped >= 1, "histogram_items_per_thread_clamped must be positive");
  static_assert(tie_break_items_per_thread_clamped >= 1, "tie_break_items_per_thread_clamped must be positive");
  static_assert(copy_items_per_thread_clamped >= 1, "copy_items_per_thread_clamped must be positive");

  static constexpr int num_buckets     = 1 << policy.bits_per_pass;
  using smem_layout_t                  = smem_block_tile_layout<key_t, policy.chunk_bytes, policy.load_align_bytes>;
  static constexpr int max_chunk_items = smem_layout_t::max_chunk_items;
  static constexpr int num_load_align_items = smem_layout_t::num_load_align_items;
  static constexpr int slot_alignment       = smem_layout_t::slot_alignment;

  // (pointer, count) carrier for a contiguous run of SMEM-staged keys, used only where the length must travel with the
  // base across call boundaries (the resident window and the overflow stream's per-stage view); elsewhere: `key_t*` +
  // count.
  using smem_keys_t = ::cuda::std::span<key_t>;

  // Tie-break unroll for either filter's streamed overflow, which feeds `process_tiles` one chunk slot at a time: clamp
  // items so the tile (`policy.threads_per_block * items`) stays within a chunk, bounding the per-tile early-exit to <=
  // chunk granularity. Resident/edge regions keep the full `tie_break_items_per_thread_clamped`. Floors at 1.
  static constexpr int tie_break_items_streamed =
    ::cuda::std::clamp(max_chunk_items / policy.threads_per_block, 1, tie_break_items_per_thread_clamped);
  static_assert(tie_break_items_streamed >= 1, "tie_break_items_streamed must be positive");

  static_assert(policy.pipeline_stages > 0);
  // `load_phase` tracks one parity bit per stage in a 32-bit mask.
  static_assert(policy.pipeline_stages <= 32, "pipeline_stages must fit in the 32-bit per-stage phase mask");
  // `__block_elect_one` elects via a full-warp `__shfl_sync` + `elect.sync`, so the block must be whole warps.
  static_assert(policy.threads_per_block % detail::warp_threads == 0,
                "threads_per_block must be a multiple of the warp size");
  static_assert(policy.copy_items_per_thread > 0, "copy_items_per_thread must be positive");
  static_assert(policy.histogram_items_per_thread > 0, "histogram_items_per_thread must be positive");
  static_assert(policy.tie_break_items_per_thread > 0, "tie_break_items_per_thread must be positive");
  static_assert(policy.chunk_bytes > 0);
  static_assert(policy.load_align_bytes > 0);
  static_assert(policy.chunk_bytes % policy.load_align_bytes == 0,
                "chunk_bytes must be a multiple of load_align_bytes");
  // The hybrid load relies on the aligned bulk-copy path being exact (no scalar guard), which requires the load
  // alignment to be a power of two and at least the bulk-copy minimum alignment. Mirrors `is_valid_cluster_policy`
  // (checked by the dispatch on the whole policy); repeated here to also guard direct agent instantiations.
  static_assert(policy.load_align_bytes >= detail::bulk_copy_min_align,
                "load_align_bytes must be >= bulk_copy_min_align");
  static_assert(::cuda::is_power_of_two(policy.load_align_bytes), "load_align_bytes must be a power of two");
  static_assert(max_chunk_items > 0);

  using decomposer_t = detail::identity_decomposer_t;
  // Resident/streamed chunks are pulled into the block_tile with elected-thread `cp.async.bulk`/TMA copies against
  // raw per-stage mbarriers; see the async bulk-copy pipeline helpers below.

  // The aligned bulk (TMA) path tiles gmem into `load_align`-aligned units and dense-packs them by bytes into smem.
  // That is only sound when a `load_align` unit is a whole number of keys and a key has no internal padding; otherwise
  // (e.g. `float3`: 12 bytes, 4-byte aligned) a `load_align` boundary would slice a key or leave bubbles in the
  // resident range, so such types fall back to plain per-element loads/stores.
  static constexpr bool key_is_bulk_tileable =
    int{sizeof(key_t)} == int{alignof(key_t)} && policy.load_align_bytes % int{sizeof(key_t)} == 0;
  static constexpr bool use_block_load_to_shared =
    THRUST_NS_QUALIFIER::is_trivially_relocatable_v<key_t> && THRUST_NS_QUALIFIER::is_contiguous_iterator_v<key_it_t>
    && ::cuda::std::__can_to_address<key_it_t> && key_is_bulk_tileable;

  // ---------------------------------------------------------------------------
  // Block-scan used by the leader block to prefix-sum its merged histogram
  // ---------------------------------------------------------------------------
  // The leader-block prefix sum spans `num_buckets` entries. Each thread owns
  // `buckets_per_thread` consecutive buckets in a blocked arrangement; entries
  // past the last valid bucket contribute zero so the histogram size is no
  // longer constrained to be `<= policy.threads_per_block`.
  static constexpr int buckets_per_thread = ::cuda::ceil_div(num_buckets, policy.threads_per_block);
  using block_scan_t                      = BlockScan<offset_t, policy.threads_per_block, BLOCK_SCAN_WARP_SCANS>;

  // ---------------------------------------------------------------------------
  // Shared memory storage
  // ---------------------------------------------------------------------------
  // The same layout is allocated by every block of the cluster so that any
  // block can reach the leader's fields at a known offset via DSMEM. Each
  // block populates its own `hist` block-locally; after the first cluster
  // sync the non-leader blocks reduce their bucket counts into the leader's
  // `hist` through DSMEM atomics. `state` is meaningful only in the leader
  // block; the other blocks reach it exclusively through the DSMEM mapping.
  // `selected_offset_counter`/`tie_offset_counter` are the final-filter output-slot counters, but they first serve as
  // the cross-CTA scan accumulators: peers add their selected/tied counts into them through DSMEM
  // (`add_remote_prefix`) while this block seeds its own tie base locally, leaving each counter primed with this
  // block's absolute region base (selected = `selected_prefix`, tie = `num_cluster_selected + tie_prefix`). Because
  // peers reach them over DSMEM they must sit at an identical offset in every block's storage.
  // `num_local_strictly_selected` accumulates this block's strictly-selected count across passes, and
  // `num_local_candidates` holds the last pass's splitter-bucket count.
  struct _TempStorage
  {
    offset_t hist[num_buckets];
    state_t state;
    offset_t selected_offset_counter;
    offset_t tie_offset_counter;
    offset_t num_local_strictly_selected;
    offset_t num_local_candidates;
    typename block_scan_t::TempStorage scan_storage;
    // One mbarrier handle per pipeline stage, shared by the resident load and the overflow stream and reused
    // (ping-ponged) across radix passes; all are initialized once up front by `init_load_barriers`.
    ::cuda::std::uint64_t load_mbar[policy.pipeline_stages];
    // Persistent unaligned boundary edges (block-load path only): the head prefix (`[0, num_load_align_items)`, on rank
    // 0) and the peeled tail suffix (`[num_load_align_items, 2 * num_load_align_items)`, on the tail owner whenever it
    // is unaligned), each strictly `< num_load_align_items` keys. Loaded once in the first pass and consumed into every
    // pass + the final filter. Block-local (never reached through DSMEM).
    key_t edge_keys[2 * num_load_align_items];
  };

  struct chunk_desc
  {
    offset_t offset;
    // The chunk body this configuration copies: the aligned bulk (unaligned tail suffix peeled to `edge_keys`) on the
    // block-load path, the full raw count on the generic path. Callers read it unconditionally; the raw count is
    // recovered only at the tail-peel spots via `segment_size - offset`.
    int num_items;
  };

  // Chunk `chunk_idx` of the aligned region, beginning on a `load_align` boundary (`num_cluster_head_items + chunk_idx
  // * max_chunk_items`, with `num_cluster_head_items` aligning the base and `max_chunk_items` a multiple of
  // `num_load_align_items`): so every chunk has a zero prefix and only the last chunk can carry an unaligned suffix
  // (its trailing `< num_load_align_items` items). The block-load path reports the aligned bulk `round_down(raw,
  // num_load_align_items)` in `num_items` (that suffix is peeled into `edge_keys`); the generic path reports the full
  // raw count.
  [[nodiscard]] static _CCCL_DEVICE _CCCL_FORCEINLINE chunk_desc
  get_chunk(offset_t chunk_idx, offset_t segment_size, offset_t num_cluster_head_items)
  {
    const offset_t offset = num_cluster_head_items + chunk_idx * offset_t{max_chunk_items};
    // Callers pass a chunk index `< num_cluster_chunks`, so the chunk is non-empty and unsigned `remaining` below can't
    // underflow.
    _CCCL_ASSERT(offset < segment_size, "get_chunk: chunk index lies past the segment end");
    const offset_t remaining = segment_size - offset;
    const offset_t raw_items = (::cuda::std::min) (remaining, offset_t{max_chunk_items});
    if constexpr (use_block_load_to_shared)
    {
      return {offset, static_cast<int>(::cuda::round_down(raw_items, offset_t{num_load_align_items}))};
    }
    else
    {
      return {offset, static_cast<int>(raw_items)};
    }
  }

  // Assignment of the cluster's global chunk indices `[0, num_cluster_chunks)` to its CTAs. A rank owns `num_chunks`
  // chunks; its i-th owned chunk has global index `global_index(i) = first + i * stride`. The single mapping point lets
  // the rest of the agent (resident load, overflow stream, per-pass scans) stay agnostic to the strided/blocked layout
  // chosen in `compute_segment_layout`.
  struct chunk_partition
  {
    offset_t first; // global index of this rank's first owned chunk
    offset_t stride; // distance between consecutive owned chunks (`num_logical_cluster_blocks` strided, `1` blocked)
    offset_t num_chunks; // number of chunks owned by this rank

    [[nodiscard]] _CCCL_DEVICE _CCCL_FORCEINLINE offset_t global_index(offset_t local_chunk_idx) const
    {
      _CCCL_ASSERT(local_chunk_idx < num_chunks, "global_index: rank-local chunk index out of range");
      return first + local_chunk_idx * stride;
    }
  };

  // Stage a small (`< num_load_align_items` items) unaligned run -- a boundary edge (head prefix / tail suffix) -- from
  // gmem `src` into SMEM `dst` and consume it into the first pass in one strided sweep:
  // each thread copies *and* consumes the same indices it owns (`local % policy.threads_per_block == threadIdx.x`),
  // consuming from the just-loaded register rather than from SMEM. These runs cannot go through the aligned
  // (16-byte-aligned dst, guard-free) BlockLoadToShared path. Fusing the copy and consume steps means no thread ever
  // reads a key another thread wrote, so the first-pass consume step needs no barrier after the staging *by
  // construction* -- not by a coincidental match between two separate traversals. Later passes and the final filter
  // re-read `dst` (from `edge_keys` / the resident span) only after a pass-boundary barrier, so their reads are
  // independently safe.
  //
  // TODO(cccl): an asymmetric-alignment BlockLoadToShared API (independent begin/end alignment, e.g. an aligned begin
  // with an arbitrary end) would let a boundary chunk be loaded with a single aligned-bulk + in-place edge call and
  // remove these hand-rolled copies entirely.
  template <typename Apply>
  _CCCL_DEVICE _CCCL_FORCEINLINE void
  stage_and_consume_edge(key_t* dst, const key_t* src, int num_keys, Apply&& apply) const
  {
    _CCCL_ASSERT(num_keys >= 0 && num_keys <= num_load_align_items, "a boundary edge must fit in its edge_keys slot");
    _CCCL_PRAGMA_NOUNROLL()
    for (int key_idx = tid; key_idx < num_keys; key_idx += policy.threads_per_block)
    {
      const key_t key = src[key_idx];
      dst[key_idx]    = key;
      apply(key);
    }
  }

  // Apply `apply(key, key_idx)` to each key of a contiguous chunk (`key_idx` is the key's strided lane index in
  // `[0, num_keys)`), processing tiles of `Unroll * policy.threads_per_block` keys. Each full tile is loaded into
  // registers by one unrolled loop, then handed to `apply` by a second. Splitting the loads out matters for the
  // histogram passes: `apply`'s SMEM atomics can't be proven disjoint from the SMEM key reads, so a fused loop would
  // interleave each load with its atomic instead of hoisting the whole load wave ahead. `Unroll` is the caller's
  // clamped (floor) items per thread, so the sub-tile remainder is handled by a single fused block-stride loop bounded
  // by the count.
  template <int Unroll, typename Apply>
  _CCCL_DEVICE _CCCL_FORCEINLINE void for_each_chunk_key_impl(const key_t* keys, int num_keys, Apply&& apply) const
  {
    constexpr int tile   = Unroll * policy.threads_per_block;
    const int full_tiles = ::cuda::round_down(num_keys, tile);

    _CCCL_PRAGMA_NOUNROLL()
    for (int tile_base = 0; tile_base < full_tiles; tile_base += tile)
    {
      key_t regs[Unroll];
      _CCCL_PRAGMA_UNROLL_FULL()
      for (int i = 0; i < Unroll; ++i)
      {
        regs[i] = keys[tile_base + i * policy.threads_per_block + tid];
      }
      _CCCL_PRAGMA_UNROLL_FULL()
      for (int i = 0; i < Unroll; ++i)
      {
        const int key_idx = tile_base + i * policy.threads_per_block + tid;
        apply(regs[i], key_idx);
      }
    }

    // Sub-tile remainder. No unroll pragma on purpose: the compiler's partial auto-unroll beats forced nounroll here.
    for (int key_idx = full_tiles + tid; key_idx < num_keys; key_idx += policy.threads_per_block)
    {
      apply(keys[key_idx], key_idx);
    }
  }

  template <int Unroll, typename KeyOp>
  _CCCL_DEVICE _CCCL_FORCEINLINE void for_each_chunk_key(const key_t* chunk_keys, int num_keys, KeyOp&& key_op) const
  {
    for_each_chunk_key_impl<Unroll>(chunk_keys, num_keys, [&](const key_t& key, int) {
      key_op(key);
    });
  }

  // ---------------------------------------------------------------------------
  // Async bulk-copy pipeline helpers (raw mbarrier + cp.async.bulk via cuda::ptx)
  // ---------------------------------------------------------------------------
  // Inlines BlockLoadToShared's internals (one mbarrier per stage, a single elected thread issuing the TMA copy +
  // transaction arrival) without its reference member or per-call CommitToken: per-stage wait state is one bit of the
  // per-thread `load_phase` mask, so the pipeline loops spill nothing. SM 9.0+ only (gated by `NV_PROVIDES_SM_90`).

  // Front-load every stage mbarrier before any bulk copy uses it. Init needs no leader or uniform path, so all threads
  // init distinct stages in parallel via a block-stride loop. The caller's block `__syncthreads()` orders these
  // generic-proxy inits before the first `cp.async.bulk` issue, so no `fence.proxy.async` is needed (cf.
  // `BlockLoadToShared`, which front-loads init + `__syncthreads()` likewise).
  _CCCL_DEVICE _CCCL_FORCEINLINE void init_load_barriers()
  {
    _CCCL_PRAGMA_NOUNROLL()
    for (int stage = tid; stage < policy.pipeline_stages; stage += policy.threads_per_block)
    {
      ::cuda::ptx::mbarrier_init(&temp_storage.load_mbar[stage], 1u);
    }
  }

  // Issue one aligned global->shared (TMA) bulk copy into `dst` on stage `stage`'s mbarrier from the block leader,
  // which also arrives with the transaction byte count (an empty copy arrives with zero so the phase still completes).
  // The stage mbarrier must already be initialized (see `init_load_barriers`). Each call must be paired, in issue order
  // per stage, with a matching `wait_stage(stage)`.
  _CCCL_DEVICE _CCCL_FORCEINLINE void issue_bulk_copy(int stage, char* dst, ::cuda::std::span<const key_t> src)
  {
    _CCCL_ASSERT(stage >= 0 && stage < policy.pipeline_stages, "pipeline stage index out of range");
    // Only the block leader (see `is_block_leader`) drives the mbarrier, for a uniform branch and better mbarrier
    // codegen.
    if (!is_block_leader)
    {
      return;
    }
    const int num_bytes = static_cast<int>(::cuda::std::size(src)) * int{sizeof(key_t)};
    // A source is one chunk's aligned bulk (`round_down(count, num_load_align_items)`): a whole load-align unit, <= a
    // slot.
    _CCCL_ASSERT(num_bytes % policy.load_align_bytes == 0, "a bulk copy size must be a whole load-alignment unit");
    _CCCL_ASSERT(num_bytes <= policy.chunk_bytes, "a bulk copy must not exceed one chunk slot");
    if (num_bytes > 0)
    {
      // The TMA path only requires `bulk_copy_min_align` (>= 16), but the aligned base + `load_align`-multiple bulk
      // packing give every destination the stronger `load_align_bytes` alignment (matching the gmem sources).
      _CCCL_ASSERT(::cuda::is_aligned(dst, policy.load_align_bytes),
                   "block_tile destination must satisfy the shared-memory bulk-copy alignment");
#if __cccl_ptx_isa >= 860
      ::cuda::ptx::cp_async_bulk(
        ::cuda::ptx::space_shared,
        ::cuda::ptx::space_global,
        dst,
        ::cuda::std::data(src),
        num_bytes,
        &temp_storage.load_mbar[stage]);
#else // __cccl_ptx_isa < 860
      ::cuda::ptx::cp_async_bulk(
        ::cuda::ptx::space_cluster,
        ::cuda::ptx::space_global,
        dst,
        ::cuda::std::data(src),
        num_bytes,
        &temp_storage.load_mbar[stage]);
#endif // __cccl_ptx_isa >= 860
    }
    ::cuda::ptx::mbarrier_arrive_expect_tx(
      ::cuda::ptx::sem_release,
      ::cuda::ptx::scope_cta,
      ::cuda::ptx::space_shared,
      &temp_storage.load_mbar[stage],
      static_cast<::cuda::std::uint32_t>(num_bytes));
  }

  // Wait for stage `stage`'s copy to land (all threads spin on its current parity), then flip that stage's parity bit.
  _CCCL_DEVICE _CCCL_FORCEINLINE void wait_stage(int stage)
  {
    _CCCL_ASSERT(stage >= 0 && stage < policy.pipeline_stages, "pipeline stage index out of range");
    const ::cuda::std::uint32_t parity = (load_phase >> stage) & 1u;
    _CCCL_PRAGMA_NOUNROLL()
    while (!::cuda::ptx::mbarrier_try_wait_parity(&temp_storage.load_mbar[stage], parity))
    {
    }
    load_phase ^= (::cuda::std::uint32_t{1} << stage);
  }

  using TempStorage = Uninitialized<_TempStorage>;

  // Per-segment, per-rank geometry computed once by `compute_segment_layout` at the top of `run`: the head-aligned
  // chunking, the logical (non-idle) cluster width and this rank's partition of it, the leader/idle roles, and the
  // resident/streaming/edge split of this rank's chunks. All fields are loop-invariant for the segment; the
  // streaming-only intermediates (`overflow_base`, `num_local_resident_slots`, `num_local_stream_slots`,
  // `local_partition.num_chunks`) are kept because the overflow-streaming helpers (`init_overflow_stream`,
  // `run_overflow_pass`, ...) read them.
  struct segment_layout
  {
    offset_t segment_size;
    key_it_t block_keys_in;
    const key_t* block_keys_in_bulk_ptr;
    offset_t num_cluster_head_items;
    offset_t num_cluster_chunks;
    unsigned num_logical_cluster_blocks;
    bool is_idle_rank;
    chunk_partition local_partition;
    unsigned leader_rank;
    // `shared::cluster` addresses of the leader's `state` and `hist[0]`, remapped via `mapa` in
    // `compute_segment_layout`. Every block reads the leader's per-pass results from `leader_state32`; a cluster block
    // also reduces histograms into `leader_hist32 + i * sizeof(offset_t)` (unused on the single-CTA path, which never
    // reduces).
    ::cuda::std::uint32_t leader_state32;
    ::cuda::std::uint32_t leader_hist32;
    offset_t num_local_resident_chunks;
    offset_t num_local_overflow_chunks;
    offset_t resident_base;
    offset_t overflow_base;
    offset_t num_local_resident_slots;
    offset_t num_local_stream_slots;
    int num_local_head_edge_items;
    int num_local_tail_edge_items;
  };

  // ---------------------------------------------------------------------------
  // Per-thread members
  // ---------------------------------------------------------------------------
  _TempStorage& temp_storage;
  KeyInputItItT d_key_segments_it;
  KeyOutputItItT d_key_segments_out_it;
  ValueInputItItT d_value_segments_it;
  ValueOutputItItT d_value_segments_out_it;
  SegmentSizeParameterT segment_sizes;
  KParameterT k_param;
  SelectDirectionParameterT select_directions;
  NumSegmentsParameterT num_segments;
  char* key_slots;
  offset_t max_block_resident_items;
  // Per-thread mbarrier phase parity, one bit per pipeline stage (see `wait_stage`); the resident load and the
  // overflow stream keep their per-stage issue/wait calls balanced so each bit tracks its mbarrier's phase.
  ::cuda::std::uint32_t load_phase{};
  // The single block leader (warp 0's elected lane) for all block-wide single-thread work: the bulk copies and the
  // arbitrary `threadIdx.x == 0` picks (state init, counter seeding). Elected once at construction (convergent there)
  // and cached, so callers reuse it instead of re-electing; the `elect.sync` predicate also keeps each guarded branch
  // on a uniform data path.
  const bool is_block_leader = ::cuda::device::__block_elect_one();
  // This thread's block-local index, signed for the agent's block-stride loops and cached to avoid re-casting
  // `threadIdx.x` at each site.
  const int tid = static_cast<int>(threadIdx.x);
  // Raw launched cluster geometry, cached once from the PTX cluster sregs at the top of `process_impl`. The logical
  // cluster the radix/scan/filter path runs on is `layout.num_logical_cluster_blocks` (1 -- rank 0 alone -- when a
  // small segment collapses onto a single resident CTA); `is_single_cta` records that collapse.
  unsigned cluster_block_rank      = 0u;
  unsigned num_full_cluster_blocks = 1u;
  bool is_single_cta               = true;
  // Per-segment constants for this block, set once and then read directly by the helpers instead of being threaded
  // through their signatures. `segment_id`/`segment_size`/`k` are set in `process_impl`; `layout` is filled by
  // `compute_segment_layout` on the radix path (the select-all fast path and redundant CTAs never touch it).
  num_segments_val_t segment_id{};
  segment_size_val_t segment_size{};
  out_offset_t k{};
  segment_layout layout{};

  // Overflow-streaming slot geometry + ping-pong cursor, set once per segment by `init_overflow_stream` and carried
  // across every radix pass and the final filter (the "Overflow streaming" section documents the reuse scheme). Inert
  // when this rank has no overflow chunks (`init_overflow_stream` still runs, but streaming then touches no slot).
  int stream_slot_base  = 0;
  int num_stream_stages = 1;
  bool stream_is_forward{true};
  bool stream_is_primed{false};
  // In-flight streaming copies, one bit per stage. Maintained only by the radix-pass consume path
  // (`consume_overflow_visit`/`run_overflow_pass`), where phase-1 visits hit resident turn-around chunks and must not
  // wait. The histogram first pass owns no persistent stream state: it waits its own primes in ring order and leaves
  // this zero, so every `run_overflow_pass` enters drained.
  ::cuda::std::uint32_t stream_inflight_mask{0};

  _CCCL_DEVICE_API _CCCL_FORCEINLINE agent_batched_topk_cluster(
    TempStorage& temp_storage_,
    KeyInputItItT d_key_segments_it_,
    KeyOutputItItT d_key_segments_out_it_,
    ValueInputItItT d_value_segments_it_,
    ValueOutputItItT d_value_segments_out_it_,
    SegmentSizeParameterT segment_sizes_,
    KParameterT k_param_,
    SelectDirectionParameterT select_directions_,
    NumSegmentsParameterT num_segments_,
    char* key_slots_,
    offset_t max_block_resident_items_)
      : temp_storage(temp_storage_.Alias())
      , d_key_segments_it(d_key_segments_it_)
      , d_key_segments_out_it(d_key_segments_out_it_)
      , d_value_segments_it(d_value_segments_it_)
      , d_value_segments_out_it(d_value_segments_out_it_)
      , segment_sizes(segment_sizes_)
      , k_param(k_param_)
      , select_directions(select_directions_)
      , num_segments(num_segments_)
      , key_slots(key_slots_)
      , max_block_resident_items(max_block_resident_items_)
  {}

  // ---------------------------------------------------------------------------
  // Main entry point
  // ---------------------------------------------------------------------------
  // SM 9.0+ only. `NV_IF_TARGET` strips the call on NVCC's sub-SM-9.0 device passes, so `process_impl` (and the
  // cluster/async PTX in it and its callees) is never ODR-used there and never reaches ptxas.
  _CCCL_DEVICE_API _CCCL_FORCEINLINE void Process()
  {
    NV_IF_TARGET(NV_PROVIDES_SM_90, (process_impl();));
  }

private:
  _CCCL_DEVICE _CCCL_FORCEINLINE void reset_hist()
  {
    // The `num_buckets / policy.threads_per_block` full strided rounds are in range for every thread. The `<
    // policy.threads_per_block` leftover is compiled out when `num_buckets` is a multiple of
    // `policy.threads_per_block`.
    constexpr int full_rounds = num_buckets / policy.threads_per_block;
    _CCCL_PRAGMA_UNROLL_FULL()
    for (int r = 0; r < full_rounds; ++r)
    {
      temp_storage.hist[r * policy.threads_per_block + tid] = 0;
    }
    if constexpr (num_buckets % policy.threads_per_block != 0)
    {
      if (const int i = full_rounds * policy.threads_per_block + tid; i < num_buckets)
      {
        temp_storage.hist[i] = 0;
      }
    }
  }

  // Weak `ld.shared::cluster` read of a field (or an 8-byte sub-struct) of the leader's cluster-merged `state`, at
  // `leader_state32 + offset` (remapped once in `compute_segment_layout`). The `result` pair is read once per pass; the
  // `size` pair (`num_cluster_candidates`, `leftover_k`) once in the post-pass final filter. The load is a plain
  // `u32`/`u64`; `bit_cast`
  // reinterprets it as `FieldT`, so packed sub-structs come back typed without shifts or masks
  // (endianness-independent). Every read follows a cluster/block barrier that orders the leader's publish, so the weak
  // load is enough; `volatile` keeps it from being hoisted or CSE'd across passes (`result` changes each pass).
  template <typename FieldT>
  _CCCL_DEVICE _CCCL_FORCEINLINE FieldT leader_state_load(::cuda::std::size_t byte_offset)
  {
    const ::cuda::std::uint32_t addr = layout.leader_state32 + static_cast<::cuda::std::uint32_t>(byte_offset);
    if constexpr (sizeof(FieldT) == sizeof(::cuda::std::uint64_t))
    {
      ::cuda::std::uint64_t raw;
      asm volatile("ld.shared::cluster.u64 %0, [%1];" : "=l"(raw) : "r"(addr));
      return ::cuda::std::bit_cast<FieldT>(raw);
    }
    else
    {
      static_assert(sizeof(FieldT) == sizeof(::cuda::std::uint32_t),
                    "leader_state_load supports 32- and 64-bit fields");
      ::cuda::std::uint32_t raw;
      asm volatile("ld.shared::cluster.u32 %0, [%1];" : "=r"(raw) : "r"(addr));
      return ::cuda::std::bit_cast<FieldT>(raw);
    }
  }

  // Adds `num_local_selected_for_scan`/`num_local_tied_for_scan` into the selected/tie placement counters of the CTA at
  // cluster rank `target_rank` through DSMEM (mirrors the Step 2 histogram reduction: `mapa` to `target_rank`, then a
  // cluster-scope `red.add` per counter).
  // Two independent 32-bit reductions rather than one 64-bit one: `red.add.u64` on shared memory is emulated with a
  // CAS spin loop, whereas `red.add.u32` is a native shared-memory atomic. Drives the cross-CTA selected/tied
  // prefix scan (see `prime_placement_counters`).
  _CCCL_DEVICE _CCCL_FORCEINLINE void
  add_remote_prefix(unsigned target_rank, offset_t num_local_selected_for_scan, offset_t num_local_tied_for_scan)
  {
    const ::cuda::std::uint32_t own_selected =
      static_cast<::cuda::std::uint32_t>(__cvta_generic_to_shared(&temp_storage.selected_offset_counter));
    const ::cuda::std::uint32_t own_tied =
      static_cast<::cuda::std::uint32_t>(__cvta_generic_to_shared(&temp_storage.tie_offset_counter));
    // `mapa` is affine (adds the target window's base delta, independent of the address), so one remap serves both
    // counters: map `selected`, then reach `tied` by the same intra-CTA offset `own_tied - own_selected`. Both `cvta`s
    // are symbol-relative offsets off the same `temp_storage` base, so NVVM cancels the base and folds the difference
    // to a compile-time constant -- the emitted PTX is one base materialization, one `mapa`, and a constant `add`.
    ::cuda::std::uint32_t remote_selected;
    asm("mapa.shared::cluster.u32 %0, %1, %2;" : "=r"(remote_selected) : "r"(own_selected), "r"(target_rank));
    const ::cuda::std::uint32_t remote_tied = remote_selected + (own_tied - own_selected);
    asm volatile("red.relaxed.cluster.shared::cluster.add.u32 [%0], %1;"
                 :
                 : "r"(remote_selected), "r"(num_local_selected_for_scan)
                 : "memory");
    asm volatile("red.relaxed.cluster.shared::cluster.add.u32 [%0], %1;"
                 :
                 : "r"(remote_tied), "r"(num_local_tied_for_scan)
                 : "memory");
  }

  // Parallel prefix sum (cub::BlockScan) over the leader's merged histogram
  // plus identification of the bucket holding the k-th item. Each thread of
  // the leader block contributes `buckets_per_thread` consecutive buckets in
  // a blocked arrangement; entries past `num_buckets` contribute zero. The
  // single (thread, slot) pair that owns the k-th bucket writes the per-pass
  // state. The caller must guarantee the leader block has finished its DSMEM
  // merge before invoking this.
  _CCCL_DEVICE _CCCL_FORCEINLINE void leader_identify_kth_bucket()
  {
    // Capture `state.size.leftover_k` before the scan: the owning thread overwrites it in the loop below, so any later
    // read would race with that write.
    const out_offset_t target_k = temp_storage.state.size.leftover_k;
    // Every pass keeps the remaining `k` inside the chosen bucket, so `1 <= target_k <= num_cluster_candidates`.
    _CCCL_ASSERT(target_k >= 1, "leader scan: remaining k must stay positive");
    _CCCL_ASSERT(target_k <= temp_storage.state.size.num_cluster_candidates,
                 "leader scan: remaining k cannot exceed the candidate count");

    offset_t hist_vals[buckets_per_thread];
    offset_t prefixes[buckets_per_thread];

    _CCCL_PRAGMA_UNROLL_FULL()
    for (int j = 0; j < buckets_per_thread; ++j)
    {
      const int bucket = tid * buckets_per_thread + j;
      hist_vals[j]     = (bucket < num_buckets) ? temp_storage.hist[bucket] : offset_t{0};
    }

    block_scan_t(temp_storage.scan_storage).ExclusiveSum(hist_vals, prefixes);

    // Exactly one (thread, slot) pair satisfies
    // `prefix < target_k <= prefix + hist_val`.
    _CCCL_PRAGMA_UNROLL_FULL()
    for (int j = 0; j < buckets_per_thread; ++j)
    {
      const int bucket = tid * buckets_per_thread + j;
      if (bucket < num_buckets && prefixes[j] < target_k && prefixes[j] + hist_vals[j] >= target_k)
      {
        const out_offset_t new_k                        = target_k - static_cast<out_offset_t>(prefixes[j]);
        const offset_t num_remaining_cluster_candidates = hist_vals[j];
        temp_storage.state.size.num_cluster_candidates  = num_remaining_cluster_candidates;
        temp_storage.state.size.leftover_k              = new_k;
        // Publish the splitter bucket and the early-stop flag (set when the bucket holds exactly the remaining `k`);
        // see `pass_result`.
        temp_storage.state.result = pass_result_t{
          static_cast<::cuda::std::uint32_t>(bucket),
          static_cast<::cuda::std::uint32_t>(static_cast<out_offset_t>(num_remaining_cluster_candidates) == new_k)};
      }
    }
  }

  // ---------------------------------------------------------------------------
  // Overflow streaming
  // ---------------------------------------------------------------------------
  // Re-streams a rank's "overflow" chunks (those that do not fit its resident SMEM region) from gmem through a fixed,
  // round-robin set of `num_stream_stages` (<= `policy.pipeline_stages`) streaming slots, reused across every radix
  // pass and the final filter. It ping-pongs the iteration order across calls (`stream_is_forward`) so the
  // `num_stream_stages` turn-around chunks one pass leaves resident in the streaming slots are reused by the next with
  // no reload; the remaining `num_local_overflow_chunks - num_stream_stages` are reloaded from gmem each pass.
  // `compute_segment_layout` sizes the reservation `num_local_stream_slots = min(policy.pipeline_stages,
  // num_local_excess_chunks)` (`num_local_excess_chunks = local_partition.num_chunks - num_local_slots`) that
  // `init_overflow_stream` adopts as `num_stream_stages`, so a streaming rank reloads exactly `num_local_excess_chunks`
  // chunks per pass -- the reserved slots only ever buy reuse of the turn-around chunks, never a reload-free pass. The
  // resident region occupies slots `[0, num_local_resident_slots)`, the streaming region `[stream_slot_base,
  // stream_slot_base + num_stream_stages)`. All geometry comes from `layout`; the only per-stage state is one bit each
  // of `stream_inflight_mask` (set while a copy is in flight) and the `load_phase` parity, so a spillable per-stage
  // array is avoided (the read span is recomputed on demand by `stage_span`).

  // Adopt the streaming-slot window (`num_local_stream_slots`, sized by `compute_segment_layout`) and reset the
  // ping-pong/priming cursor for this segment. `run` may then flip `stream_is_forward` for the deterministic filter's
  // entry parity.
  _CCCL_DEVICE _CCCL_FORCEINLINE void init_overflow_stream()
  {
    stream_slot_base = static_cast<int>(layout.num_local_resident_slots);
    // Use the whole reserved streaming region as pipeline stages for maximal ping-pong reuse; the `1` floor covers the
    // no-op (`num_local_overflow_chunks == 0`) case, where streaming never touches a slot (asserted below).
    num_stream_stages =
      (layout.num_local_stream_slots > offset_t{0}) ? static_cast<int>(layout.num_local_stream_slots) : 1;
    stream_is_forward    = true;
    stream_is_primed     = false;
    stream_inflight_mask = 0;
    // Both chunk windows must lie inside this rank's `local_partition.num_chunks` (resident first, streamed from
    // `overflow_base`).
    _CCCL_ASSERT(layout.num_local_resident_chunks <= layout.local_partition.num_chunks
                   && layout.overflow_base <= layout.local_partition.num_chunks
                   && layout.num_local_overflow_chunks <= layout.local_partition.num_chunks - layout.overflow_base,
                 "overflow stream chunk windows escape the rank's partition");
    // The streaming region is carved from the tile's slots and capped by the pipeline depth.
    _CCCL_ASSERT(stream_slot_base >= 0 && layout.num_local_stream_slots <= static_cast<offset_t>(policy.pipeline_stages)
                   && static_cast<offset_t>(stream_slot_base) + layout.num_local_stream_slots
                        <= max_block_resident_items / static_cast<offset_t>(max_chunk_items),
                 "overflow stream slots escape the block tile or pipeline");
    _CCCL_ASSERT(
      layout.num_local_overflow_chunks == 0 || num_stream_stages <= static_cast<int>(layout.num_local_overflow_chunks),
      "streaming depth exceeds the overflow chunk count");
  }

  // gmem aligned bulk of the chunk at rank-local index `window_base + index` (the resident or overflow window), as a
  // span from `block_keys_in_bulk_ptr`; empty when it has none. `get_chunk` already reports the aligned bulk in
  // `num_items` (the global-last chunk's unaligned suffix is peeled into `edge_keys`). Shared source computation for
  // both the resident and overflow-stream bulk-copy issues.
  [[nodiscard]] _CCCL_DEVICE _CCCL_FORCEINLINE ::cuda::std::span<const key_t>
  chunk_bulk_src(offset_t window_base, offset_t window_chunk_idx) const
  {
    const auto chunk = get_chunk(layout.local_partition.global_index(window_base + window_chunk_idx),
                                 layout.segment_size,
                                 layout.num_cluster_head_items);
    if (chunk.num_items == 0)
    {
      return {};
    }
    _CCCL_ASSERT(::cuda::is_aligned(layout.block_keys_in_bulk_ptr + chunk.offset, policy.load_align_bytes),
                 "a chunk source must start on a load-alignment boundary");
    return {layout.block_keys_in_bulk_ptr + chunk.offset, static_cast<::cuda::std::size_t>(chunk.num_items)};
  }

  // Shared-memory view of the chunk currently resident in `stage`'s slot: the slot index is a pure function of `stage`
  // and the length is recomputed from `overflow_idx` (no spillable per-stage array). Returns the aligned bulk only (the
  // always-peeled tail suffix is excluded).
  [[nodiscard]] _CCCL_DEVICE _CCCL_FORCEINLINE smem_keys_t stage_span(int stage, offset_t overflow_idx) const
  {
    const auto chunk = get_chunk(layout.local_partition.global_index(layout.overflow_base + overflow_idx),
                                 layout.segment_size,
                                 layout.num_cluster_head_items);
    return smem_keys_t(::cuda::ptr_rebind<key_t>(key_slots + (stream_slot_base + stage) * policy.chunk_bytes),
                       chunk.num_items);
  }

  // Consume the `i`-th visit on the block-load path (its ping-pong-ordered position is `overflow_idx`): wait for its
  // slot, consume its keys via `block_apply`, then prefetch the chunk `num_stream_stages` visits ahead into the
  // just-freed slot. A block barrier must separate every lane's read of that slot (in `block_apply`) from the copy
  // that overwrites it; when `PollLeadsWithBarrier` the `should_continue` poll already issued one (its leading
  // barrier sits between the two), so we skip a redundant one here. Returns false once `should_continue()` reports the
  // top-k fully placed -- polled before the prefetch so we never launch a copy we would only drain again; the
  // prefetches already in flight are drained after `run_overflow_pass`'s consume loops.
  template <bool PollLeadsWithBarrier, typename BlockApply, typename Continue>
  [[nodiscard]] _CCCL_DEVICE _CCCL_FORCEINLINE bool
  consume_overflow_visit(offset_t overflow_visit_idx, int& stage, BlockApply&& block_apply, Continue&& should_continue)
  {
    const offset_t overflow_idx =
      stream_is_forward ? overflow_visit_idx : (layout.num_local_overflow_chunks - 1 - overflow_visit_idx);
    // `stage` is a rolling ring pointer owned by the caller and stepped here for the next visit, replacing a per-visit
    // `overflow_idx % num_stream_stages` (a runtime, non-power-of-two divisor). The assert pins it to that closed form
    // so a later edit cannot desync the two.
    _CCCL_ASSERT(stage == static_cast<int>(overflow_idx % static_cast<offset_t>(num_stream_stages)),
                 "overflow stage desynced from its rolling ring pointer");
    if (stream_inflight_mask & (::cuda::std::uint32_t{1} << stage))
    {
      wait_stage(stage);
      stream_inflight_mask &= ~(::cuda::std::uint32_t{1} << stage);
    }
    block_apply(stage, overflow_idx);

    if (!should_continue())
    {
      return false;
    }

    const offset_t next_step = overflow_visit_idx + static_cast<offset_t>(num_stream_stages);
    if (next_step < layout.num_local_overflow_chunks)
    {
      const offset_t next_overflow_idx =
        stream_is_forward ? next_step : (layout.num_local_overflow_chunks - 1 - next_step);
      _CCCL_ASSERT(next_overflow_idx < layout.num_local_overflow_chunks, "overflow chunk index out of range");
      // Slot-reuse fence (see header): order the read of `stage` ahead of its overwrite, unless the poll self-led.
      if constexpr (!PollLeadsWithBarrier)
      {
        __syncthreads();
      }
      _CCCL_ASSERT((stream_inflight_mask & (::cuda::std::uint32_t{1} << stage)) == 0,
                   "cannot issue a load into a streaming stage that is still in flight");
      char* const dst = key_slots + (stream_slot_base + stage) * policy.chunk_bytes;
      issue_bulk_copy(stage, dst, chunk_bulk_src(layout.overflow_base, next_overflow_idx));
      stream_inflight_mask |= (::cuda::std::uint32_t{1} << stage);
    }
    // Step the ring pointer one slot in the consume direction, wrapping with a compare-and-select (no modulo).
    if (stream_is_forward)
    {
      if (++stage == num_stream_stages)
      {
        stage = 0;
      }
    }
    else
    {
      stage = (stage == 0) ? num_stream_stages - 1 : stage - 1;
    }
    return true;
  }

  // Shared driver for one overflow pass. `block_apply(stage, overflow_idx)` consumes the chunk `overflow_idx` resident
  // in streaming slot `stage` (block-load path); `generic_apply(chunk)` consumes an overflow chunk read straight from
  // gmem (fallback). `overlap_work()` runs at most once per pass, positioned to overlap the caller's resident-chunk
  // work with in-flight copies: after the first reload wave (`num_stream_stages` visits) is issued but before it is
  // waited on (block-load path), or before the gmem loop (fallback). A phase-1 early stop on the block-load path skips
  // it, since nothing is then left to place; it must be block-uniform with no unmatched barrier. `should_continue()` is
  // polled once after each consumed chunk (before its refill copy is issued); returning false breaks the stream so the
  // final filter bails once the top-k is placed. Its result must be block-uniform (all lanes break together, else the
  // post-break barrier deadlocks) and it is evaluated by every lane, so it may contain a barrier (both final filters'
  // do, to read their placement counters block-wide); the histogram passes an always-true predicate.
  // `PollLeadsWithBarrier` declares the poll opens with a block barrier (both final filters' do), letting
  // `consume_overflow_visit` drop its own slot-reuse barrier; the histogram's barrier-free poll passes false. An early
  // break can leave prefetches in flight, so the pass drains the remaining stages before returning (a full pass ends
  // with an empty `stream_inflight_mask`, so the drain is a no-op).
  template <bool PollLeadsWithBarrier, typename BlockApply, typename GenericApply, typename OverlapWork, typename Continue>
  _CCCL_DEVICE _CCCL_FORCEINLINE void run_overflow_pass(
    BlockApply&& block_apply, GenericApply&& generic_apply, OverlapWork&& overlap_work, Continue&& should_continue)
  {
    // Every pass begins drained: `load_and_histogram_first_pass` fully drains the first wave before returning, and each
    // pass reuses the prior pass's turn-around chunks resident (not in flight).
    _CCCL_ASSERT(stream_inflight_mask == ::cuda::std::uint32_t{0}, "an overflow pass must begin drained");
    if (layout.num_local_overflow_chunks == 0)
    {
      overlap_work();
      return;
    }

    if constexpr (use_block_load_to_shared)
    {
      // The stream is always primed before the first `run_overflow_pass`: `load_and_histogram_first_pass` primes every
      // streaming rank on the block-load path (interleaved with its resident load, or directly when it has no resident
      // chunks), and `stream_is_primed` then carries across all radix passes and the final filter with no re-prime.
      _CCCL_ASSERT(stream_is_primed,
                   "run_overflow_pass requires the overflow stream primed by load_and_histogram_first_pass");

      // Phase 1: consume the first `num_stream_stages` visits and issue this pass's reload wave into the freed slots.
      // Every pass enters drained, so these slots always hold the prior pass's reused turn-around chunks (already
      // resident); `consume_overflow_visit` issues but never waits here, and phase 2 waits on the reloads it launches.
      // Rolling ring pointer carried across both consume loops so no visit pays a runtime `% num_stream_stages`:
      // forward starts at slot 0, reverse at the last chunk's slot (so this modulo runs only on reverse passes). That
      // seed is the only runtime modulo left in these consume loops in release builds (the per-visit ones became the
      // rolling step; a debug-only assert still evaluates one): a runtime, not compile-time-constant, divisor, at most
      // once per pass and cold. Lowest priority. `consume_overflow_visit` then steps the pointer with compare-select.
      int stage = stream_is_forward
                  ? 0
                  : static_cast<int>((layout.num_local_overflow_chunks - 1) % static_cast<offset_t>(num_stream_stages));
      bool is_stopped = false;
      const offset_t num_phase1_chunks =
        (::cuda::std::min) (static_cast<offset_t>(num_stream_stages), layout.num_local_overflow_chunks);
      _CCCL_PRAGMA_NOUNROLL()
      for (offset_t i = 0; i < num_phase1_chunks; ++i)
      {
        if (!consume_overflow_visit<PollLeadsWithBarrier>(i, stage, block_apply, should_continue))
        {
          is_stopped = true;
          break;
        }
      }

      if (!is_stopped)
      {
        // The reload wave is now in flight; run the caller's overlap work to hide its latency before waiting. Skipped
        // on an early stop: the stream only breaks once this CTA's whole contribution is placed, so no resident key can
        // still be required (the non-deterministic filter consumes its resident keys as `overlap_work`).
        overlap_work();

        // Phase 2: consume the remaining visits (their loads were issued in phase 1 and overlapped `overlap_work`).
        _CCCL_PRAGMA_NOUNROLL()
        for (offset_t i = num_phase1_chunks; i < layout.num_local_overflow_chunks; ++i)
        {
          if (!consume_overflow_visit<PollLeadsWithBarrier>(i, stage, block_apply, should_continue))
          {
            break;
          }
        }
      }

      // Drain prefetches still in flight before returning: an early break leaves outstanding bulk copies whose
      // mbarriers were never waited, and they must complete before the block can exit (their slots are never read).
      // `stream_inflight_mask` is block-uniform (set/cleared under uniform control flow), so the trip count and each
      // collective `wait_stage` are uniform across the block.
      _CCCL_PRAGMA_NOUNROLL()
      while (stream_inflight_mask != ::cuda::std::uint32_t{0})
      {
        const int drain_stage = ::cuda::std::countr_zero(stream_inflight_mask);
        wait_stage(drain_stage);
        stream_inflight_mask &= ~(::cuda::std::uint32_t{1} << drain_stage);
      }
      stream_is_forward = !stream_is_forward;
    }
    else
    {
      // Generic fallback: no async SMEM pipeline, so resident work cannot hide load latency here. Consume the resident
      // chunks first (preserving the prior ordering), then read the overflow keys straight from gmem each pass (no
      // SMEM reuse), with the walk still snaking for L2 locality.
      overlap_work();
      _CCCL_PRAGMA_NOUNROLL()
      for (offset_t visit_idx = 0; visit_idx < layout.num_local_overflow_chunks; ++visit_idx)
      {
        const offset_t overflow_idx =
          stream_is_forward ? visit_idx : (layout.num_local_overflow_chunks - 1 - visit_idx);
        const offset_t chunk_idx = layout.local_partition.global_index(layout.overflow_base + overflow_idx);
        const auto chunk         = get_chunk(chunk_idx, layout.segment_size, layout.num_cluster_head_items);
        generic_apply(chunk);
        if (!should_continue())
        {
          break;
        }
      }
      stream_is_forward = !stream_is_forward;
    }
  }

  // Apply `consume_key(key)` to every overflow key once in the current ping-pong direction. `UnrollFactor` partially
  // unrolls the generic (gmem fallback) consume loop; callers pass their clamped items-per-thread. See
  // `run_overflow_pass` for the overlap semantics of `overlap_work`.
  template <int UnrollFactor, typename KeyConsumer, typename OverlapWork>
  _CCCL_DEVICE _CCCL_FORCEINLINE void consume_overflow_keys(KeyConsumer&& consume_key, OverlapWork&& overlap_work)
  {
    // The histogram poll is barrier-free, so `consume_overflow_visit` keeps its own slot-reuse barrier.
    run_overflow_pass</*PollLeadsWithBarrier=*/false>(
      [&](int stage, offset_t overflow_idx) {
        const auto keys = stage_span(stage, overflow_idx);
        for_each_chunk_key<UnrollFactor>(keys.data(), static_cast<int>(keys.size()), consume_key);
      },
      [&](const auto& chunk) {
        const int num_iterations = ::cuda::ceil_div(chunk.num_items, policy.threads_per_block);
        _CCCL_PRAGMA_UNROLL(UnrollFactor)
        for (int j = 0; j < num_iterations; ++j)
        {
          const int item_idx = j * policy.threads_per_block + tid;
          if (item_idx < chunk.num_items)
          {
            consume_key(
              layout.block_keys_in[static_cast<segment_size_val_t>(chunk.offset + static_cast<offset_t>(item_idx))]);
          }
        }
      },
      ::cuda::std::forward<OverlapWork>(overlap_work),
      [] {
        return true;
      });
  }

  // -------------------------------------------------------------------------
  // Per-direction implementation
  // -------------------------------------------------------------------------
  // Split halves of the cluster-wide barrier (replaces cooperative_groups' `cluster.sync()`). `arrive` releases this
  // CTA's prior writes and signals arrival; `wait` acquires all CTAs' writes once every CTA has arrived. Both are
  // `.aligned` since every thread reaches them under a uniform branch. Issuing independent, block-local work between
  // them hides the cluster-arrival latency.
  _CCCL_DEVICE _CCCL_FORCEINLINE static void cluster_arrive()
  {
    asm volatile("barrier.cluster.arrive.release.aligned;" : : : "memory");
  }
  _CCCL_DEVICE _CCCL_FORCEINLINE static void cluster_wait()
  {
    asm volatile("barrier.cluster.wait.acquire.aligned;" : : : "memory");
  }

  // Cluster-wide barrier: arrive immediately followed by wait, no work window exploited.
  _CCCL_DEVICE _CCCL_FORCEINLINE static void cluster_barrier()
  {
    cluster_arrive();
    cluster_wait();
  }

  // Synchronize the segment's cluster. A single-CTA "cluster" keeps all state block-local, so `__syncthreads()` orders
  // it and the cluster-scoped barrier is unnecessary. `is_single_cta` is the agent's logical-cluster member (see
  // `init_logical_cluster`): 1 when a small segment collapsed onto rank 0, not the raw cluster size. It is
  // per-segment uniform across the surviving block(s), so the branch is reached uniformly.
  _CCCL_DEVICE _CCCL_FORCEINLINE static void cluster_or_block_sync(bool is_single_cta)
  {
    if (is_single_cta)
    {
      __syncthreads();
    }
    else
    {
      cluster_barrier();
    }
  }

  // Split form of `cluster_or_block_sync`, for overlapping the cluster-arrival latency with independent block-local
  // work: `arrive`, then the work, then `wait`. A single-CTA "cluster" has no arrival latency to hide and no cross-CTA
  // state, so it takes the whole `__syncthreads()` at `arrive` and its `wait` is a no-op. In the multi-CTA case the
  // work between the two must touch only block-local state (a cross-CTA read before `wait` may miss a peer's writes).
  _CCCL_DEVICE _CCCL_FORCEINLINE static void cluster_or_block_arrive(bool is_single_cta)
  {
    if (is_single_cta)
    {
      __syncthreads();
    }
    else
    {
      cluster_arrive();
    }
  }
  _CCCL_DEVICE _CCCL_FORCEINLINE static void cluster_or_block_wait(bool is_single_cta)
  {
    if (!is_single_cta)
    {
      cluster_wait();
    }
  }

  struct cross_cta_prefixes
  {
    offset_t selected_prefix; // exclusive selected prefix across CTAs
    offset_t tie_prefix; // exclusive tie prefix across CTAs (candidate-rank space)
  };
  // Exclusive cross-CTA prefix scan fused with priming the final-filter placement counters. Each working CTA pushes its
  // `num_local_selected_for_scan`/`num_local_tied_for_scan` counts into every successor's selected/tie counter in
  // `is_scan_descending` order (the leader is last and pushes to nobody, so it holds the full predecessor sum) and
  // adds its own tie-region base `num_cluster_selected` to its own tie counter. All are commutative `red.add`s into
  // the counters zeroed in `process_impl` (so a single post-push barrier suffices), leaving
  // `selected_offset_counter = selected_prefix` and `tie_offset_counter = num_cluster_selected + tie_prefix` -- the
  // absolute output-slot bases `place_one` expects.
  //
  // Returns this CTA's exclusive selected/tie prefixes for the driver's region math (the non-deterministic path uses
  // only `selected_prefix`); `is_single_cta` yields both zero (selected stays 0, tie is just
  // `num_cluster_selected`). The successor pushes are lane-parallel (each thread owns a strided slice); all threads
  // see CTA-uniform counts, so the guard and the barrier stay uniform.
  _CCCL_DEVICE _CCCL_FORCEINLINE cross_cta_prefixes prime_placement_counters(
    offset_t num_local_selected_for_scan, offset_t num_local_tied_for_scan, offset_t num_cluster_selected)
  {
    if (is_single_cta)
    {
      // No peers: the selected base is 0 (untouched since init) and the tie base is just `num_cluster_selected`.
      if (is_block_leader)
      {
        temp_storage.tie_offset_counter = num_cluster_selected;
      }
      __syncthreads();
      return cross_cta_prefixes{offset_t{0}, offset_t{0}};
    }
    // Fold this CTA's tie base into `tie_offset_counter`, racing the peers' cluster-scope tie-prefix pushes into the
    // same counter (`add_remote_prefix`); `atomicAdd`'s default `.gpu` scope stays mutually atomic with those
    // `.cluster` pushes (see the histogram hot path for the scope argument).
    if (is_block_leader)
    {
      atomicAdd(&temp_storage.tie_offset_counter, num_cluster_selected);
    }
    if (num_local_selected_for_scan != offset_t{0} || num_local_tied_for_scan != offset_t{0})
    {
      // Only working (non-leader) ranks reach here with a nonzero count; idle ranks / the leader push 0.
      _CCCL_ASSERT(cluster_block_rank < layout.num_logical_cluster_blocks,
                   "a nonzero prefix count must come from a working rank");
      if constexpr (is_scan_descending)
      {
        // Lower ranks follow; leader last.
        _CCCL_PRAGMA_NOUNROLL()
        for (unsigned rank = threadIdx.x; rank < cluster_block_rank; rank += policy.threads_per_block)
        {
          add_remote_prefix(rank, num_local_selected_for_scan, num_local_tied_for_scan);
        }
      }
      else
      {
        // Higher ranks follow. Stops at `num_logical_cluster_blocks` since idle ranks own nothing; the leader at the
        // last logical rank is last.
        _CCCL_PRAGMA_NOUNROLL()
        for (unsigned rank = cluster_block_rank + 1u + threadIdx.x; rank < layout.num_logical_cluster_blocks;
             rank += policy.threads_per_block)
        {
          add_remote_prefix(rank, num_local_selected_for_scan, num_local_tied_for_scan);
        }
      }
    }
    // TODO(cccl): idle ranks arrive here only to keep this barrier reachable; a sub-cluster mbarrier over the working
    // ranks would let them exit (see the pass loop).
    cluster_or_block_sync(is_single_cta);
    // The local seed guarantees the tie counter carries at least `num_cluster_selected` (postcondition of the fused
    // prime).
    _CCCL_ASSERT(temp_storage.tie_offset_counter >= num_cluster_selected,
                 "tie counter must include the seeded region base after the scan");
    const cross_cta_prefixes prefixes{
      temp_storage.selected_offset_counter, temp_storage.tie_offset_counter - num_cluster_selected};
    // Every thread must finish snapshotting the primed bases before any lane's `place_one` mutates the same counters:
    // the leading boundary edge in each driver has no barrier of its own before its first placement atomic.
    __syncthreads();
    return prefixes;
  }

  // Which region of the deterministic sweep carries this CTA's last placement work -- the "terminal" region whose last
  // tile may hold the K-boundary and so runs the direct tie scan (all earlier regions, plus the lazy overflow/generic
  // loops, detect the crossing per tile instead). Exactly one region is terminal. `overflow` names an overflow-terminal
  // sweep; it is never queried (overflow uses lazy detection), and each block-load region compares against its own
  // enumerator.
  enum class terminal_region
  {
    head_edge,
    resident,
    overflow,
    tail_edge
  };

  // Deterministic final-filter state: the `run()`-local tie-break values (counts, prefixes, region extents) plus the
  // mutable `running`/`is_tie_active` scan cursor, bundled into one POD so the flattened filter methods below take a
  // single `state` argument instead of ~16. A deterministic-path-only local of `write_deterministic_topk`; never
  // instantiated on the non-deterministic path. Segment-invariant inputs (`segment_id`, `k`, and the `layout.*`
  // geometry) are read from the agent directly rather than duplicated here. `resident_keys` carries the resident
  // window as a `smem_keys_t` view.
  template <detail::topk::select SelectDirection>
  struct det_filter_state
  {
    using identify_op_t = detail::topk::
      identify_candidates_op_t<key_t, SelectDirection, policy.bits_per_pass, decomposer_t, normalize_minus_zero>;

    identify_op_t identify_op;
    it_value_t<KeyOutputItItT> block_keys_out;
    out_offset_t num_cluster_tie_winners;
    out_offset_t num_local_selected;
    offset_t selected_prefix;
    offset_t tie_prefix;
    offset_t num_local_tied;
    offset_t resident_seg_base;
    smem_keys_t resident_keys;
    int num_local_resident_items;
    bool block_selects_all_tied;
    terminal_region terminal;
    // Mutable per-invocation tie-break scan cursor.
    offset_t running;
    bool is_tie_active;
  };

  // ---------------------------------------------------------------------------
  // Final-filter placement (shared) + deterministic filter
  // ---------------------------------------------------------------------------
  // The classify/place helpers below (`place_one`, `place_tile`, `process_tiles`, ...) are shared by both filters. The
  // deterministic-only sweeps that follow are named agent methods over a `det_filter_state` (`state`), driven by
  // `run_filter`; `write_deterministic_topk` computes `state` and calls `run_filter(state)`. See
  // `write_deterministic_topk` for the front/back placement scheme. All methods are `_CCCL_FORCEINLINE`.

  // Shared by both final filters: for each key written to `block_keys_out[pos]`, load the associated input value at the
  // key's segment-local index `seg_idx` from gmem and store it at the same slot. Compiled out (and never dereferences
  // the null value iterators) in keys-only builds; `segment_id` is loop-invariant, so the per-segment iterators hoist
  // out of the writes.
  _CCCL_DEVICE _CCCL_FORCEINLINE void final_filter_write_value(out_offset_t pos, offset_t seg_idx)
  {
    if constexpr (!is_keys_only)
    {
      _CCCL_ASSERT(pos < k && seg_idx < layout.segment_size,
                   "value write must land in the top-k output and read inside the segment");
      auto block_vals_in  = d_value_segments_it[segment_id];
      auto block_vals_out = d_value_segments_out_it[segment_id];
      block_vals_out[pos] = block_vals_in[static_cast<segment_size_val_t>(seg_idx)];
    }
  }

  // Per-item placement code stored in `flags[]` by the load/classify pass and reused by `place_tile`/`emit_indexed`, so
  // each key is classified exactly once.
  static constexpr offset_t flag_none      = 0; // rejected or out-of-range: no placement, absent from the tie scan
  static constexpr offset_t flag_candidate = 1; // tie candidate: routed to the back, counted by the boundary scan
  static constexpr offset_t flag_selected  = 2; // strictly selected: routed to the front

  // Map thread `tid`'s item slot `i` to its position within the current tile. Blocked is used by the straddling
  // deterministic CTA while it resolves ties (`process_tiles` phase A): `emit_indexed`'s `BlockScan` ranks candidates
  // in blocked order, which makes the tie ranks segment-index-ordered. Striped (consecutive threads hit consecutive
  // addresses: no SMEM bank conflicts on the staged reads, coalesced loads in the gmem fallback) is used everywhere
  // else -- the whole non-deterministic filter, every non-straddling deterministic CTA, and the straddling CTA's tiles
  // past the boundary (phase B). `classify_tile` and `place_tile` must use the same `Blocked` so `keys[i]`/`flags[i]`
  // denote the same element; `emit_indexed` is intrinsically blocked.
  template <bool Blocked, int ItemsPerThread>
  _CCCL_DEVICE _CCCL_FORCEINLINE int tile_item_pos(int tile_base, int i) const
  {
    if constexpr (Blocked)
    {
      return tile_base + tid * ItemsPerThread + i;
    }
    else
    {
      return tile_base + i * policy.threads_per_block + tid;
    }
  }

  // Shared per-key arrival placement core (called by `place_tile` for both final filters): route one key by class to
  // the selected or tie counter, each primed with its region base by `prime_placement_counters` so the SMEM atomic
  // returns the absolute output slot with no per-key offset. The uniform `out < k` guard drops losing candidates but
  // always accepts selected keys; pairs builds also copy the key's value from `seg_idx`. (Deterministic index-ordered
  // tie resolution goes through `emit_indexed` instead.)
  template <typename KeyOutIt>
  _CCCL_DEVICE _CCCL_FORCEINLINE void
  place_one(KeyOutIt block_keys_out, bool is_tied, const key_t& key, offset_t seg_idx)
  {
    offset_t* const counter = is_tied ? &temp_storage.tie_offset_counter : &temp_storage.selected_offset_counter;
    const out_offset_t out  = static_cast<out_offset_t>(atomicAdd(counter, offset_t{1}));
    // The selected counter never overruns the selected region, so only losing candidates may exceed `k`.
    _CCCL_ASSERT(is_tied || out < k, "a strictly-selected key must always land within the top-k output");
    if (out < k)
    {
      block_keys_out[out] = key;
      final_filter_write_value(out, seg_idx);
    }
  }

  // Uniform "all placed" predicate: true once this block has emitted all `num_local_selected` strictly-selected keys
  // and resolved its ties. Brackets its block-wide counter reads with two barriers, so callers neither pre- nor
  // post-sync; every lane must reach it. Polled only at critical points -- between regions and after each consumed
  // overflow chunk -- never per tile.
  template <detail::topk::select SelectDirection>
  _CCCL_DEVICE _CCCL_FORCEINLINE bool final_filter_should_stop(const det_filter_state<SelectDirection>& state)
  {
    // Counters run absolute (primed with the region base), so completion compares against each region's end. Every
    // region is visited at most once, so neither counter can pass its end.
    const offset_t num_cluster_selected =
      static_cast<offset_t>(k) - static_cast<offset_t>(state.num_cluster_tie_winners);
    const offset_t selected_end = state.selected_prefix + static_cast<offset_t>(state.num_local_selected);
    const offset_t tie_end      = num_cluster_selected + state.tie_prefix + state.num_local_tied;
    // Bracket the counter reads against both placement waves: the leading barrier publishes the prior wave's
    // `place_one` atomics (a region or a single overflow chunk; also resyncs lanes that drifted through its
    // barrier-free tiles); the trailing barrier keeps the next wave's atomics from overtaking a read still in flight
    // (UB, and could diverge the returned predicate).
    __syncthreads();
    _CCCL_ASSERT(temp_storage.selected_offset_counter <= selected_end && temp_storage.tie_offset_counter <= tie_end,
                 "final-filter placement counters exceeded this CTA's assigned work");
    const bool is_selected_done = temp_storage.selected_offset_counter >= selected_end;
    // Straddling/above CTAs finish the tie region when `is_tie_active` clears; a `block_selects_all_tied` (which never
    // clears it) finishes once all `num_local_tied` of its candidates are placed.
    const bool is_tie_done = !state.is_tie_active || (temp_storage.tie_offset_counter >= tie_end);
    __syncthreads();
    return is_selected_done && is_tie_done;
  }

  // Arrival-order placement for one tile: each in-range key is routed by `place_one` (both regions fill forward). The
  // candidate atomic advances win or lose; arrival order is fine because either every candidate wins (select-all) or
  // the lazy crossing tile is overwritten in index order later. `do_arrival == false` (terminal tile only) skips
  // candidates here and leaves them to `emit_indexed`; the lazy path passes `true` and its crossing tile is later
  // overwritten by `emit_indexed`.
  template <bool Reversed, bool Blocked, int ItemsPerThread, typename State>
  _CCCL_DEVICE _CCCL_FORCEINLINE void place_tile(
    State& state,
    const key_t (&keys)[ItemsPerThread],
    const offset_t (&flags)[ItemsPerThread],
    offset_t seg_base,
    int num_keys,
    int tile_base,
    bool do_arrival)
  {
    _CCCL_PRAGMA_UNROLL_FULL()
    for (int i = 0; i < ItemsPerThread; ++i)
    {
      const bool is_tied = flags[i] == flag_candidate;
      if (flags[i] == flag_none || (is_tied && !do_arrival))
      {
        continue;
      }
      const int pos          = tile_item_pos<Blocked, ItemsPerThread>(tile_base, i);
      const offset_t seg_idx = seg_base + static_cast<offset_t>(Reversed ? (num_keys - 1 - pos) : pos);
      place_one(state.block_keys_out, is_tied, keys[i], seg_idx);
    }
  }

  // Index-ordered back placement for one tile: a block scan over the candidate mask gives each candidate a
  // deterministic rank (`base` plus the count of preceding candidates in the tile). A winner (rank below
  // `num_cluster_tie_winners`) lands at forward output slot `num_cluster_selected + rank`, matching `place_tile`.
  // Returns the tile's candidate total. Used where the K-boundary falls in this tile (terminal tile, or the lazy
  // path's crossing tile).
  template <bool Reversed, int ItemsPerThread, typename State>
  _CCCL_DEVICE _CCCL_FORCEINLINE offset_t emit_indexed(
    State& state,
    const key_t (&keys)[ItemsPerThread],
    const offset_t (&flags)[ItemsPerThread],
    offset_t seg_base,
    int num_keys,
    int tile_base,
    offset_t base)
  {
    const offset_t num_cluster_selected =
      static_cast<offset_t>(k) - static_cast<offset_t>(state.num_cluster_tie_winners); // front region size
    // `flags[]` is 3-valued (none/candidate/selected); the scan must count candidates only, so reduce to a 0/1 mask.
    offset_t tied_mask[ItemsPerThread];
    _CCCL_PRAGMA_UNROLL_FULL()
    for (int i = 0; i < ItemsPerThread; ++i)
    {
      tied_mask[i] = (flags[i] == flag_candidate) ? offset_t{1} : offset_t{0};
    }
    offset_t tied_excl[ItemsPerThread];
    offset_t num_tile_tied = 0;
    block_scan_t(temp_storage.scan_storage).ExclusiveSum(tied_mask, tied_excl, num_tile_tied);
    _CCCL_PRAGMA_UNROLL_FULL()
    for (int i = 0; i < ItemsPerThread; ++i)
    {
      if (tied_mask[i] != offset_t{0})
      {
        const offset_t global_rank = base + tied_excl[i];
        if (global_rank < static_cast<offset_t>(state.num_cluster_tie_winners))
        {
          // `emit_indexed` is deterministic-only, and its `BlockScan` ranks assume a blocked arrangement.
          const int pos             = tile_item_pos<true, ItemsPerThread>(tile_base, i);
          const out_offset_t out    = static_cast<out_offset_t>(num_cluster_selected + global_rank);
          const offset_t seg_idx    = seg_base + static_cast<offset_t>(Reversed ? (num_keys - 1 - pos) : pos);
          state.block_keys_out[out] = keys[i];
          final_filter_write_value(out, seg_idx);
        }
      }
    }
    return num_tile_tied;
  }

  // Load and 3-way classify one tile's items into `keys`/`flags` (see `flag_*`), re-run by `place_tile`/`emit_indexed`
  // without touching `identify_op` again. `Blocked` picks the thread->element arrangement (`tile_item_pos`); the source
  // is `smem_src` (folded in-region position) or gmem `block_keys_in`. Out-of-range lanes stay `flag_none`.
  template <bool Blocked, int ItemsPerThread, bool FromSmem, bool Reversed, typename State>
  _CCCL_DEVICE _CCCL_FORCEINLINE void classify_tile(
    State& state,
    [[maybe_unused]] const key_t* smem_src,
    offset_t seg_base,
    int num_keys,
    int tile_base,
    key_t (&keys)[ItemsPerThread],
    offset_t (&flags)[ItemsPerThread])
  {
    _CCCL_PRAGMA_UNROLL_FULL()
    for (int i = 0; i < ItemsPerThread; ++i)
    {
      const int pos = tile_item_pos<Blocked, ItemsPerThread>(tile_base, i);
      flags[i]      = flag_none;
      if (pos < num_keys)
      {
        // In-region index: forward, or (`Reversed`) counting down from the last element. Shared by the `FromSmem`
        // local read and the segment-local value index.
        const int folded_pos = Reversed ? (num_keys - 1 - pos) : pos;
        if constexpr (FromSmem)
        {
          keys[i] = smem_src[folded_pos];
        }
        else
        {
          keys[i] = layout.block_keys_in[static_cast<segment_size_val_t>(seg_base + static_cast<offset_t>(folded_pos))];
        }
        const auto cls = state.identify_op(keys[i]);
        flags[i]       = (cls == detail::topk::candidate_class::candidate)
                         ? flag_candidate
                         : (cls == detail::topk::candidate_class::selected ? flag_selected : flag_none);
      }
    }
  }

  // Classify (`classify_tile`) and place each of `num_keys` keys, tiled by `policy.threads_per_block * ItemsPerThread`.
  // `FromSmem` picks the key source; `Reversed` walks the span high-to-low. Both final filters share this via
  // `Deterministic`:
  //   * `false` (a `nondet_filter_state`, always striped): every tile placed in arrival order (`place_tile` with
  //     `do_arrival == true`); no scan/tie-state/barrier, `region_is_terminal` unused.
  //   * `true` (a `det_filter_state`): resolves the boundary ties in segment-index order via `emit_indexed`, so callers
  //     walk the regions in global-index order and carry `state.running`/`state.is_tie_active` across tiles;
  //     `region_is_terminal` marks the CTA's last. Only the boundary-straddling CTA resolves ties and is dispatched
  //     `Blocked`; other deterministic CTAs never scan and are dispatched striped (see `write_deterministic_topk`).
  // `Blocked` is the *entry* arrangement (`tile_item_pos`). The blocked deterministic path is two-phase: it loads
  // blocked only while ties remain (phase A, `emit_indexed`'s scan needs it) and switches once to striped for the
  // remaining strictly-selected/rejected keys (phase B).
  template <int ItemsPerThread, bool FromSmem, bool Reversed, bool Deterministic, bool Blocked, typename State>
  _CCCL_DEVICE _CCCL_FORCEINLINE void process_tiles(
    State& state,
    [[maybe_unused]] const key_t* smem_src,
    offset_t seg_base,
    int num_keys,
    [[maybe_unused]] bool region_is_terminal)
  {
    // The SMEM-source clause is exempt when reading from gmem (`FromSmem == false`, the generic overflow fallback
    // passes `nullptr`) or for an empty tile.
    _CCCL_ASSERT(num_keys >= 0 && seg_base <= layout.segment_size
                   && static_cast<offset_t>(num_keys) <= layout.segment_size - seg_base
                   && (!FromSmem || num_keys == 0 || smem_src != nullptr),
                 "process_tiles: region must be a valid in-segment source span");
    constexpr int tile_size = policy.threads_per_block * ItemsPerThread;
    int tile_base           = 0;

    if constexpr (Deterministic && Blocked)
    {
      // Blocked is dispatched only for the boundary-straddling CTA, which always has ties and is never select-all.
      _CCCL_ASSERT(!state.block_selects_all_tied, "blocked deterministic path is only for the straddling CTA");

      // Phase A: while ties remain, load blocked (`emit_indexed`'s scan needs it) and resolve them. A region entered
      // past the crossing (its ties already placed) has `is_tie_active == false`, so phase A is skipped and everything
      // falls through to phase B.
      _CCCL_PRAGMA_NOUNROLL()
      for (; state.is_tie_active && tile_base < num_keys; tile_base += tile_size)
      {
        key_t keys[ItemsPerThread];
        offset_t flags[ItemsPerThread];
        classify_tile</*Blocked=*/true, ItemsPerThread, FromSmem, Reversed>(
          state, smem_src, seg_base, num_keys, tile_base, keys, flags);

        // The boundary tile places its candidates via `emit_indexed` (arrival placement skipped, `do_arrival ==
        // false`); every other tile uses `place_tile`'s arrival route:
        //   * terminal tile -- the CTA's last tile necessarily holds the boundary: scan it directly.
        //   * lazy crossing tile -- boundary not yet known: candidates land in arrival order first, then `B1` reads the
        //                           counter and, on the tile that crosses `num_cluster_tie_winners`, overwrites those
        //                           slots in index order.
        const bool is_terminal_tile = region_is_terminal && (tile_base + tile_size >= num_keys);
        place_tile<Reversed, /*Blocked=*/true>(state, keys, flags, seg_base, num_keys, tile_base, !is_terminal_tile);

        if (is_terminal_tile)
        {
          state.running += emit_indexed<Reversed>(state, keys, flags, seg_base, num_keys, tile_base, state.running);
          state.is_tie_active = false;
        }
        else
        {
          // B1: order the arrival global writes (from `place_tile`) ahead of the index-order overwrite (same boundary
          // slots) and make the counter read race-free and block-uniform.
          __syncthreads();
          // `tie_offset_counter` is primed with the tie base (`num_cluster_selected + tie_prefix`), so subtracting the
          // front region size recovers this CTA's candidate-rank reached so far (`tie_prefix` plus placed candidates).
          const offset_t num_cluster_selected =
            static_cast<offset_t>(k) - static_cast<offset_t>(state.num_cluster_tie_winners);
          _CCCL_ASSERT(temp_storage.tie_offset_counter >= num_cluster_selected,
                       "tie counter must stay at or above its primed base (no unsigned underflow)");
          const offset_t reached = temp_storage.tie_offset_counter - num_cluster_selected;
          if (reached > static_cast<offset_t>(state.num_cluster_tie_winners))
          {
            // Crossing tile: overwrite this tile's arrival slots `{num_cluster_selected+state.running, ...}` with the
            // index-ordered winners (identical slot set, different candidate->slot mapping).
            emit_indexed<Reversed>(state, keys, flags, seg_base, num_keys, tile_base, state.running);
          }
          state.running = reached;
          if (state.running >= static_cast<offset_t>(state.num_cluster_tie_winners))
          {
            state.is_tie_active = false;
          }
          // Trailing barrier for the lazy-scan path only: separate this tile's counter read (B1 above) from the next
          // tile's `tie_offset_counter` atomic. Other paths write disjoint slots and need no explicit barrier.
          __syncthreads();
        }
      }

      // Phase B: ties are placed, so any remaining candidate-class keys are losers (dropped via `do_arrival == false`);
      // only strictly-selected keys are placed, to the front in arrival order. Load striped (coalesced/conflict-free);
      // no scan or barrier -- `selected_offset_counter` is order-independent, so the A->B switch needs none either.
      _CCCL_PRAGMA_NOUNROLL()
      for (; tile_base < num_keys; tile_base += tile_size)
      {
        key_t keys[ItemsPerThread];
        offset_t flags[ItemsPerThread];
        classify_tile</*Blocked=*/false, ItemsPerThread, FromSmem, Reversed>(
          state, smem_src, seg_base, num_keys, tile_base, keys, flags);
        place_tile<Reversed, /*Blocked=*/false>(state, keys, flags, seg_base, num_keys, tile_base, /*do_arrival=*/false);
      }
    }
    else
    {
      // Single striped pass: the non-deterministic filter (always) or a deterministic CTA that never scans.
      _CCCL_PRAGMA_NOUNROLL()
      for (; tile_base < num_keys; tile_base += tile_size)
      {
        key_t keys[ItemsPerThread];
        offset_t flags[ItemsPerThread];
        classify_tile<Blocked, ItemsPerThread, FromSmem, Reversed>(
          state, smem_src, seg_base, num_keys, tile_base, keys, flags);
        if constexpr (Deterministic)
        {
          // Non-straddling CTA: a select-all CTA places its (all-winning) candidates in arrival order; a select-no or
          // already-resolved CTA has none. Never the index-ordered scan.
          _CCCL_ASSERT(state.block_selects_all_tied || !state.is_tie_active,
                       "striped deterministic tile must never need index-ordered tie resolution");
          const bool do_arrival = state.is_tie_active && state.block_selects_all_tied;
          place_tile<Reversed, Blocked>(state, keys, flags, seg_base, num_keys, tile_base, do_arrival);
        }
        else
        {
          // Selected to the front, the first `num_cluster_tie_winners` candidates to the back via `place_one`'s `out <
          // k` guard.
          place_tile<Reversed, Blocked>(state, keys, flags, seg_base, num_keys, tile_base, /*do_arrival=*/true);
        }
      }
    }
  }

  // Resident-front region. Direction is the compile-time `is_residency_reversed` (== `is_tie_reversed` in
  // deterministic mode): ascending walks the low-index window forward, descending the high-index window
  // (`resident_base`) in reverse. One `process_tiles` call per span handles both, folding the index at compile time.
  template <bool Blocked, detail::topk::select SelectDirection>
  _CCCL_DEVICE _CCCL_FORCEINLINE void process_resident(det_filter_state<SelectDirection>& state)
  {
    if constexpr (use_block_load_to_shared)
    {
      // Whole contiguous resident span staged in SMEM.
      process_tiles<tie_break_items_per_thread_clamped,
                    /*FromSmem=*/true,
                    /*Reversed=*/is_residency_reversed,
                    /*Deterministic=*/true,
                    Blocked>(
        state,
        state.resident_keys.data(),
        state.resident_seg_base,
        state.num_local_resident_items,
        state.terminal == terminal_region::resident);
    }
    else
    {
      const int num_local_resident_chunks = static_cast<int>(layout.num_local_resident_chunks);
      _CCCL_PRAGMA_NOUNROLL()
      for (int resident_visit_idx = 0; resident_visit_idx < num_local_resident_chunks; ++resident_visit_idx)
      {
        const int local_resident_chunk_idx =
          is_residency_reversed ? (num_local_resident_chunks - 1 - resident_visit_idx) : resident_visit_idx;
        const offset_t chunk_idx =
          layout.local_partition.global_index(layout.resident_base + static_cast<offset_t>(local_resident_chunk_idx));
        const auto chunk = get_chunk(chunk_idx, layout.segment_size, layout.num_cluster_head_items);
        // Generic multi-chunk resident loop reads the chunk's SMEM slot; never the terminal-tile fast path (the lazy
        // per-tile boundary detection handles any boundary), so pass `false`.
        process_tiles<tie_break_items_per_thread_clamped,
                      /*FromSmem=*/true,
                      /*Reversed=*/is_residency_reversed,
                      /*Deterministic=*/true,
                      Blocked>(
          state,
          ::cuda::ptr_rebind<key_t>(key_slots + local_resident_chunk_idx * policy.chunk_bytes),
          chunk.offset,
          chunk.num_items,
          false);
      }
    }
  }

  // Overflow chunks. On the block-load path each landed slot is consumed through `process_tiles` (reusing the TMA
  // pipeline); the generic fallback reads gmem chunk by chunk. `run_overflow_pass`'s `should_continue` breaks the
  // stream once the top-k is fully placed. The streaming direction is already correct on entry (preselected in `run`),
  // and the slots are already primed -- the histogram's first streaming pass primed the same persistent stream, so
  // `stream_is_primed` carries in as `true` and this pass reuses the resident turn-around chunks with no re-prime (the
  // generic fallback re-reads gmem each pass regardless).
  template <bool Blocked, detail::topk::select SelectDirection>
  _CCCL_DEVICE _CCCL_FORCEINLINE void process_overflow(det_filter_state<SelectDirection>& state)
  {
    // Guards the straddling CTA (the only rank needing scan order): `run` preselected the direction so it enters at
    // `stream_is_forward == !is_tie_reversed` after the full `num_passes`. The escape disjuncts are the cases where
    // the streaming direction is moot: no overflow (`num_local_overflow_chunks == 0`); a CTA entirely at/below the
    // boundary
    // (`block_selects_all_tied`, arrival-order atomics); or one with no back scan (`!is_tie_active`). Early stop is
    // subsumed -- it makes every CTA `block_selects_all_tied`, so the shorter (possibly mis-parity) pass count never
    // reaches a straddler.
    _CCCL_ASSERT(layout.num_local_overflow_chunks == 0 || state.block_selects_all_tied || !state.is_tie_active
                   || stream_is_forward == (!is_tie_reversed),
                 "preselected ping-pong parity mismatch: the straddling CTA entered the deterministic filter with "
                 "the wrong streaming direction");

    // `final_filter_should_stop` opens with a block barrier, so `consume_overflow_visit` drops its slot-reuse barrier.
    run_overflow_pass</*PollLeadsWithBarrier=*/true>(
      // Block-load: consume the chunk `overflow_idx`, resident in streaming slot `stage`, straight from SMEM.
      // `stage_span` returns the slot's aligned-bulk view (a peeled tail suffix is handled by `process_tail_edge`).
      [&](int stage, offset_t overflow_idx) {
        const auto keys = stage_span(stage, overflow_idx);
        const offset_t base_off =
          get_chunk(layout.local_partition.global_index(layout.overflow_base + overflow_idx),
                    layout.segment_size,
                    layout.num_cluster_head_items)
            .offset;
        // The multi-chunk overflow stream stays on the lazy per-tile boundary detection (`region_is_terminal ==
        // false`): a stray terminal direct scan here would need the stream to flag its last chunk, and the saving
        // is one barrier on one tile.
        process_tiles<tie_break_items_streamed,
                      /*FromSmem=*/true,
                      /*Reversed=*/is_tie_reversed,
                      /*Deterministic=*/true,
                      Blocked>(state, keys.data(), base_off, static_cast<int>(keys.size()), false);
      },
      // Generic fallback: read the overflow chunk straight from gmem (full count; the fallback never peels a tail).
      [&](const auto& chunk) {
        // FromSmem=false: `smem_src` is unread, so pass nullptr.
        process_tiles<tie_break_items_streamed,
                      /*FromSmem=*/false,
                      /*Reversed=*/is_tie_reversed,
                      /*Deterministic=*/true,
                      Blocked>(state, nullptr, chunk.offset, chunk.num_items, false);
      },
      // No interleaved resident work: the deterministic filter consumes its resident span separately.
      [] {},
      // Break the stream once the whole top-k is placed (polled before each refill copy). `final_filter_should_stop`
      // self-syncs, so the just-consumed chunk's placement atomics cannot race its read.
      [&] {
        return !final_filter_should_stop(state);
      });
  }

  // Consume one persistent boundary edge (head prefix or peeled tail suffix), both staged in `edge_keys`. A no-op on
  // the generic fallback (which reads boundary items straight from gmem) and for a zero-length edge. An edge spans
  // fewer than `num_load_align_items` items (it fits in its `edge_keys` slot), so it runs `process_tiles` at unroll
  // factor 1 (non-unrolled) instead of the wider tie-break unroll the potentially large resident/overflow regions use.
  template <bool Blocked, detail::topk::select SelectDirection>
  _CCCL_DEVICE _CCCL_FORCEINLINE void process_edge(
    [[maybe_unused]] det_filter_state<SelectDirection>& state,
    [[maybe_unused]] const key_t* keys,
    [[maybe_unused]] offset_t seg_base,
    [[maybe_unused]] int num_keys,
    [[maybe_unused]] bool is_terminal)
  {
    if constexpr (use_block_load_to_shared)
    {
      _CCCL_ASSERT(num_keys >= 0 && num_keys <= num_load_align_items, "a boundary edge must fit in its edge_keys slot");
      process_tiles<1, /*FromSmem=*/true, /*Reversed=*/is_tie_reversed, /*Deterministic=*/true, Blocked>(
        state, keys, seg_base, num_keys, is_terminal);
    }
  }

  // Head prefix edge (rank 0): the segment's lowest indices `[0, num_local_head_edge_items)`, staged at `edge_keys`
  // (base 0). In global-index order it is the leading region (ascending) / trailing region (descending); a non-head
  // rank or empty prefix is a no-op.
  template <bool Blocked, detail::topk::select SelectDirection>
  _CCCL_DEVICE _CCCL_FORCEINLINE void process_head_edge(det_filter_state<SelectDirection>& state)
  {
    process_edge<Blocked>(
      state,
      temp_storage.edge_keys,
      offset_t{0},
      layout.num_local_head_edge_items,
      state.terminal == terminal_region::head_edge);
  }

  // Peeled tail suffix edge (tail owner): the segment's highest indices, staged at `edge_keys + num_load_align_items`
  // (base `segment_size - num_local_tail_edge_items`). In global-index order it is the trailing region (ascending) /
  // leading region (descending); an aligned or non-owned tail is a no-op.
  template <bool Blocked, detail::topk::select SelectDirection>
  _CCCL_DEVICE _CCCL_FORCEINLINE void process_tail_edge(det_filter_state<SelectDirection>& state)
  {
    process_edge<Blocked>(
      state,
      temp_storage.edge_keys + num_load_align_items,
      layout.segment_size - static_cast<offset_t>(layout.num_local_tail_edge_items),
      layout.num_local_tail_edge_items,
      state.terminal == terminal_region::tail_edge);
  }

  // Drive the four regions in global-index order (ascending, or descending under `is_tie_reversed`), bailing between
  // regions once `final_filter_should_stop` reports the whole top-k placed. The two orders share the resident->overflow
  // middle and only swap which boundary edge leads: ascending is head, resident, overflow, tail; descending reverses
  // the edges. Both visit resident before overflow, so the stop check can skip re-streaming the overflow once the
  // top-k is placed; `is_residency_reversed` keeps the first-visited (high-index) chunks resident in the descending
  // order so this holds.
  template <bool Blocked, detail::topk::select SelectDirection>
  _CCCL_DEVICE _CCCL_FORCEINLINE void run_filter(det_filter_state<SelectDirection>& state)
  {
    const auto step = [&](auto&& region) {
      // No explicit barrier: `final_filter_should_stop` self-syncs, isolating its read from `region`'s placement
      // atomics and the prior region's.
      if (!final_filter_should_stop(state))
      {
        region();
      }
    };
    if constexpr (is_tie_reversed)
    {
      process_tail_edge<Blocked>(state);
    }
    else
    {
      process_head_edge<Blocked>(state);
    }
    step([&] {
      process_resident<Blocked>(state);
    });
    step([&] {
      process_overflow<Blocked>(state);
    });
    step([&] {
      if constexpr (is_tie_reversed)
      {
        process_head_edge<Blocked>(state);
      }
      else
      {
        process_tail_edge<Blocked>(state);
      }
    });
  }

  // Consume the persistent boundary edges into `apply` (head prefix on rank 0; peeled tail suffix on the tail owner),
  // reading the keys already staged in `edge_keys`. Used by the histogram passes; both final filters consume the edges
  // through `process_tiles` instead (as separate regions for the deterministic filter, via `nondet_consume_resident`).
  template <typename Apply>
  _CCCL_DEVICE _CCCL_FORCEINLINE void consume_boundary_edges(
    [[maybe_unused]] int num_head_edge_keys, [[maybe_unused]] int num_tail_edge_keys, [[maybe_unused]] Apply&& apply)
  {
    if constexpr (use_block_load_to_shared)
    {
      _CCCL_PRAGMA_NOUNROLL()
      for (int key_idx = tid; key_idx < num_head_edge_keys; key_idx += policy.threads_per_block)
      {
        apply(temp_storage.edge_keys[key_idx]);
      }
      _CCCL_PRAGMA_NOUNROLL()
      for (int key_idx = tid; key_idx < num_tail_edge_keys; key_idx += policy.threads_per_block)
      {
        apply(temp_storage.edge_keys[num_load_align_items + key_idx]);
      }
    }
  }

  // ---------------------------------------------------------------------------
  // Non-deterministic final filter
  // ---------------------------------------------------------------------------
  // Order-independent counterpart of the deterministic filter: every region is swept by
  // `process_tiles<..., Deterministic=false>` (arrival-order placement, no scan/tie-state/barrier). Since order is
  // irrelevant, `write_nondeterministic_topk` consumes the resident keys as the overflow stream's `overlap_work`
  // (overlapping the first reloads) and bails out of the overflow stream once its contribution is fully placed.
  template <typename IdentifyOp, typename KeyOutIt>
  struct nondet_filter_state
  {
    IdentifyOp identify_op;
    KeyOutIt block_keys_out;
    out_offset_t num_cluster_tie_winners;
    offset_t selected_prefix;
    offset_t num_local_selected; // this CTA's selected region size (see `write_deterministic_topk`'s
                                 // `num_local_selected`)
    smem_keys_t resident_keys;
  };

  // Consume this rank's resident keys (and boundary edges) through `process_tiles`, run as the overflow pass's
  // `overlap_work` so they overlap the first overflow reloads. Placement uses order-independent atomics into slots
  // disjoint from the streaming slots, so this never races the overflow apply. Each chunk's `chunk.offset` is passed as
  // the region's segment base (used for the pair value fetch; elided in keys-only).
  template <typename IdentifyOp, typename KeyOutIt>
  _CCCL_DEVICE _CCCL_FORCEINLINE void nondet_consume_resident(nondet_filter_state<IdentifyOp, KeyOutIt>& state)
  {
    if constexpr (use_block_load_to_shared)
    {
      // Resident keys are densely packed in slot order (aligned bulks only), so a running cursor recovers per-chunk
      // spans. Only the global-last chunk can be partial (its unaligned suffix is peeled into `edge_keys` and consumed
      // below), so iterate `chunk.num_items` (the aligned bulk on this block-load path).
      key_t* const resident_ptr = state.resident_keys.data();
      int running_offset_items  = 0;
      _CCCL_PRAGMA_NOUNROLL()
      for (offset_t local_resident_chunk_idx = 0; local_resident_chunk_idx < layout.num_local_resident_chunks;
           ++local_resident_chunk_idx)
      {
        const auto chunk =
          get_chunk(layout.local_partition.global_index(layout.resident_base + local_resident_chunk_idx),
                    layout.segment_size,
                    layout.num_cluster_head_items);
        process_tiles<tie_break_items_per_thread_clamped,
                      /*FromSmem=*/true,
                      /*Reversed=*/false,
                      /*Deterministic=*/false,
                      /*Blocked=*/false>(
          state, resident_ptr + running_offset_items, chunk.offset, chunk.num_items, false);
        running_offset_items += chunk.num_items;
      }
      // Persistent boundary edges (unroll factor 1: an edge spans fewer than `num_load_align_items` items): head prefix
      // at `edge_keys` (segment index 0), peeled tail suffix at `edge_keys + num_load_align_items` (segment index
      // `segment_size - num_local_tail_edge_items`).
      if (layout.num_local_head_edge_items > 0)
      {
        process_tiles<1, /*FromSmem=*/true, /*Reversed=*/false, /*Deterministic=*/false, /*Blocked=*/false>(
          state, temp_storage.edge_keys, offset_t{0}, layout.num_local_head_edge_items, false);
      }
      if (layout.num_local_tail_edge_items > 0)
      {
        process_tiles<1, /*FromSmem=*/true, /*Reversed=*/false, /*Deterministic=*/false, /*Blocked=*/false>(
          state,
          temp_storage.edge_keys + num_load_align_items,
          layout.segment_size - static_cast<offset_t>(layout.num_local_tail_edge_items),
          layout.num_local_tail_edge_items,
          false);
      }
    }
    else
    {
      // Generic fallback: each resident chunk is staged in its own `key_slots` slot (indexed by
      // `local_resident_chunk_idx`); no edges are peeled (boundary items are read as ordinary chunks). Indexing is
      // `global_index(local_resident_chunk_idx)` with no
      // `resident_base` offset, unlike the sibling loops -- valid only because this path never reverses residency.
      static_assert(!is_residency_reversed, "non-deterministic path never uses reversed residency");
      _CCCL_PRAGMA_NOUNROLL()
      for (offset_t local_resident_chunk_idx = 0; local_resident_chunk_idx < layout.num_local_resident_chunks;
           ++local_resident_chunk_idx)
      {
        const auto chunk = get_chunk(layout.local_partition.global_index(local_resident_chunk_idx),
                                     layout.segment_size,
                                     layout.num_cluster_head_items);
        process_tiles<tie_break_items_per_thread_clamped,
                      /*FromSmem=*/true,
                      /*Reversed=*/false,
                      /*Deterministic=*/false,
                      /*Blocked=*/false>(
          state,
          ::cuda::ptr_rebind<key_t>(key_slots + static_cast<int>(local_resident_chunk_idx) * policy.chunk_bytes),
          chunk.offset,
          chunk.num_items,
          false);
      }
    }
  }

  // Non-deterministic final filter driver. `prime_placement_counters` primes this block's selected/tie placement
  // counters to their absolute bases (only `selected_prefix` is read back here; the tie base is used in place via
  // `tie_offset_counter`); overflow keys then stream through `run_overflow_pass` (resident keys consumed as its
  // `overlap_work`) and place into block-local SMEM atomics. `run_overflow_pass` breaks the stream once this CTA's
  // contribution is fully placed (all its selected keys in the front, and its tie counter reached the region end `k`).
  template <typename IdentifyOp, typename KeyOutIt>
  _CCCL_DEVICE _CCCL_FORCEINLINE void
  write_nondeterministic_topk(IdentifyOp identify_op, KeyOutIt block_keys_out, smem_keys_t resident_keys)
  {
    // Leader's remaining tie count after the passes, pulled while every block is still coupled to the pass loop's final
    // cluster barrier (a later re-read could touch an already-returned leader) in one 64-bit `size`-pair load. Only
    // `leftover_k` drives the filter (the back region places against it directly); `num_cluster_candidates` bounds the
    // debug check below.
    const size_state_t size                    = leader_state_load<size_state_t>(offsetof(state_t, size));
    const out_offset_t num_cluster_tie_winners = size.leftover_k;
    _CCCL_ASSERT(num_cluster_tie_winners > out_offset_t{0} && num_cluster_tie_winners <= k
                   && static_cast<offset_t>(num_cluster_tie_winners) <= size.num_cluster_candidates,
                 "remaining k must fit within the top-k and the candidate count");
    const bool participates                    = !layout.is_idle_rank && (cluster_block_rank != layout.leader_rank);
    const offset_t num_local_selected_for_scan = participates ? temp_storage.num_local_strictly_selected : offset_t{0};
    const offset_t num_local_tied_for_scan     = participates ? temp_storage.num_local_candidates : offset_t{0};
    // The scan doubles as counter priming: it leaves this CTA's placement counters holding its absolute region bases
    // (selected = `selected_prefix`, tie = `num_cluster_selected + tie_prefix`), so no explicit priming follows.
    const offset_t num_cluster_selected = static_cast<offset_t>(k) - static_cast<offset_t>(num_cluster_tie_winners);
    // Only the selected prefix is needed here: tie placement uses the primed `tie_offset_counter` directly and the
    // early stop tests it against `k`, so the tie prefix is discarded.
    const offset_t selected_prefix =
      prime_placement_counters(num_local_selected_for_scan, num_local_tied_for_scan, num_cluster_selected)
        .selected_prefix;
    // This CTA's exclusive selected prefix must leave room for the `num_cluster_tie_winners` tie-back slots. It is
    // `<=`, not `==`: `selected_prefix` reaches the full selected total `num_cluster_selected` (so the sum hits `k`)
    // only for the last CTA in scan order (the leader); every earlier CTA sits strictly below it.
    _CCCL_ASSERT(
      static_cast<::cuda::std::uint64_t>(selected_prefix) + static_cast<::cuda::std::uint64_t>(num_cluster_tie_winners)
        <= static_cast<::cuda::std::uint64_t>(k),
      "selected prefix must fit before the tie-back output region");
    // This CTA's selected region size (mirrors `write_deterministic_topk`): the leader is last in scan order and
    // derives it from the total (`num_cluster_selected - selected_prefix`) since its merged histogram can't
    // self-count; others place `num_local_selected_for_scan`.
    const offset_t num_local_selected =
      (cluster_block_rank == layout.leader_rank)
        ? (num_cluster_selected - selected_prefix)
        : num_local_selected_for_scan;

    nondet_filter_state<IdentifyOp, KeyOutIt> state{
      identify_op, block_keys_out, num_cluster_tie_winners, selected_prefix, num_local_selected, resident_keys};

    // The nondet stop poll opens with a block barrier, so `consume_overflow_visit` drops its slot-reuse barrier.
    run_overflow_pass</*PollLeadsWithBarrier=*/true>(
      // Block-load: consume the chunk `overflow_idx`, resident in streaming slot `stage`, straight from SMEM.
      [&](int stage, offset_t overflow_idx) {
        const auto keys = stage_span(stage, overflow_idx);
        const offset_t base_off =
          get_chunk(layout.local_partition.global_index(layout.overflow_base + overflow_idx),
                    layout.segment_size,
                    layout.num_cluster_head_items)
            .offset;
        process_tiles<tie_break_items_streamed,
                      /*FromSmem=*/true,
                      /*Reversed=*/false,
                      /*Deterministic=*/false,
                      /*Blocked=*/false>(state, keys.data(), base_off, static_cast<int>(keys.size()), false);
      },
      // Generic fallback: read the overflow chunk straight from gmem.
      [&](const auto& chunk) {
        process_tiles<tie_break_items_streamed,
                      /*FromSmem=*/false,
                      /*Reversed=*/false,
                      /*Deterministic=*/false,
                      /*Blocked=*/false>(state, nullptr, chunk.offset, chunk.num_items, false);
      },
      // Consume the resident keys + boundary edges, overlapping the first overflow reloads.
      [&] {
        nondet_consume_resident(state);
      },
      // Break the stream once this CTA's whole contribution is placed: its front is full (`selected_offset_counter`
      // reached `selected_prefix + num_local_selected`) and its tie region is full (`tie_offset_counter >= k`, so
      // further candidates fail `place_one`'s `out < k` guard). The stop needs both conditions, so a CTA whose
      // candidates never fill its tie region to `k` simply never stops early. The barriers bracket the counter reads
      // against both placement waves (same pattern as `final_filter_should_stop`): the leading one publishes the
      // just-consumed chunk's atomics, the trailing one keeps the next chunk's from overtaking a read still in flight.
      [&] {
        __syncthreads();
        const offset_t selected_end = state.selected_prefix + state.num_local_selected;
        _CCCL_ASSERT(temp_storage.selected_offset_counter <= selected_end,
                     "selected counter must stay within this CTA's selected region");
        const bool is_placed = temp_storage.selected_offset_counter >= selected_end
                            && temp_storage.tie_offset_counter >= static_cast<offset_t>(k);
        __syncthreads();
        return !is_placed;
      });
  }

  // Deterministic final filter: both regions fill forward -- strictly-selected keys into the front `[0,
  // num_cluster_selected)` via a SMEM atomic (primed with this CTA's `selected_prefix`), candidates into the back
  // `[num_cluster_selected, k)`. Candidate placement uses arrival-order atomics, with an index-ordered BlockScan only
  // on the single boundary-crossing (straddling) CTA. `prime_placement_counters` gives this block its disjoint
  // selected/tie bases and lets it detect whether all/none/some of its candidates win. This member computes the
  // `det_filter_state` inputs and hands them to `run_filter`, which drives the per-region sweeps.
  template <detail::topk::select SelectDirection, typename IdentifyOp, typename KeyOutIt>
  _CCCL_DEVICE _CCCL_FORCEINLINE void
  write_deterministic_topk(IdentifyOp identify_op, KeyOutIt block_keys_out, smem_keys_t resident_keys)
  {
    // Cache the leader's final `size` pair now, while every block is still tightly coupled to the pass loop's final
    // cluster barrier -- a post-scan re-read of the leader's `state` could touch an already-returned leader (barrier
    // gone). One aligned 64-bit DSMEM load pulls both fields: the tied count and the remaining `k`. Early stop is
    // not special-cased: `num_cluster_tied == num_cluster_tie_winners` then makes every CTA `block_selects_all_tied`.
    const size_state_t size                    = leader_state_load<size_state_t>(offsetof(state_t, size));
    const offset_t num_cluster_tied            = size.num_cluster_candidates;
    const out_offset_t num_cluster_tie_winners = size.leftover_k;
    // Guards the unsigned `k - num_cluster_tie_winners` below: the remaining tie count is positive and fits both `k`
    // and the splitter bucket.
    _CCCL_ASSERT(num_cluster_tie_winners > out_offset_t{0} && num_cluster_tie_winners <= k
                   && static_cast<offset_t>(num_cluster_tie_winners) <= num_cluster_tied,
                 "remaining k must fit within both the top-k and the splitter bucket");
    const out_offset_t num_cluster_selected = k - num_cluster_tie_winners; // front region

    const bool participates                    = !layout.is_idle_rank && (cluster_block_rank != layout.leader_rank);
    const offset_t num_local_selected_for_scan = participates ? temp_storage.num_local_strictly_selected : offset_t{0};
    const offset_t num_local_tied_for_scan     = participates ? temp_storage.num_local_candidates : offset_t{0};
    // The scan doubles as counter priming: it leaves this CTA's placement counters holding its absolute region bases
    // (selected = `selected_prefix`, tie = `num_cluster_selected + tie_prefix`), so no explicit priming follows. Only
    // the selected count feeds the selected counter; candidates always route through the tie counter.
    const auto prefixes = prime_placement_counters(
      num_local_selected_for_scan, num_local_tied_for_scan, static_cast<offset_t>(num_cluster_selected));
    const offset_t selected_prefix = prefixes.selected_prefix;
    const offset_t tie_prefix      = prefixes.tie_prefix;
    // Guards the leader's remainder subtractions below (`num_cluster_tied - tie_prefix`, `num_cluster_selected -
    // selected_prefix`).
    _CCCL_ASSERT(tie_prefix <= num_cluster_tied && selected_prefix <= static_cast<offset_t>(num_cluster_selected),
                 "cross-CTA prefixes must stay within their tied and selected totals");
    // This block's own tied count: non-leaders hold it in `num_local_tied_for_scan`; the leader is last in scan order,
    // so `tie_prefix` already sums every other block's candidates and `num_cluster_tied - tie_prefix` is its own. A
    // CTA is `block_selects_all_tied` when all of its candidates sit at or below the K-boundary (`tie_prefix +
    // num_local_tied <= num_cluster_tie_winners`): every one wins, so the back places them with arrival-order SMEM
    // atomics and skips the index-ordered scan. While `is_tie_active`, a non-`block_selects_all_tied` CTA is the
    // single boundary-crossing (straddling) CTA cluster-wide.
    const offset_t num_local_tied =
      (cluster_block_rank == layout.leader_rank) ? (num_cluster_tied - tie_prefix) : num_local_tied_for_scan;
    const bool block_selects_all_tied = (tie_prefix + num_local_tied) <= static_cast<offset_t>(num_cluster_tie_winners);
    // Mirror image: a CTA selects none of its candidates when the tie region is empty (`num_cluster_tie_winners == 0`)
    // or all of its candidates sort strictly after the K-boundary (`tie_prefix >= num_cluster_tie_winners`). Such a
    // CTA seeds `is_tie_active` false and skips the back placement entirely.
    const bool block_selects_no_tied =
      (num_cluster_tie_winners == out_offset_t{0}) || (tie_prefix >= static_cast<offset_t>(num_cluster_tie_winners));
    // This block's own selected size: non-leaders know it directly (`num_local_selected_for_scan`); the leader is last
    // in scan order, so `selected_prefix` already sums every other block's selected and `num_cluster_selected -
    // selected_prefix` is the remainder it owns.
    const out_offset_t num_local_selected =
      (cluster_block_rank == layout.leader_rank)
        ? static_cast<out_offset_t>(num_cluster_selected - static_cast<out_offset_t>(selected_prefix))
        : static_cast<out_offset_t>(num_local_selected_for_scan);
    // This CTA's front slots `[selected_prefix, selected_prefix + num_local_selected)` (the range its primed
    // `selected_offset_counter` walks) must stay within the selected region `[0, num_cluster_selected)`.
    _CCCL_ASSERT(
      selected_prefix + static_cast<offset_t>(num_local_selected) <= static_cast<offset_t>(num_cluster_selected),
      "this CTA's front slots must fit within the selected region");

    // Resident-front extent (bulk path): the whole contiguous resident span. The unaligned tail suffix (the
    // globally-last chunk's) is always peeled into `edge_keys` and consumed by `process_tail_edge`, so it is never
    // part of this span.
    const int num_local_resident_items = static_cast<int>(resident_keys.size());

    // The terminal region (see `terminal_region`): the last one carrying work in sweep order (ascending
    // head->resident->overflow->tail, reversed tail->resident->overflow->head).
    [[maybe_unused]] const bool has_head      = layout.num_local_head_edge_items > 0;
    const bool has_resident                   = num_local_resident_items > 0;
    const bool has_overflow                   = layout.num_local_overflow_chunks > offset_t{0};
    [[maybe_unused]] const bool has_tail_edge = layout.num_local_tail_edge_items > 0;
    terminal_region terminal;
    if constexpr (is_tie_reversed)
    {
      terminal = has_head     ? terminal_region::head_edge
               : has_overflow ? terminal_region::overflow
               : has_resident ? terminal_region::resident
                              : terminal_region::tail_edge;
    }
    else
    {
      terminal = has_tail_edge ? terminal_region::tail_edge
               : has_overflow  ? terminal_region::overflow
               : has_resident  ? terminal_region::resident
                               : terminal_region::head_edge;
    }

    // Segment-local base of the resident-front span (its lowest-index resident chunk; `resident_base` shifts it to
    // the high-index window under `is_residency_reversed`). The blocked partition packs the front contiguously, so
    // element `pos` maps to `resident_seg_base + pos`. Guarded on `num_local_resident_items > 0`: with a fully-streamed
    // rank
    // (`num_local_stream_slots == num_local_slots`) there are no resident chunks and `resident_base` would name an
    // out-of-range local chunk under `is_residency_reversed`.
    const offset_t resident_seg_base =
      (num_local_resident_items > 0)
        ? get_chunk(layout.local_partition.global_index(layout.resident_base),
                    layout.segment_size,
                    layout.num_cluster_head_items)
            .offset
        : offset_t{0};

    // Positional aggregate init in `det_filter_state` declaration order. The last two initializers seed the tie-break
    // cursor: `running` at this CTA's exclusive tie prefix (candidates owned by preceding CTAs), `is_tie_active` at
    // `!block_selects_no_tied` -- true unless this is a select-no-candidates CTA (empty tie region, or all of this
    // CTA's candidates sort past the boundary).
    det_filter_state<SelectDirection> state{
      identify_op,
      block_keys_out,
      num_cluster_tie_winners,
      num_local_selected,
      selected_prefix,
      tie_prefix,
      num_local_tied,
      resident_seg_base,
      resident_keys,
      num_local_resident_items,
      block_selects_all_tied,
      terminal,
      tie_prefix,
      !block_selects_no_tied};
    // Arrangement dispatch: only the boundary-straddling CTA (neither select-all nor select-no candidates) resolves
    // ties via `emit_indexed`, so it enters `Blocked` (then switches to striped past the boundary; see
    // `process_tiles`). Every other CTA places purely via arrival-order atomics and loads striped throughout.
    if (!block_selects_all_tied && !block_selects_no_tied)
    {
      run_filter</*Blocked=*/true>(state);
    }
    else
    {
      run_filter</*Blocked=*/false>(state);
    }
  }

  // Fused first pass: load this rank's resident chunks into the block_tile, stage the persistent boundary edges into
  // `edge_keys`, and consume every key (resident + edges + overflow) into pass 0's histogram in the same sweep (pass 0
  // needs no candidate filtering). Publishes the resident span as `resident_keys` for the later passes and the final
  // filter. The caller's `__syncthreads()` makes `edge_keys` and the block-local histogram block-visible; cross-CTA
  // visibility of the zeroed histogram comes later, from the deferred initial cluster wait in `run_radix_passes` (this
  // whole load runs in that arrive->wait window).
  template <detail::topk::select SelectDirection>
  _CCCL_DEVICE _CCCL_FORCEINLINE void load_and_histogram_first_pass(smem_keys_t& resident_keys)
  {
    using extract_bin_op_t =
      detail::topk::extract_bin_op_t<key_t, SelectDirection, policy.bits_per_pass, decomposer_t, normalize_minus_zero>;
    constexpr int total_bits = int{sizeof(key_t)} * 8;

    extract_bin_op_t extract_op(0, total_bits, decomposer_t{});
    // Histogram hot path: `atomicAdd(&temp_storage.hist[bucket], 1)` would rederive the address from `temp_storage`'s
    // 64-bit generic base every key. Pinning a hoisted 32-bit shared base for `hist[0]` (`optimizeSmemPtr`, nvbug
    // 4907996 -- as the dynamic-smem allocator does) keeps the per-key `atomicAdd` at pure 32-bit addressing
    // (`ATOMS.POPC.INC.32`). `atomicAdd` defaults to `.gpu` scope (not `.cta` -- that is `atomicAdd_block`), which
    // includes the cluster peers, so it is morally strong with (atomic against) the `.cluster`-scoped DSMEM reductions
    // racing into the leader's `hist` (the Step 2 DSMEM reduction) during the Step 1/2 overlap.
    offset_t* const hist = detail::warpspeed::optimizeSmemPtr(temp_storage.hist);
    auto add_first_pass  = [&](const key_t& key) {
      const int bucket = extract_op(key);
      _CCCL_ASSERT(bucket >= 0 && bucket < num_buckets, "histogram bucket index out of range");
      atomicAdd(hist + bucket, offset_t{1});
    };

    if constexpr (use_block_load_to_shared)
    {
      // Resident load geometry (meaningful only when this rank owns resident chunks). Chunks are written densely in
      // slot order from offset 0 at the fixed stride `local_resident_chunk_idx * policy.chunk_bytes` and read back in
      // the same order, so the consume loop needs no stored per-chunk state. `num_prologue_stages` shared mbarrier
      // stages carry the resident pipeline. The stream ring (`num_stream_stages` stages) and the resident window share
      // the same mbarrier array; the first wave is primed in consume order so the earliest-consumed copies issue first
      // (see the direction-aware layout below).
      const bool interleave_overflow_prime = layout.num_local_overflow_chunks > offset_t{0};
      const int num_prologue_stages =
        layout.num_local_resident_chunks > 0
          ? (::cuda::std::min) (+policy.pipeline_stages, static_cast<int>(layout.num_local_resident_chunks))
          : 0;

      // First wave = the `num_stream_stages` overflow chunks resident when the overflow phase begins (forward chunks
      // `[0, num_stream_stages)`, reverse chunks `[first_wave_base, num_local_overflow_chunks)`); a chunk's stage is
      // always `chunk % num_stream_stages`.
      const offset_t num_first_wave_stages = static_cast<offset_t>(num_stream_stages);
      const offset_t first_wave_base       = layout.num_local_overflow_chunks - num_first_wave_stages;

      // Distinct mbarrier stages in flight: the stream ring and the resident window share mbarriers, so the cycle spans
      // whichever is wider -- sub-case A (`num_stream_stages > num_prologue_stages`) nests the resident window in the
      // stream ring; sub-case B nests the stream ring in the resident window.
      const int num_cycle_stages = (::cuda::std::max) (num_stream_stages, num_prologue_stages);

      // Reverse consumes the first wave as stages descending from `reverse_first_stage`; forward ascending from 0. We
      // prime in that same order. The `num_stream_stages - num_prologue_stages` early-consumed stages are the
      // "complement", primed up-front onto fresh mbarriers for maximal overlap; the `num_prologue_stages` late-consumed
      // stages are the "resident window", primed as the resident consume loop frees their shared mbarriers.
      const int reverse_first_stage =
        interleave_overflow_prime
          ? static_cast<int>((layout.num_local_overflow_chunks - offset_t{1}) % num_first_wave_stages)
          : 0;

      // `stage_base` places the resident window on the late-consumed stages. Forward: shift up by the early-consumed
      // count `num_stream_stages - num_prologue_stages` (nonzero only when `num_stream_stages > num_prologue_stages`,
      // which forces `num_prologue_stages == num_local_resident_chunks`, so no reload). Reverse: the late-consumed
      // stages form the cyclic window starting at `(reverse_first_stage + 1) % num_cycle_stages` (==
      // `num_local_overflow_chunks % num_stream_stages` for sub-case A).
      int stage_base = 0;
      if constexpr (first_wave_is_forward)
      {
        if (interleave_overflow_prime && num_prologue_stages > 0 && num_stream_stages > num_prologue_stages)
        {
          stage_base = num_stream_stages - num_prologue_stages;
        }
      }
      else
      {
        if (num_prologue_stages > 0)
        {
          stage_base = static_cast<int>(
            (static_cast<offset_t>(reverse_first_stage) + offset_t{1}) % static_cast<offset_t>(num_cycle_stages));
        }
      }

      // Resident chunk -> mbarrier-stage rotation, chosen so the last `num_prologue_stages` resident chunks free the
      // resident window in consume order as they are consumed. Forward walks the window `+1` (ascending); `stage_rot`
      // corrects a misaligned reload tail so the last chunks still land `[stage_base, stage_base +
      // num_prologue_stages)` in order. Reverse walks the window `-1` (descending) from its top; `reverse_cycle_seed`
      // seeds the cycle position so chunk `num_local_resident_chunks-1` frees `stage_base`.
      const offset_t tail_align =
        num_prologue_stages > 0
          ? layout.num_local_resident_chunks % static_cast<offset_t>(num_prologue_stages)
          : offset_t{0};
      const offset_t stage_rot =
        (first_wave_is_forward && interleave_overflow_prime && num_prologue_stages > 0
         && num_stream_stages <= num_prologue_stages && tail_align != offset_t{0})
          ? static_cast<offset_t>(num_prologue_stages) - tail_align
          : offset_t{0};
      const int reverse_cycle_seed =
        num_prologue_stages > 0
          ? static_cast<int>(
              (layout.num_local_resident_chunks - offset_t{1}) % static_cast<offset_t>(num_prologue_stages))
          : 0;

      // Shared first-wave ring counter, seeded once in prime (== consume) order and stepped unit-stride across both the
      // up-front prime and the merged consume loop's resident re-arms: forward `+1` from chunk 0, reverse `-1` from
      // `num_local_overflow_chunks - 1` (== `fw(reverse_first_stage)`). `prime_complement` marks sub-case A, where the
      // up-front loop primes the early-consumed complement stages first and then hands the counter to the re-arms.
      const bool prime_complement = interleave_overflow_prime && num_stream_stages > num_prologue_stages;
      // Sub-case A implies `num_prologue_stages < policy.pipeline_stages`, which forces `num_prologue_stages ==
      // num_local_resident_chunks`: the resident consume loop then never reloads a resident successor (`chunk +
      // num_prologue_stages >= num_local_resident_chunks` always), so every one of the last `num_prologue_stages`
      // iterations re-arms a shared stream stage.
      _CCCL_ASSERT(!prime_complement || layout.num_local_resident_chunks == static_cast<offset_t>(num_prologue_stages),
                   "sub-case A (stream wider than the resident window) admits no resident reload");
      offset_t first_wave_chunk_idx =
        first_wave_is_forward ? offset_t{0} : (layout.num_local_overflow_chunks - offset_t{1});

      // Reverse resident chunk -> mbarrier stage (assertion + cursor cross-check): descending cycle position
      // `reverse_cycle_seed - chunk` (Euclidean) mapped into the cyclic window. Only valid when `num_prologue_stages >
      // 0`.
      [[maybe_unused]] const auto reverse_resident_stage = [&](offset_t local_resident_chunk_idx) -> int {
        const offset_t num_reverse_cycle_stages = static_cast<offset_t>(num_prologue_stages);
        const offset_t cycle_pos =
          (static_cast<offset_t>(reverse_cycle_seed) + num_reverse_cycle_stages
           - local_resident_chunk_idx % num_reverse_cycle_stages)
          % num_reverse_cycle_stages;
        const int stage_index = stage_base + static_cast<int>(cycle_pos);
        return stage_index >= num_cycle_stages ? stage_index - num_cycle_stages : stage_index;
      };

      {
        // Issue every up-front bulk copy from one TMA site, in first-wave consume order. The first
        // `num_prologue_stages` iterations load resident chunks into their dense slots over the resident-window
        // mbarriers; the rest (sub-case A) prime the early-consumed complement onto fresh stream mbarriers that overlap
        // the resident bulks (the resident-window stages are re-armed later, by the consume loop). No resident chunks
        // -> this loop arms the whole wave.
        //
        // Force nounroll: auto-unroll replicates the full TMA issue per iteration and bloats the load path.
        _CCCL_ASSERT(!interleave_overflow_prime || stream_is_forward == first_wave_is_forward,
                     "first-wave prime ran in an unexpected stream direction");
        _CCCL_ASSERT(
          !interleave_overflow_prime || static_cast<offset_t>(num_stream_stages) <= layout.num_local_overflow_chunks,
          "first wave assumes at least `num_stream_stages` overflow chunks");
        const int num_upfront_copies = prime_complement ? num_stream_stages : num_prologue_stages;
        // Resident-load mbarrier cursor (see the rotation note above): forward walks `+1` from `stage_base`, reverse
        // walks the cycle position `-1` from `reverse_cycle_seed`; both select-wrap, no runtime modulo.
        [[maybe_unused]] int resident_stage     = first_wave_is_forward ? stage_base + static_cast<int>(stage_rot) : 0;
        [[maybe_unused]] int resident_cycle_pos = reverse_cycle_seed;
        _CCCL_PRAGMA_NOUNROLL()
        for (int upfront_copy_idx = 0; upfront_copy_idx < num_upfront_copies; ++upfront_copy_idx)
        {
          // Each branch selects only its destination slot and chunk source; the shared `chunk_bulk_src` and bulk copy
          // issue once, uniformly, below.
          int stage         = 0;
          int dst_slot_idx  = 0;
          offset_t src_base = 0;
          offset_t src_idx  = 0;
          if (upfront_copy_idx < num_prologue_stages)
          {
            const offset_t local_resident_chunk_idx = static_cast<offset_t>(upfront_copy_idx);
            if constexpr (first_wave_is_forward)
            {
              _CCCL_ASSERT(
                resident_stage
                  == stage_base
                       + static_cast<int>(
                         (local_resident_chunk_idx + stage_rot) % static_cast<offset_t>(num_prologue_stages)),
                "resident issue stage desynced from its rolling counter");
              stage = resident_stage;
              if (++resident_stage == stage_base + num_prologue_stages)
              {
                resident_stage = stage_base;
              }
            }
            else
            {
              stage = stage_base + resident_cycle_pos;
              if (stage >= num_cycle_stages)
              {
                stage -= num_cycle_stages;
              }
              _CCCL_ASSERT(stage == reverse_resident_stage(local_resident_chunk_idx),
                           "resident issue stage desynced from its rolling counter");
              resident_cycle_pos = (resident_cycle_pos == 0) ? num_prologue_stages - 1 : resident_cycle_pos - 1;
            }
            dst_slot_idx = upfront_copy_idx;
            src_base     = layout.resident_base;
            src_idx      = local_resident_chunk_idx;
          }
          else
          {
            if constexpr (first_wave_is_forward)
            {
              // Map the complement index `upfront_copy_idx - num_prologue_stages` around the resident window: low
              // stages
              // `[0, stage_base)` map to themselves, the rest skip the window (`+ num_prologue_stages`, i.e. back to
              // `upfront_copy_idx`).
              stage = (upfront_copy_idx - num_prologue_stages < stage_base)
                      ? upfront_copy_idx - num_prologue_stages
                      : upfront_copy_idx;
            }
            else
            {
              // Reverse complement stages descend from `reverse_first_stage`; the ring counter already walks them, so
              // the stage is just its chunk's stage.
              stage = static_cast<int>(first_wave_chunk_idx % num_first_wave_stages);
            }
            _CCCL_ASSERT(
              num_prologue_stages == 0
                || static_cast<int>((stage - stage_base + num_cycle_stages) % num_cycle_stages) >= num_prologue_stages,
              "up-front prime stage must lie outside the resident window");
            _CCCL_ASSERT(first_wave_chunk_idx < layout.num_local_overflow_chunks
                           && first_wave_chunk_idx % num_first_wave_stages == static_cast<offset_t>(stage),
                         "first-wave chunk must map back to its stage");
            dst_slot_idx = stream_slot_base + stage;
            src_base     = layout.overflow_base;
            src_idx      = first_wave_chunk_idx;
            if constexpr (first_wave_is_forward)
            {
              first_wave_chunk_idx =
                (first_wave_chunk_idx + offset_t{1} == first_wave_base + num_first_wave_stages)
                  ? first_wave_base
                  : first_wave_chunk_idx + offset_t{1};
            }
            else
            {
              first_wave_chunk_idx =
                (first_wave_chunk_idx == first_wave_base)
                  ? first_wave_base + num_first_wave_stages - offset_t{1}
                  : first_wave_chunk_idx - offset_t{1};
            }
          }
          issue_bulk_copy(stage, key_slots + dst_slot_idx * policy.chunk_bytes, chunk_bulk_src(src_base, src_idx));
        }
      }

      // Consume this rank's chunks into the first-pass histogram through one loop and one bulk-copy site: the resident
      // chunks first (`chunk < num_local_resident_chunks`), then the overflow chunks. Each iteration consumes exactly
      // one chunk and optionally refills one stage's pipeline; the `consume_is_resident` x `refill_kind` classification
      // below names the five states it can be in. The stream is fully primed before the overflow phase (the up-front
      // loop above, plus this loop's resident re-arms) and the histogram never early-stops, so overflow visits only
      // wait/consume/prefetch and the pass ends drained. Edges are consumed after. The resident cursor cycles the
      // resident window and `streaming_stage` the stream ring `[0, num_stream_stages)`, both stepping unit-stride with
      // a select-wrap (no runtime modulo); forward ascends, reverse descends.
      enum class refill_kind
      {
        none,
        resident,
        stream
      };
      const offset_t num_local_chunks         = layout.num_local_resident_chunks + layout.num_local_overflow_chunks;
      [[maybe_unused]] int resident_stage     = first_wave_is_forward ? stage_base + static_cast<int>(stage_rot) : 0;
      [[maybe_unused]] int resident_cycle_pos = reverse_cycle_seed;
      int streaming_stage = first_wave_is_forward ? 0 : static_cast<int>(reverse_first_stage); // reverse 1st-consumed
                                                                                               // stage
      // `first_wave_chunk_idx` carries over from the up-front prime in consume order: sub-case A walked it through the
      // early-consumed complement, leaving it at the first late-consumed chunk; otherwise it still sits at its seed.
      // The last `num_prologue_stages` resident chunks free the resident window in consume order as they are consumed,
      // so their re-arms consume the counter unit-stride from here (forward `+1`, reverse `-1`).
      _CCCL_PRAGMA_NOUNROLL()
      for (offset_t local_chunk_idx = offset_t{0}; local_chunk_idx < num_local_chunks; ++local_chunk_idx)
      {
        // Consume axis: pick the chunk this iteration consumes, the stage it occupies, and step that pipeline's cursor.
        bool consume_is_resident    = true;
        int stage                   = 0;
        offset_t consume_chunk_idx  = 0; // resident: local chunk index; stream: ping-pong overflow chunk index
        offset_t overflow_visit_idx = 0; // stream only: 0-based position in the overflow sequence
        if (local_chunk_idx < layout.num_local_resident_chunks)
        {
          consume_chunk_idx = local_chunk_idx;
          if constexpr (first_wave_is_forward)
          {
            stage = resident_stage;
            _CCCL_ASSERT(
              stage
                == stage_base
                     + static_cast<int>((local_chunk_idx + stage_rot) % static_cast<offset_t>(num_prologue_stages)),
              "resident read stage desynced from its rolling counter");
            resident_stage = (resident_stage + 1 == stage_base + num_prologue_stages) ? stage_base : resident_stage + 1;
          }
          else
          {
            stage = stage_base + resident_cycle_pos;
            if (stage >= num_cycle_stages)
            {
              stage -= num_cycle_stages;
            }
            _CCCL_ASSERT(stage == reverse_resident_stage(local_chunk_idx),
                         "resident read stage desynced from its rolling counter");
            resident_cycle_pos = (resident_cycle_pos == 0) ? num_prologue_stages - 1 : resident_cycle_pos - 1;
          }
        }
        else
        {
          consume_is_resident = false;
          overflow_visit_idx  = local_chunk_idx - layout.num_local_resident_chunks;
          stage               = streaming_stage;
          consume_chunk_idx   = first_wave_is_forward
                                ? overflow_visit_idx
                                : (layout.num_local_overflow_chunks - offset_t{1} - overflow_visit_idx);
          _CCCL_ASSERT(stage == static_cast<int>(consume_chunk_idx % static_cast<offset_t>(num_stream_stages)),
                       "overflow stage desynced from its rolling ring pointer");
          // First-pass direction is the compile-time `first_wave_is_forward` (`stream_is_forward` flips only after).
          if constexpr (first_wave_is_forward)
          {
            streaming_stage = (streaming_stage + 1 == num_stream_stages) ? 0 : streaming_stage + 1;
          }
          else
          {
            streaming_stage = (streaming_stage == 0) ? num_stream_stages - 1 : streaming_stage - 1;
          }
        }

        // Refill axis (flat over the four refilling states; the remaining two fall through to `none`): a resident stage
        // refills its resident successor, or -- lacking one -- re-arms its shared stream slot with the first overflow
        // wave; a stream stage prefetches the chunk `num_stream_stages` visits ahead. `refill_chunk_idx` is a resident
        // local chunk index for `resident`, an overflow chunk index for `stream`.
        refill_kind refill        = refill_kind::none;
        offset_t refill_chunk_idx = 0;
        if (consume_is_resident
            && local_chunk_idx + static_cast<offset_t>(num_prologue_stages) < layout.num_local_resident_chunks)
        {
          refill           = refill_kind::resident;
          refill_chunk_idx = local_chunk_idx + static_cast<offset_t>(num_prologue_stages);
        }
        else if (consume_is_resident && interleave_overflow_prime && stage < num_stream_stages)
        {
          _CCCL_ASSERT(first_wave_chunk_idx % num_first_wave_stages == static_cast<offset_t>(stage),
                       "first-wave chunk must map back to its stage");
          refill           = refill_kind::stream;
          refill_chunk_idx = first_wave_chunk_idx;
          if constexpr (first_wave_is_forward)
          {
            first_wave_chunk_idx =
              (first_wave_chunk_idx + offset_t{1} == first_wave_base + num_first_wave_stages)
                ? first_wave_base
                : first_wave_chunk_idx + offset_t{1};
          }
          else
          {
            first_wave_chunk_idx =
              (first_wave_chunk_idx == first_wave_base)
                ? first_wave_base + num_first_wave_stages - offset_t{1}
                : first_wave_chunk_idx - offset_t{1};
          }
        }
        else if (!consume_is_resident
                 && overflow_visit_idx + static_cast<offset_t>(num_stream_stages) < layout.num_local_overflow_chunks)
        {
          const offset_t next_step = overflow_visit_idx + static_cast<offset_t>(num_stream_stages);
          refill                   = refill_kind::stream;
          refill_chunk_idx =
            first_wave_is_forward ? next_step : (layout.num_local_overflow_chunks - offset_t{1} - next_step);
        }
        _CCCL_ASSERT(refill != refill_kind::stream || refill_chunk_idx < layout.num_local_overflow_chunks,
                     "overflow chunk index out of range");

        // Consume: wait the classified slot, then histogram it. Resident chunks sit at their dense slot, stream chunks
        // at this stage's stream slot.
        const int consume_slot_idx =
          consume_is_resident ? static_cast<int>(consume_chunk_idx) : stream_slot_base + stage;
        const offset_t consume_base = consume_is_resident ? layout.resident_base : layout.overflow_base;
        wait_stage(stage);
        const key_t* consume_src = ::cuda::ptr_rebind<key_t>(key_slots + consume_slot_idx * policy.chunk_bytes);
        const auto consume_chunk_desc =
          get_chunk(layout.local_partition.global_index(consume_base + consume_chunk_idx),
                    layout.segment_size,
                    layout.num_cluster_head_items);
        // Only the segment's global-last chunk can be short; consumed ascending it is the last resident chunk (overflow
        // chunks are consumed after and may also be short), so every earlier resident chunk fills its slot.
        _CCCL_ASSERT(!consume_is_resident || local_chunk_idx + offset_t{1} == layout.num_local_resident_chunks
                       || consume_chunk_desc.num_items == max_chunk_items,
                     "only the last resident chunk may carry a short aligned bulk");
        for_each_chunk_key<histogram_items_per_thread_clamped>(
          consume_src, consume_chunk_desc.num_items, add_first_pass);

        // Refill: issue this stage's next copy. A resident successor lands at its dense slot; either stream case (a
        // first-wave re-arm or a reload) lands at this stage's stream slot.
        if (refill != refill_kind::none)
        {
          const bool refill_resident = refill == refill_kind::resident;
          const int refill_slot_idx  = refill_resident ? static_cast<int>(refill_chunk_idx) : stream_slot_base + stage;
          const offset_t refill_base = refill_resident ? layout.resident_base : layout.overflow_base;
          // Phase safety: re-arming before all threads clear the wait above would advance the mbarrier phase twice,
          // stranding a lagging waiter.
          __syncthreads();
          issue_bulk_copy(
            stage, key_slots + refill_slot_idx * policy.chunk_bytes, chunk_bulk_src(refill_base, refill_chunk_idx));
        }
      }

      if (interleave_overflow_prime)
      {
        // Every visit above waited its own prefetch, so the first pass ends with all copies complete; the direction
        // flip and `stream_is_primed` carry to the radix passes and final filter, which reuse the persistent stream.
        stream_is_forward = !stream_is_forward;
        stream_is_primed  = true;
      }

      if (layout.num_local_resident_chunks > 0)
      {
        // Resident region extent for the later passes (one contiguous run of aligned bulks; both boundary edges live in
        // `edge_keys`): `(num_local_resident_chunks - 1)` full `max_chunk_items` slots plus the last chunk's (possibly
        // short) aligned bulk. The sum is a `num_load_align_items` multiple because each term is.
        const offset_t num_last_resident_chunk_items = static_cast<offset_t>(
          get_chunk(layout.local_partition.global_index(
                      layout.resident_base + (layout.num_local_resident_chunks - offset_t{1})),
                    layout.segment_size,
                    layout.num_cluster_head_items)
            .num_items);
        const int num_local_resident_items = static_cast<int>(
          (layout.num_local_resident_chunks - offset_t{1}) * static_cast<offset_t>(max_chunk_items)
          + num_last_resident_chunk_items);
        _CCCL_ASSERT(num_local_resident_items % num_load_align_items == 0,
                     "the resident region must end on a load-alignment boundary");
        resident_keys = smem_keys_t(::cuda::ptr_rebind<key_t>(key_slots), num_local_resident_items);
      }

      // Stage the persistent boundary edges into `edge_keys` and consume them into the first pass, after the whole
      // resident+overflow loop (the histogram is order-independent). `stage_and_consume_edge` consumes keys each thread
      // just wrote, so no barrier is needed here. The head prefix (rank 0) precedes chunk 0; the peeled tail suffix
      // (tail owner, always when unaligned) trails the last chunk.
      if (layout.num_local_head_edge_items > 0)
      {
        stage_and_consume_edge(
          temp_storage.edge_keys, layout.block_keys_in_bulk_ptr, layout.num_local_head_edge_items, add_first_pass);
      }
      if (layout.num_local_tail_edge_items > 0)
      {
        _CCCL_ASSERT(layout.num_cluster_chunks > offset_t{0}, "a peeled tail edge requires at least one aligned chunk");
        const auto tail_chunk =
          get_chunk(layout.num_cluster_chunks - offset_t{1}, layout.segment_size, layout.num_cluster_head_items);
        const offset_t tail_raw_items = layout.segment_size - tail_chunk.offset;
        _CCCL_ASSERT(layout.num_local_tail_edge_items <= tail_raw_items,
                     "peeled tail length cannot exceed its source chunk");
        stage_and_consume_edge(
          temp_storage.edge_keys + num_load_align_items,
          layout.block_keys_in_bulk_ptr + tail_chunk.offset + (tail_raw_items - layout.num_local_tail_edge_items),
          layout.num_local_tail_edge_items,
          add_first_pass);
      }
    }
    else
    {
      _CCCL_PRAGMA_NOUNROLL()
      for (offset_t local_resident_chunk_idx = 0; local_resident_chunk_idx < layout.num_local_resident_chunks;
           ++local_resident_chunk_idx)
      {
        const offset_t chunk_idx = layout.local_partition.global_index(layout.resident_base + local_resident_chunk_idx);
        const auto chunk         = get_chunk(chunk_idx, layout.segment_size, layout.num_cluster_head_items);
        key_t* const chunk_keys =
          ::cuda::ptr_rebind<key_t>(key_slots + static_cast<int>(local_resident_chunk_idx) * policy.chunk_bytes);
        const int num_iterations = ::cuda::ceil_div(chunk.num_items, policy.threads_per_block);
        _CCCL_PRAGMA_UNROLL(histogram_items_per_thread_clamped)
        for (int j = 0; j < num_iterations; ++j)
        {
          const int item_idx = j * policy.threads_per_block + tid;
          if (item_idx < chunk.num_items)
          {
            const key_t key =
              layout.block_keys_in[static_cast<segment_size_val_t>(chunk.offset + static_cast<offset_t>(item_idx))];
            chunk_keys[item_idx] = key;
            add_first_pass(key);
          }
        }
      }

      // Consume the overflow chunks straight from gmem (the block-load path consumes them in the merged loop above,
      // reusing the resident load's stage mbarriers). No overlap work: this pass already consumed its resident keys
      // above.
      consume_overflow_keys<histogram_items_per_thread_clamped>(add_first_pass, [] {});
    }

    const int num_local_resident_items = static_cast<int>(resident_keys.size());
    _CCCL_ASSERT(
      num_local_resident_items == 0 || static_cast<offset_t>(num_local_resident_items) <= max_block_resident_items,
      "Dynamic shared memory block_tile is too small");
  }

  // Fill the `layout` member for this block's `segment_id`/`segment_size`. Called once at the top of `run`.
  _CCCL_DEVICE _CCCL_FORCEINLINE void compute_segment_layout()
  {
    layout.block_keys_in = d_key_segments_it[segment_id];
    layout.segment_size  = static_cast<offset_t>(segment_size);

    layout.block_keys_in_bulk_ptr = nullptr;
    layout.num_cluster_head_items = 0;
    if constexpr (use_block_load_to_shared)
    {
      layout.block_keys_in_bulk_ptr = ::cuda::std::to_address(layout.block_keys_in);
      _CCCL_ASSERT(layout.block_keys_in_bulk_ptr != nullptr, "a bulk-load segment must have a valid input pointer");
      // Items from `block_keys_in_bulk_ptr` to the next `load_align_bytes` boundary (0 when already aligned), clamped
      // to the segment. `load_align_bytes` is a multiple of `sizeof(key_t)`, so the aligned pointer lands on a key
      // boundary and the pointer difference is already an exact item count; narrow it to 32-bit `offset_t` right away.
      const offset_t head_to_boundary_offset_items = static_cast<offset_t>(
        ::cuda::align_up(layout.block_keys_in_bulk_ptr, policy.load_align_bytes) - layout.block_keys_in_bulk_ptr);
      layout.num_cluster_head_items = (::cuda::std::min) (head_to_boundary_offset_items, layout.segment_size);
      // Distance to the next alignment boundary is < one alignment unit, so the head prefix fits its `edge_keys` slot.
      _CCCL_ASSERT(layout.num_cluster_head_items < static_cast<offset_t>(num_load_align_items),
                   "the unaligned head prefix must be shorter than one load-alignment unit");
    }
    // Number of aligned chunks covering the segment: the unaligned head prefix (`num_cluster_head_items`) is a separate
    // edge, not a chunk, so the aligned region that follows the head prefix, `[num_cluster_head_items, segment_size)`,
    // chunks uniformly at `max_chunk_items` (a segment lying entirely before the first alignment boundary yields
    // `num_cluster_head_items == segment_size` and zero chunks). The generic fallback skips the alignment/peeling path
    // and keeps `num_cluster_head_items == 0`; the two chunkings may assign keys to CTAs differently, but top-k only
    // depends on the multiset of keys the cluster covers.
    _CCCL_ASSERT(layout.num_cluster_head_items <= layout.segment_size, "head prefix cannot exceed the segment");
    layout.num_cluster_chunks = static_cast<offset_t>(
      smem_layout_t::num_chunks_from_num_items(layout.segment_size - layout.num_cluster_head_items));

    // Logical cluster blocks: the CTAs that actually receive chunks (at least `policy.min_chunks_per_block` each), <=
    // the launched `num_full_cluster_blocks`. Ranks at or beyond it are idle -- they own no chunks, consume nothing,
    // and never lead -- but stay resident and still arrive at every cluster barrier (a returned CTA would hang the
    // barrier; see the TODOs at the barrier sites). Derived from this CTA's head-aligned `num_cluster_chunks` so it
    // matches the partition exactly. Collapses to 1 on the single-CTA path and stays at `num_full_cluster_blocks` for
    // host-exact sizes (the dispatch already matched it).
    layout.num_logical_cluster_blocks = is_single_cta ? 1u : num_full_cluster_blocks;
    if constexpr (enable_runtime_single_cta)
    {
      if (!is_single_cta)
      {
        layout.num_logical_cluster_blocks = compute_num_logical_cluster_blocks(
          layout.num_cluster_chunks, policy.min_chunks_per_block, num_full_cluster_blocks);
      }
    }
    _CCCL_ASSERT(layout.num_logical_cluster_blocks >= 1u && layout.num_logical_cluster_blocks <= num_full_cluster_blocks
                   && (!is_single_cta || layout.num_logical_cluster_blocks == 1u),
                 "logical cluster blocks must stay in [1, full cluster blocks] and be 1 on the single-CTA path");
    layout.is_idle_rank = cluster_block_rank >= layout.num_logical_cluster_blocks;

    // Assign this rank's chunks. Both layouts keep chunk 0 on rank 0 (which also
    // stages the head edge) and the tail chunk on a single rank; the per-chunk alignment, resident/streaming split, and
    // streaming ping-pong depend only on the global chunk index, not on which rank owns it. The blocked layout is
    // required by the deterministic tie-break (its cross-CTA scan assumes CTA-rank order matches ascending contiguous
    // global-index ranges), so it is selected exactly when `needs_set_determinism` is set; otherwise chunk `i` goes to
    // rank `i % num_logical_cluster_blocks` (strided).
    if (layout.is_idle_rank)
    {
      layout.local_partition = chunk_partition{offset_t{0}, offset_t{1}, offset_t{0}};
    }
    else
    {
      _CCCL_ASSERT(cluster_block_rank < layout.num_logical_cluster_blocks,
                   "a working rank must satisfy rank < logical cluster blocks");
      // TODO(cccl): both branches divide by `num_logical_cluster_blocks` (runtime, non-power-of-two). Critical path:
      // runs at kernel entry and gates the first TMA copy, so it is one-time but has nothing earlier to hide it. For
      // host-exact sizes the logical cluster equals the launch (`enable_runtime_single_cta == false`), so this divisor
      // is host-known: precompute a `cuda::fast_mod_div` on the host and pass it in to turn the divide into a
      // multiply-shift. N/A when the logical cluster is device-collapsed (deferred/sequence sizes).
      if constexpr (needs_set_determinism)
      {
        const offset_t max_block_chunks =
          ::cuda::ceil_div(layout.num_cluster_chunks, layout.num_logical_cluster_blocks);
        const offset_t first = static_cast<offset_t>(cluster_block_rank) * max_block_chunks;
        const offset_t num_local_chunks =
          (first < layout.num_cluster_chunks)
            ? (::cuda::std::min) (max_block_chunks, layout.num_cluster_chunks - first)
            : offset_t{0};
        layout.local_partition = chunk_partition{first, offset_t{1}, num_local_chunks};
      }
      else
      {
        // Strided count: rank `r` owns `ceil((num_cluster_chunks - r) / num_logical_cluster_blocks)`, written as
        // `(num_cluster_chunks - 1 - r) / num_logical_cluster_blocks + 1`; the `r >= num_cluster_chunks` guard keeps
        // the subtraction from underflowing the unsigned `offset_t`.
        const offset_t num_local_chunks =
          (cluster_block_rank < layout.num_cluster_chunks)
            ? static_cast<offset_t>(
                (layout.num_cluster_chunks - 1 - cluster_block_rank) / layout.num_logical_cluster_blocks + 1)
            : offset_t{0};
        layout.local_partition = chunk_partition{
          static_cast<offset_t>(cluster_block_rank),
          static_cast<offset_t>(layout.num_logical_cluster_blocks),
          num_local_chunks};
      }
    }

    // Leader rank. The leader owns the cluster-merged histogram and the shared `state`, and is always a working rank
    // (`< num_logical_cluster_blocks`). The deterministic tie-break makes the leader the *last* CTA in scan order so it
    // never needs its own (merged-away) local candidate count: prefer-smallest scans ascending by rank (leader = last
    // logical rank), prefer-largest scans descending (leader = rank 0). The nondeterministic path keeps rank 0.
    layout.leader_rank = (needs_set_determinism && !is_tie_reversed) ? (layout.num_logical_cluster_blocks - 1u) : 0u;
    _CCCL_ASSERT(layout.leader_rank < layout.num_logical_cluster_blocks, "leader must be a working rank");

    // `state`, `hist[0]`, and `leader_rank` are all loop-invariant across the radix passes, so the DSMEM remaps the
    // blocks use to reach the leader (its per-pass `state` and the Step 2 histogram reduction target) are hoisted here,
    // once per segment, rather than repeated every pass. `leader_state32` is always mapped -- the single-CTA path runs
    // in a size-1 cluster, so rank 0 maps to itself and the state reads take the same `ld.shared::cluster` path as a
    // wide cluster. `leader_hist32` is skipped there because the single CTA never reduces (`cluster_block_rank ==
    // leader_rank`).
    const ::cuda::std::uint32_t state_smem32 =
      static_cast<::cuda::std::uint32_t>(__cvta_generic_to_shared(&temp_storage.state));
    asm("mapa.shared::cluster.u32 %0, %1, %2;"
        : "=r"(layout.leader_state32)
        : "r"(state_smem32), "r"(layout.leader_rank));
    if (!is_single_cta)
    {
      const ::cuda::std::uint32_t hist_smem32 =
        static_cast<::cuda::std::uint32_t>(__cvta_generic_to_shared(temp_storage.hist));
      asm("mapa.shared::cluster.u32 %0, %1, %2;"
          : "=r"(layout.leader_hist32)
          : "r"(hist_smem32), "r"(layout.leader_rank));
    }

    // Resident vs. streaming split, decided independently per CTA (CTAs need not agree -- cross-CTA traffic and every
    // cluster barrier is reached uniformly). A CTA whose chunks fit its resident slots (`local_partition.num_chunks <=
    // num_local_slots`) keeps them all resident and streams nothing; an overflowing CTA reserves a round-robin
    // streaming region at the tail of its block_tile and re-streams its overflow chunks from gmem each pass via the
    // overflow stream.
    //
    // Boundary edges (the unaligned head prefix on rank 0 and the unaligned tail suffix on the tail owner) cannot use
    // the aligned TMA stream, so both are always peeled into the persistent `edge_keys` buffer. Only that unaligned
    // suffix is excluded; the tail chunk's aligned bulk is then a normal aligned chunk (possibly shorter than a full
    // slot) that can be resident or streamed like any other. Peeling both boundaries means streaming needs only
    // `num_local_slots >= 1`.
    //
    // `num_local_stream_slots` is right-sized: clamped into `[1, num_local_slots]` when streaming; deep overflows still
    // get the full `policy.pipeline_stages` depth. The generic fallback has no async pipeline (it re-reads overflow
    // from gmem each pass and peels nothing), so it reserves no streaming slots. Dispatch guarantees >= 1 whole chunk
    // slot of capacity, so the streaming clamp below is well-defined.
    _CCCL_ASSERT(max_block_resident_items >= static_cast<offset_t>(max_chunk_items)
                   && max_block_resident_items % static_cast<offset_t>(max_chunk_items) == offset_t{0},
                 "block tile capacity must be a positive whole number of chunk slots");
    const offset_t num_local_slots              = max_block_resident_items / static_cast<offset_t>(max_chunk_items);
    [[maybe_unused]] const bool needs_streaming = layout.local_partition.num_chunks > num_local_slots;

    // The unaligned suffix of the global tail chunk, peeled into `edge_keys` when this rank owns it (block-load path
    // only; the generic fallback reads any trailing items straight from gmem and never peels). Stays 0 for every other
    // rank and for an aligned tail, so it doubles as the "peel this tail" predicate.
    offset_t tail_suffix_items = offset_t{0};
    if constexpr (use_block_load_to_shared)
    {
      // This rank owns the global tail iff its last owned chunk is chunk `num_cluster_chunks-1` (its local index
      // `local_partition.num_chunks-1`, true for both the strided and blocked partitions).
      if (layout.local_partition.num_chunks > 0
          && layout.local_partition.global_index(layout.local_partition.num_chunks - offset_t{1})
               == layout.num_cluster_chunks - offset_t{1})
      {
        const auto tail_chunk =
          get_chunk(layout.num_cluster_chunks - offset_t{1}, layout.segment_size, layout.num_cluster_head_items);
        tail_suffix_items = (layout.segment_size - tail_chunk.offset) - static_cast<offset_t>(tail_chunk.num_items);
      }
    }

    // Streaming-slot reservation: clamped into `[1, num_local_slots]` when this rank overflows, else 0.
    offset_t num_local_stream_slots = offset_t{0};
    if constexpr (use_block_load_to_shared)
    {
      if (needs_streaming)
      {
        const offset_t num_local_excess_chunks = layout.local_partition.num_chunks - num_local_slots;
        const offset_t num_local_desired_stream_slots =
          (::cuda::std::min) (static_cast<offset_t>(policy.pipeline_stages), num_local_excess_chunks);
        num_local_stream_slots = ::cuda::std::clamp(num_local_desired_stream_slots, offset_t{1}, num_local_slots);
      }
    }
    layout.num_local_resident_slots = num_local_slots - num_local_stream_slots;
    layout.num_local_resident_chunks =
      (::cuda::std::min) (layout.local_partition.num_chunks, layout.num_local_resident_slots);
    // Resident chunks stay within the first `num_local_resident_slots` slots; the streaming region occupies the slots
    // `[num_local_resident_slots, num_local_slots)`, so both regions live inside the allocated block_tile buffer.
    _CCCL_ASSERT(layout.num_local_resident_chunks <= layout.num_local_resident_slots,
                 "Dynamic shared memory block_tile is too small");

    layout.num_local_overflow_chunks =
      (layout.local_partition.num_chunks > layout.num_local_resident_chunks)
        ? (layout.local_partition.num_chunks - layout.num_local_resident_chunks)
        : offset_t{0};
    // Rank-local base of the resident and overflow (streamed) chunk windows. Default: resident `[0,
    // num_local_resident_chunks)`, overflow the high-index rest. `is_residency_reversed` swaps them: resident
    // `[num_local_overflow_chunks, local_partition.num_chunks)`, overflow `[0, num_local_overflow_chunks)`.
    layout.resident_base          = is_residency_reversed ? layout.num_local_overflow_chunks : offset_t{0};
    layout.overflow_base          = is_residency_reversed ? offset_t{0} : layout.num_local_resident_chunks;
    layout.num_local_stream_slots = num_local_stream_slots;

    // Persistent boundary-edge lengths: the head prefix lives on rank 0 (`num_cluster_head_items` is 0 on the generic
    // fallback and for an aligned base); the peeled tail suffix lives on the tail owner whenever it is unaligned.
    layout.num_local_head_edge_items = (cluster_block_rank == 0u) ? static_cast<int>(layout.num_cluster_head_items) : 0;
    layout.num_local_tail_edge_items = static_cast<int>(tail_suffix_items);
  }

  // Radix histogram/scan passes: refine the splitter one `policy.bits_per_pass` digit at a time until the top-k prefix
  // is pinned down (or early stop fires). Folds `kth_key_bits_local` up digit by digit and returns the number of passes
  // that actually ran (`num_executed_passes`), which the final filter uses to size its identify operator.
  template <detail::topk::select SelectDirection>
  _CCCL_DEVICE _CCCL_FORCEINLINE int run_radix_passes(smem_keys_t resident_keys, key_prefix_t& kth_key_bits_local)
  {
    using extract_bin_op_t =
      detail::topk::extract_bin_op_t<key_t, SelectDirection, policy.bits_per_pass, decomposer_t, normalize_minus_zero>;
    using identify_candidates_op_t = detail::topk::
      identify_candidates_op_t<key_t, SelectDirection, policy.bits_per_pass, decomposer_t, normalize_minus_zero>;

    constexpr int total_bits = int{sizeof(key_t)} * 8;
    constexpr int num_passes = detail::topk::calc_num_passes<key_t>(policy.bits_per_pass);

    int num_executed_passes = num_passes;
    // No unroll pragma on purpose: the compiler's partial/full auto-unroll beats forced nounroll here.
    for (int pass = 0; pass < num_passes; ++pass)
    {
      const bool is_first_pass = (pass == 0);

      // `kth_key_bits_local` already holds the splitter digits for passes `0..pass-1`: each block folded the leader's
      // published `kth_bucket` into it at the end of the previous pass (see the end of this loop). Pass 0 needs no
      // filtering (all keys are candidates), so it is handled by the fused first-pass load above.
      if (!is_first_pass)
      {
        identify_candidates_op_t identify_op(&kth_key_bits_local, pass, total_bits, decomposer_t{});
        extract_bin_op_t extract_op(pass, total_bits, decomposer_t{});

        // Step 1: block-private histogram. Same pinned 32-bit base + `.gpu`-scope `atomicAdd` as
        // `load_and_histogram_first_pass` (see there for the addressing/scope rationale).
        offset_t* const hist = detail::warpspeed::optimizeSmemPtr(temp_storage.hist);
        auto add_hist        = [&](const key_t& key) {
          if (identify_op(key) == detail::topk::candidate_class::candidate)
          {
            const int bucket = extract_op(key);
            _CCCL_ASSERT(bucket >= 0 && bucket < num_buckets, "histogram bucket index out of range");
            atomicAdd(hist + bucket, offset_t{1});
          }
        };

        // Resident-chunk histogram, deferred into the overflow stream so it overlaps the stream's in-flight first
        // reload wave (see `consume_overflow_keys`). The histogram is order-independent, so consuming resident keys
        // between the stream's load issue and its wait does not change the result.
        const auto consume_resident_hist = [&] {
          if constexpr (use_block_load_to_shared)
          {
            for_each_chunk_key<histogram_items_per_thread_clamped>(
              resident_keys.data(), static_cast<int>(resident_keys.size()), add_hist);
          }
          else
          {
            _CCCL_PRAGMA_NOUNROLL()
            for (offset_t local_resident_chunk_idx = 0; local_resident_chunk_idx < layout.num_local_resident_chunks;
                 ++local_resident_chunk_idx)
            {
              const offset_t chunk_idx =
                layout.local_partition.global_index(layout.resident_base + local_resident_chunk_idx);
              const auto chunk = get_chunk(chunk_idx, layout.segment_size, layout.num_cluster_head_items);
              for_each_chunk_key<histogram_items_per_thread_clamped>(
                ::cuda::ptr_rebind<key_t>(key_slots + static_cast<int>(local_resident_chunk_idx) * policy.chunk_bytes),
                chunk.num_items,
                add_hist);
            }
          }
        };

        // Re-stream the overflow chunks into this pass's histogram, overlapping the resident-chunk histogram with the
        // first wave of reload bulk copies. Ping-pongs direction and reuses the turn-around chunks left resident by the
        // previous pass.
        consume_overflow_keys<histogram_items_per_thread_clamped>(add_hist, consume_resident_hist);

        // Consume the persistent boundary edges (loaded once in the first pass) into this pass's histogram, alongside
        // the resident and overflow keys. Keeps every owner's per-bucket counts (the source of its
        // `num_local_strictly_selected` and `num_local_candidates`, the cross-CTA scan inputs) inclusive of its edge
        // candidates.
        consume_boundary_edges(layout.num_local_head_edge_items, layout.num_local_tail_edge_items, add_hist);
      }

      // Local barrier is enough here: all Step 1 / Step 2 writes to `hist[]` are atomic at compatible scopes (see Step
      // 1 dispatch). The cluster-wide ordering before Step 3's leader read of the merged `hist[]` is supplied by the
      // split post-reduction cluster wait further below.
      __syncthreads();

      // First pass only: complete the deferred initial cluster barrier here. `process_impl` issued its matching
      // `cluster_arrive` right after zeroing `state`/`hist`, so the cluster-arrival latency overlapped the fused
      // first-pass load + histogram. The wait must precede the first cross-CTA access -- the Step-2 reductions just
      // below, which need the leader's `hist` visibly zeroed.
      if (is_first_pass)
      {
        cluster_or_block_wait(is_single_cta);
      }

      // Step 2: non-leader blocks reduce their per-bucket raw counts into the leader's `hist` via cluster-scope DSMEM
      // atomics. The leader skips this to avoid double-counting its own contribution; idle ranks
      // (`>= num_logical_cluster_blocks`) have an all-zero histogram, so they skip the reduction entirely (the loop
      // would only read zeros).
      if (cluster_block_rank != layout.leader_rank && !layout.is_idle_rank)
      {
        // Reduce each non-zero bucket into the leader's `hist` through DSMEM: `layout.leader_hist32` is this block's
        // `hist[0]` remapped to the leader's `shared::cluster` window (identical per-CTA layouts, `mapa` hoisted into
        // `compute_segment_layout`), so bucket `i` is reached by the constant offset `i * sizeof(offset_t)` and a
        // cluster-scope `red.add` accumulates it -- no 64-bit pointer, no memory descriptor. Cluster scope makes it
        // mutually atomic with the leader's own `hist` `atomicAdd`s (see `load_and_histogram_first_pass`).
        //
        // Same split as `reset_hist`: unroll the full strided rounds, then (only when there's a remainder) at most one
        // more guarded reduction.
        const auto reduce_bucket = [&](int i) {
          const offset_t num_local_bucket_keys = temp_storage.hist[i];
          if (num_local_bucket_keys != 0)
          {
            const ::cuda::std::uint32_t remote =
              layout.leader_hist32 + static_cast<::cuda::std::uint32_t>(i) * sizeof(offset_t);
            asm volatile("red.relaxed.cluster.shared::cluster.add.u32 [%0], %1;"
                         :
                         : "r"(remote), "r"(num_local_bucket_keys)
                         : "memory");
          }
        };
        constexpr int full_rounds = num_buckets / policy.threads_per_block;
        _CCCL_PRAGMA_UNROLL_FULL()
        for (int r = 0; r < full_rounds; ++r)
        {
          reduce_bucket(r * policy.threads_per_block + tid);
        }
        if constexpr (num_buckets % policy.threads_per_block != 0)
        {
          if (const int i = full_rounds * policy.threads_per_block + tid; i < num_buckets)
          {
            reduce_bucket(i);
          }
        }
      }

      // Split the post-reduction cluster barrier: arrive once the reductions are released, then overlap the
      // non-leaders' own-histogram scan (block-local) with the cluster-arrival latency, and only wait before the leader
      // reads the merged `hist`.
      // TODO(cccl): idle ranks arrive here only because the cluster barrier spans the whole launched cluster. An
      // mbarrier over just the active ranks would let them exit and free their SM slots instead of spinning here.
      cluster_or_block_arrive(is_single_cta);

      // Step 3 (non-leader half, run in the arrive->wait window): each non-leader exclusive-scans its *own* (un-merged)
      // histogram into registers -- the leader is otherwise the only block doing useful work at Step 3. Once the leader
      // publishes `kth_bucket` below, the lane owning it reads its exclusive prefix (this block's keys strictly above
      // the splitter this pass -> `num_local_strictly_selected`) and its raw bucket count (-> `num_local_candidates`).
      // Keeping the scan in registers lets `hist` reset on the normal schedule (the regs survive the reset and the next
      // sync).
      offset_t local_prefixes[buckets_per_thread]{};
      offset_t local_hist_vals[buckets_per_thread]{};
      if (cluster_block_rank != layout.leader_rank && !layout.is_idle_rank)
      {
        _CCCL_PRAGMA_UNROLL_FULL()
        for (int j = 0; j < buckets_per_thread; ++j)
        {
          const int bucket   = tid * buckets_per_thread + j;
          local_hist_vals[j] = (bucket < num_buckets) ? temp_storage.hist[bucket] : offset_t{0};
        }
        block_scan_t(temp_storage.scan_storage).ExclusiveSum(local_hist_vals, local_prefixes);
      }

      cluster_or_block_wait(is_single_cta);

      // Step 3 (leader half): the leader prefix-scans the merged `hist` (raw counts, all reductions now visible) and
      // updates the cluster-shared `state`. Subsequent reads (end-of-pass fold, last filter) observe these writes after
      // the next cluster sync.
      if (cluster_block_rank == layout.leader_rank)
      {
        leader_identify_kth_bucket();
      }

      if (pass + 1 < num_passes)
      {
        // Unconditional barrier: every working rank just read `hist` (the leader via its BlockScan, non-leaders via the
        // scan above), so order all of those reads before any rank resets `hist`.
        __syncthreads();
        reset_hist();
      }
      // TODO(cccl): see the barrier above -- idle ranks arrive here only to keep the cluster barrier reachable.
      cluster_or_block_sync(is_single_cta);

      // End-of-pass splitter fold. Every block pulls the leader's just-published `result` pair once through DSMEM (a
      // single naturally-aligned `u64`, ordered by the `cluster_or_block_sync()` above) and reads both halves from
      // that one load: working threads fold the `kth_bucket` digit into their own `kth_key_bits_local` (so the full
      // splitter key is reconstructed locally without a broadcast), and every block -- including idle ranks -- reuses
      // the same value for the uniform early-stop check below, so the whole cluster breaks together.
      const pass_result_t pass_result = leader_state_load<pass_result_t>(offsetof(state_t, result));
      if (!layout.is_idle_rank)
      {
        const int bucket = static_cast<int>(pass_result.kth_bucket);
        _CCCL_ASSERT(bucket >= 0 && bucket < num_buckets, "published splitter bucket index is out of range");
        detail::topk::set_kth_key_bits<key_t, policy.bits_per_pass>(kth_key_bits_local, pass, bucket);
        num_executed_passes = pass + 1;

        // Non-leader: the lane owning the splitter bucket holds its exclusive prefix and raw count in registers from
        // the scan above. Accumulate the strictly-selected count and overwrite `num_local_candidates` with this pass's
        // splitter-bucket count (the last pass's value is what the filter reads, however the loop exits). The leader's
        // `hist` is merged, so it derives its own counts from the scan total instead (see the filter).
        if (cluster_block_rank != layout.leader_rank)
        {
          const int owner = bucket / buckets_per_thread;
          if (tid == owner)
          {
            const int slot = bucket - owner * buckets_per_thread;
            atomicAdd(&temp_storage.num_local_strictly_selected, local_prefixes[slot]);
            temp_storage.num_local_candidates = local_hist_vals[slot];
          }
        }
      }
#ifndef CUB_DISABLE_CLUSTER_TOPK_EARLY_STOP
      // Early stop: the leader sets `early_stop` when the splitter bucket holds exactly the remaining `k` candidates,
      // so no further radix refinement can change the result. Every block decodes the same flag from the `pass_result`
      // it just loaded and breaks together; `num_executed_passes`/`kth_key_bits_local` then match what the original
      // top-of-next-pass break produced.
      if (pass_result.early_stop != 0)
      {
        break;
      }
#endif
    }
    return num_executed_passes;
  }

  template <detail::topk::select SelectDirection>
  _CCCL_DEVICE _CCCL_FORCEINLINE void run()
  {
    using identify_candidates_op_t = detail::topk::
      identify_candidates_op_t<key_t, SelectDirection, policy.bits_per_pass, decomposer_t, normalize_minus_zero>;

    constexpr int total_bits = int{sizeof(key_t)} * 8;
    // Only read inside the `needs_set_determinism` branch below; unused otherwise.
    [[maybe_unused]] constexpr int num_passes = detail::topk::calc_num_passes<key_t>(policy.bits_per_pass);

    // `process_impl` handles `k == 0` and select-all, so the radix path sees a strict `0 < k < segment_size`.
    _CCCL_ASSERT(k > out_offset_t{0} && static_cast<segment_size_val_t>(k) < segment_size,
                 "radix path requires 0 < k < segment size");
    compute_segment_layout();

    // Per-block local copy of `kth_key_bits` so each key check hits the block's own SMEM rather than DSMEM during the
    // histogram loop. Built up one splitter digit per pass from the leader's published `kth_bucket` (see
    // `run_radix_passes`), so the full key is never broadcast.
    key_prefix_t kth_key_bits_local = {};

    // Size the persistent overflow-streaming window for this segment; a no-op when this rank has no overflow.
    init_overflow_stream();

    // Preselect the streaming ping-pong direction. A streaming rank flips direction once per histogram pass, so the
    // leftover after the compile-time `num_passes` passes is `initial ^ (num_passes & 1)`; choosing `initial =
    // (!is_tie_reversed) ^ (num_passes & 1)` makes that leftover `== !is_tie_reversed` -- exactly what the
    // deterministic filter's straddling CTA needs to reuse its resident turn-around chunks with no re-prime (see
    // `process_overflow`; early exit runs fewer passes but then has no straddler, so direction is
    // moot). Non-deterministic filtering is order-independent, so leave its historical `stream_is_forward` start
    // untouched.
    if constexpr (needs_set_determinism)
    {
      stream_is_forward = (!is_tie_reversed) ^ ((num_passes & 1) != 0);
    }

    // Contiguous resident-key window staged in SMEM (block-load path); read once per radix pass and in the final
    // filter. Rebound to the real resident window by `load_and_histogram_first_pass`.
    smem_keys_t resident_keys;

    // Front-load all stage mbarrier inits before any bulk copy issues; the barrier below orders them ahead of the first
    // issue (see `init_load_barriers`). The generic fallback has no mbarriers but keeps the same pass-start barrier.
    if constexpr (use_block_load_to_shared)
    {
      init_load_barriers();
    }
    __syncthreads();

    load_and_histogram_first_pass<SelectDirection>(resident_keys);

    // Publish the first pass's staged `edge_keys` and per-rank histogram block-wide before the radix passes read them.
    __syncthreads();

    const int num_executed_passes = run_radix_passes<SelectDirection>(resident_keys, kth_key_bits_local);

    // -----------------------------------------------------------------------
    // Final filter pass: write the top-k keys for this segment. Strictly-
    // selected keys go to the front; the `num_cluster_tie_winners` tied candidates fill the
    // back. `kth_key_bits_local` already holds the full splitter key (folded
    // from each pass's bucket above), so no broadcast is needed here.
    // -----------------------------------------------------------------------
    auto block_keys_out = d_key_segments_out_it[segment_id];

    // `num_executed_passes` controls how many radix levels of `kth_key_bits_local` are significant. After an early-stop
    // break, only the first `num_executed_passes` digits of the splitter were folded; comparing all bits would treat
    // the (still-zero) trailing digits as smaller and erroneously reject candidates that share the identified prefix.
    identify_candidates_op_t identify_op(&kth_key_bits_local, num_executed_passes, total_bits, decomposer_t{});

    // Publish the final pass's per-rank `num_local_strictly_selected`/`num_local_candidates` (written by one lane after
    // the last cluster barrier) block-wide before the final-filter scan below reads them. Each filter loads the
    // leader's `size` pair (`leftover_k` + `num_cluster_candidates`) in a single 64-bit load, still within this barrier
    // epoch.
    __syncthreads();
    if constexpr (needs_set_determinism)
    {
      write_deterministic_topk<SelectDirection>(identify_op, block_keys_out, resident_keys);
    }
    else
    {
      write_nondeterministic_topk(identify_op, block_keys_out, resident_keys);
    }

    // No cluster barrier after the final filter pass: both filter paths place output via block-local SMEM atomics into
    // gmem, so the last cross-CTA DSMEM access is the scan's counter push in `prime_placement_counters`, already fenced
    // by its post-push cluster barrier (and `early_stop` is cached pre-scan). With no shared-memory access to another
    // block after the scan, a block can return without risking a "cluster target block not present" fault from a
    // straggler.
  }

  // Copies an entire segment `input[i] -> output[i]` for the select-all fast path (`k >= segment_size`). Keys and
  // values (pairs only) are staged together so both arrays' loads issue before either array's stores, keeping up to
  // `2 * copy_items` loads in flight. A per-array copy would instead order the value loads after the key stores (the
  // compiler cannot reorder across the separate loops) and expose their latency on small segments.
  _CCCL_DEVICE _CCCL_FORCEINLINE void copy_segment_select_all()
  {
    constexpr int copy_items         = copy_items_per_thread_clamped;
    const offset_t num_cluster_items = static_cast<offset_t>(segment_size);
    const offset_t cluster_tid = cluster_block_rank * static_cast<offset_t>(policy.threads_per_block) + threadIdx.x;
    const offset_t num_cluster_threads = num_full_cluster_blocks * static_cast<offset_t>(policy.threads_per_block);
    const offset_t step                = num_cluster_threads * static_cast<offset_t>(copy_items);
    auto keys_in_it                    = d_key_segments_it[segment_id];
    auto keys_out_it                   = d_key_segments_out_it[segment_id];

    // Full tiles: advance while a whole `step`-sized tile still fits (a grid-stride bound, not a precomputed count), so
    // `base` ends at `round_down(num_cluster_items, step)` with no division. Each tile batches unrolled loads then
    // stores for memory-level parallelism; the remainder below is a plain grid-stride tail.
    offset_t base = 0;
    _CCCL_PRAGMA_NOUNROLL()
    for (; base + step <= num_cluster_items; base += step)
    {
      const offset_t thread_base = base + cluster_tid;
      key_t keys[copy_items];
      [[maybe_unused]] value_t vals[copy_items];
      _CCCL_PRAGMA_UNROLL_FULL()
      for (int j = 0; j < copy_items; ++j)
      {
        const auto idx = static_cast<segment_size_val_t>(thread_base + static_cast<offset_t>(j) * num_cluster_threads);
        keys[j]        = keys_in_it[idx];
      }
      if constexpr (!is_keys_only)
      {
        auto vals_in_it = d_value_segments_it[segment_id];
        _CCCL_PRAGMA_UNROLL_FULL()
        for (int j = 0; j < copy_items; ++j)
        {
          const auto idx =
            static_cast<segment_size_val_t>(thread_base + static_cast<offset_t>(j) * num_cluster_threads);
          vals[j] = vals_in_it[idx];
        }
      }
      _CCCL_PRAGMA_UNROLL_FULL()
      for (int j = 0; j < copy_items; ++j)
      {
        const auto idx = static_cast<segment_size_val_t>(thread_base + static_cast<offset_t>(j) * num_cluster_threads);
        keys_out_it[idx] = keys[j];
      }
      if constexpr (!is_keys_only)
      {
        auto vals_out_it = d_value_segments_out_it[segment_id];
        _CCCL_PRAGMA_UNROLL_FULL()
        for (int j = 0; j < copy_items; ++j)
        {
          const auto idx =
            static_cast<segment_size_val_t>(thread_base + static_cast<offset_t>(j) * num_cluster_threads);
          vals_out_it[idx] = vals[j];
        }
      }
    }

    // Sub-tile remainder. Iterate the remainder relative to zero and offset by `base`, so every index stays in
    // `[0, num_cluster_items)` without relying on `base + cluster_tid` staying within `offset_t`.
    const offset_t num_cluster_remainder_items = num_cluster_items - base;
    // No unroll pragma on purpose: the compiler's partial auto-unroll beats forced nounroll here.
    for (offset_t item_idx = cluster_tid; item_idx < num_cluster_remainder_items; item_idx += num_cluster_threads)
    {
      const auto seg_idx   = static_cast<segment_size_val_t>(base + item_idx);
      keys_out_it[seg_idx] = keys_in_it[seg_idx];
      if constexpr (!is_keys_only)
      {
        auto vals_in_it      = d_value_segments_it[segment_id];
        auto vals_out_it     = d_value_segments_out_it[segment_id];
        vals_out_it[seg_idx] = vals_in_it[seg_idx];
      }
    }
  }

  // Set `is_single_cta` from the launched cluster (`num_full_cluster_blocks`) and this segment's size. For a
  // per-segment (deferred) size argument the launch is sized for the maximum segment, so a small segment that fits
  // resident in one CTA and is at/below the single-CTA tuning threshold is served by rank 0 alone via the barrier-free
  // path; the cluster's other CTAs are redundant and this returns false so they exit, freeing their SM slots. The
  // decision is per-segment uniform across the block, so a redundant CTA returns whole. Compiled out for host-exact
  // sizes, which the dispatch already sized to exact cluster blocks (returns true for all).
  [[nodiscard]] _CCCL_DEVICE _CCCL_FORCEINLINE bool init_logical_cluster()
  {
    if constexpr (enable_runtime_single_cta)
    {
      const bool fits_single_cta =
        is_single_cta_eligible(segment_size, max_block_resident_items, policy.single_block_max_seg_size);
      if (fits_single_cta && cluster_block_rank != 0u)
      {
        return false;
      }
      is_single_cta = (num_full_cluster_blocks == 1u) || fits_single_cta;
    }
    else
    {
      is_single_cta = (num_full_cluster_blocks == 1u);
    }
    return true;
  }

  _CCCL_DEVICE _CCCL_FORCEINLINE void process_impl()
  {
    // Raw launched cluster rank/size from the PTX special registers (replaces cooperative_groups' `this_cluster()`),
    // cached into the members. The radix path runs on the *logical* cluster (`layout.num_logical_cluster_blocks`, set
    // by `compute_segment_layout`); `init_logical_cluster` records whether a small segment collapsed onto rank 0. The
    // launched cluster blocks match the launch attribute the dispatch passed to `cudaLaunchKernelExC`.
    cluster_block_rank      = ::cuda::ptx::get_sreg_cluster_ctarank();
    num_full_cluster_blocks = ::cuda::ptx::get_sreg_cluster_nctarank();
    _CCCL_ASSERT(num_full_cluster_blocks > 0u && cluster_block_rank < num_full_cluster_blocks,
                 "hardware cluster rank must lie within a non-empty cluster");
    segment_id = static_cast<num_segments_val_t>(::cuda::ptx::get_sreg_clusterid_x());

    if (segment_id >= static_cast<num_segments_val_t>(detail::params::get_param(num_segments, num_segments_val_t{0})))
    {
      return;
    }

    // Read the clamped-to-nonnegative size before narrowing to `segment_size_val_t`, so the assert sees the caller's
    // value: sizes are clamped >= 0 and capped at 2^21, so a value exceeding 32-bit `offset_t` is a violation.
    const auto segment_size_raw = detail::params::__get_and_clamp_param_to_nonnegative(segment_sizes, segment_id);
    _CCCL_ASSERT(
      static_cast<::cuda::std::uint64_t>(segment_size_raw) <= ::cuda::std::numeric_limits<::cuda::std::uint32_t>::max(),
      "segment size must be non-negative and fit the 32-bit cluster offset type");
    segment_size = static_cast<segment_size_val_t>(segment_size_raw);
    // Clamp `k` (already floored to >= 0) to the segment size in a 64-bit width holding both operands.
    const auto k_clamped =
      (::cuda::std::min) (static_cast<::cuda::std::uint64_t>(
                            detail::params::__get_and_clamp_param_to_nonnegative(k_param, segment_id)),
                          static_cast<::cuda::std::uint64_t>(segment_size));

    if (k_clamped == 0)
    {
      return;
    }

    // Segments larger than the resident cluster_tile capacity are still handled : the overflow chunks are re-streamed
    // from gmem

    // `k_clamped <= segment_size`, which now fits `out_offset_t`, so this narrowing is safe.
    k = static_cast<out_offset_t>(k_clamped);

    // Select-all fast path: when `k` reaches the full segment
    if (static_cast<segment_size_val_t>(k) == segment_size)
    {
      copy_segment_select_all();
      return;
    }

    // Decide whether a small segment collapses onto rank 0 alone (sets `is_single_cta`). Returns false on the CTAs the
    // collapse makes redundant, which exit here.
    if (!init_logical_cluster())
    {
      return;
    }

    // Each block's elected leader thread initializes its block-local `state`. Only the leader block's copy is read (its
    // own scan directly, other blocks over DSMEM via `leader_state32`), but the leader's rank is unknown here
    // (`compute_segment_layout` derives it later from the runtime logical cluster size), so every block initializes
    // unconditionally to guarantee the eventual leader's `state` is valid before the first read.
    if (is_block_leader)
    {
      temp_storage.state.size   = size_state_t{static_cast<offset_t>(segment_size), k};
      temp_storage.state.result = pass_result_t{};
      // Front-load the scan accumulators so the initial cluster barrier below (arrive here, wait in the first pass)
      // publishes the zeros to all ranks: the final filter's `prime_placement_counters` then adds into already-zeroed
      // `selected_offset_counter`/`tie_offset_counter` (its own local seed + peers' DSMEM pushes, needing only a
      // post-push barrier). `num_local_candidates` is zeroed too so idle/leader ranks that never write it read 0.
      temp_storage.selected_offset_counter     = 0;
      temp_storage.tie_offset_counter          = 0;
      temp_storage.num_local_strictly_selected = 0;
      temp_storage.num_local_candidates        = 0;
    }
    reset_hist();
    // Only arrive here; the matching wait is deferred to just before the first cross-CTA reduction in
    // `run_radix_passes`' first pass, so the cluster-arrival latency overlaps the fused first-pass load + histogram.
    // Safe because nothing between here and that wait touches another rank's DSMEM (the first-pass histogram writes
    // only block-local `hist`; the leader's `state` and the scan counters are untouched until later).
    cluster_or_block_arrive(is_single_cta);

    [[maybe_unused]] const bool is_ok =
      detail::params::dispatch_discrete(select_directions, segment_id, [this](auto direction_tag) {
        constexpr detail::topk::select Direction = decltype(direction_tag)::value;
        this->template run<Direction>();
      });
    _CCCL_ASSERT(is_ok, "Unsupported select direction for cluster top-k");
  }
};
} // namespace detail::batched_topk_cluster

CUB_NAMESPACE_END
