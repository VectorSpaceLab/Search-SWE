// SPDX-FileCopyrightText: Copyright (c) 2011, Duane Merrill. All rights reserved.
// SPDX-FileCopyrightText: Copyright (c) 2011-2025, NVIDIA CORPORATION. All rights reserved.
// SPDX-License-Identifier: BSD-3

/**
 * @file
 * Simple binary operator functor types
 */

/******************************************************************************
 * Simple functor operators
 ******************************************************************************/

#pragma once

#include <cub/config.cuh>

#if defined(_CCCL_IMPLICIT_SYSTEM_HEADER_GCC)
#  pragma GCC system_header
#elif defined(_CCCL_IMPLICIT_SYSTEM_HEADER_CLANG)
#  pragma clang system_header
#elif defined(_CCCL_IMPLICIT_SYSTEM_HEADER_MSVC)
#  pragma system_header
#endif // no system header

#include <cub/detail/key_value_pair.cuh>

#include <cuda/__functional/maximum.h>
#include <cuda/__functional/minimum.h>
#include <cuda/__functional/operator_properties.h>
#include <cuda/std/__functional/operations.h>
#include <cuda/std/__utility/forward.h>
#include <cuda/std/__utility/integer_sequence.h>
#include <cuda/std/__utility/pair.h>
#include <cuda/std/cstdint>
#include <cuda/std/limits>

CUB_NAMESPACE_BEGIN

// TODO(bgruber): deprecate in C++17 with a note: "replace by decltype(cuda::std::not_fn(EqualityOp{}))"
/// @brief Inequality functor (wraps equality functor)
template <typename EqualityOp>
struct InequalityWrapper
{
  /// Wrapped equality operator
  EqualityOp op;

  /// Constructor
  _CCCL_HOST_DEVICE _CCCL_FORCEINLINE InequalityWrapper(EqualityOp op)
      : op(op)
  {}

  /// Boolean inequality operator, returns `t != u`
  template <typename T, typename U>
  _CCCL_HOST_DEVICE _CCCL_FORCEINLINE bool operator()(T&& t, U&& u)
  {
    return !op(::cuda::std::forward<T>(t), ::cuda::std::forward<U>(u));
  }
};

/// @brief Arg max functor (keeps the value and offset of the first occurrence
///        of the larger item)
struct ArgMax
{
  /// Boolean max operator, preferring the item having the smaller offset in
  /// case of ties
  template <typename T, typename OffsetT>
  _CCCL_HOST_DEVICE _CCCL_FORCEINLINE KeyValuePair<OffsetT, T>
  operator()(const KeyValuePair<OffsetT, T>& a, const KeyValuePair<OffsetT, T>& b) const
  {
    // Mooch BUG (device reduce argmax gk110 3.2 million random fp32)
    // return ((b.value > a.value) ||
    //         ((a.value == b.value) && (b.key < a.key)))
    //      ? b : a;

    if ((b.value > a.value) || ((a.value == b.value) && (b.key < a.key)))
    {
      return b;
    }

    return a;
  }
};

/// @brief Arg min functor (keeps the value and offset of the first occurrence
///        of the smallest item)
struct ArgMin
{
  /// Boolean min operator, preferring the item having the smaller offset in
  /// case of ties
  template <typename T, typename OffsetT>
  _CCCL_HOST_DEVICE _CCCL_FORCEINLINE KeyValuePair<OffsetT, T>
  operator()(const KeyValuePair<OffsetT, T>& a, const KeyValuePair<OffsetT, T>& b) const
  {
    // Mooch BUG (device reduce argmax gk110 3.2 million random fp32)
    // return ((b.value < a.value) ||
    //         ((a.value == b.value) && (b.key < a.key)))
    //      ? b : a;

    if ((b.value < a.value) || ((a.value == b.value) && (b.key < a.key)))
    {
      return b;
    }

    return a;
  }
};

namespace detail
{
// Uses a user-defined less-than comparator to return the minimum of an index/value pair. Compares values first, and
// indices when the values are equal.
template <typename ValueLessThen = ::cuda::std::less<>>
struct arg_reduce_op : ValueLessThen
{
  template <typename T, typename OffsetT>
  _CCCL_HOST_DEVICE _CCCL_FORCEINLINE ::cuda::std::pair<OffsetT, T>
  operator()(const ::cuda::std::pair<OffsetT, T>& a, const ::cuda::std::pair<OffsetT, T>& b) const
  {
    const auto& less = static_cast<const ValueLessThen&>(*this);
    if (less(b.second, a.second) || (!less(a.second, b.second) && b.first < a.first))
    {
      return b;
    }

    return a;
  }

  template <typename T, typename OffsetT>
  _CCCL_HOST_DEVICE _CCCL_FORCEINLINE KeyValuePair<OffsetT, T>
  operator()(const KeyValuePair<OffsetT, T>& a, const KeyValuePair<OffsetT, T>& b) const
  {
    const auto& less = static_cast<const ValueLessThen&>(*this);
    if (less(b.value, a.value) || (!less(a.value, b.value) && b.key < a.key))
    {
      return b;
    }

    return a;
  }
};

template <typename ValueLessThen>
_CCCL_DEDUCTION_GUIDE_ATTRIBUTES arg_reduce_op(ValueLessThen) -> arg_reduce_op<ValueLessThen>;

/// @brief Arg min functor (keeps the value and offset of the first occurrence of the smallest item)
using arg_min = arg_reduce_op<::cuda::std::less<>>;

//! @brief Binary functor swapping the arguments to ``operator()`` before forwarding to an inner functor
template <typename Predicate>
struct swap_args : Predicate
{
  template <typename T, typename U>
  _CCCL_HOST_DEVICE_API _CCCL_FORCEINLINE decltype(auto) operator()(T&& t, U&& u) const
  {
    return Predicate::operator()(::cuda::std::forward<U>(u), ::cuda::std::forward<T>(t));
  }
};

template <typename Predicate>
_CCCL_DEDUCTION_GUIDE_ATTRIBUTES swap_args(Predicate) -> swap_args<Predicate>;

/// @brief Arg max functor (keeps the value and offset of the first occurrence of the larger item)
using arg_max = arg_reduce_op<swap_args<::cuda::std::less<>>>;

template <typename T, typename IndexT>
// Reduction inputs supply all fields while preserving triviality.
// NOLINTNEXTLINE(cppcoreguidelines-pro-type-member-init)
struct argminmax_accum_t
{
  T min_value;
  T max_value;
  IndexT min_index;
  IndexT max_index;
};

//! @brief Reduction operator for ArgMinMax: selects the first minimum (smallest index on tie) and, if LastMax is true,
//! the last maximum (largest index on tie), otherwise the first maximum.
template <typename CompareOpT = ::cuda::std::less<>, bool LastMax = false>
struct arg_minmax_reduce_op : CompareOpT
{
  template <typename T, typename IndexT>
  _CCCL_HOST_DEVICE _CCCL_FORCEINLINE argminmax_accum_t<T, IndexT>
  operator()(const argminmax_accum_t<T, IndexT>& a, const argminmax_accum_t<T, IndexT>& b) const
  {
    const auto& less = static_cast<const CompareOpT&>(*this);
    auto result      = a;
    // first minimum: strictly smaller wins; ties keep the smaller index
    if (less(b.min_value, a.min_value) || (!less(a.min_value, b.min_value) && b.min_index < a.min_index))
    {
      result.min_value = b.min_value;
      result.min_index = b.min_index;
    }
    // maximum: strictly greater wins; ties keep the smaller index (first max) or larger index (last max)
    const bool b_wins_tie = LastMax ? b.max_index > a.max_index : b.max_index < a.max_index;
    if (less(a.max_value, b.max_value) || (!less(b.max_value, a.max_value) && b_wins_tie))
    {
      result.max_value = b.max_value;
      result.max_index = b.max_index;
    }
    return result;
  }
};

template <typename CompareOpT>
_CCCL_DEDUCTION_GUIDE_ATTRIBUTES arg_minmax_reduce_op(CompareOpT) -> arg_minmax_reduce_op<CompareOpT>;

template <typename ScanOpT>
struct ScanBySegmentOp
{
  /// Wrapped operator
  ScanOpT op;

  /// Constructor
  _CCCL_FORCEINLINE ScanBySegmentOp() = default;

  /// Constructor
  _CCCL_HOST_DEVICE _CCCL_FORCEINLINE ScanBySegmentOp(ScanOpT op)
      : op(op)
  {}

  /**
   * @brief Scan operator
   *
   * @tparam KeyValuePairT
   *   KeyValuePair pairing of T (value) and int (head flag)
   *
   * @param[in] first
   *   First partial reduction
   *
   * @param[in] second
   *   Second partial reduction
   */
  template <typename KeyValuePairT>
  _CCCL_HOST_DEVICE _CCCL_FORCEINLINE KeyValuePairT operator()(const KeyValuePairT& first, const KeyValuePairT& second)
  {
    // Both branches assign key and value before returning.
    // NOLINTNEXTLINE(cppcoreguidelines-pro-type-member-init)
    KeyValuePairT retval;
    retval.key = first.key | second.key;
#ifdef _NVHPC_CUDA // WAR bug on nvc++
    if (second.key)
    {
      retval.value = second.value;
    }
    else
    {
      // If second.value isn't copied into a temporary here, nvc++ will
      // crash while compiling the TestScanByKeyWithLargeTypes test in
      // thrust/testing/scan_by_key.cu:
      auto v2      = second.value;
      retval.value = op(first.value, v2);
    }
#else // not nvc++:
    // if (second.key) {
    //   The second partial reduction spans a segment reset, so it's value
    //   aggregate becomes the running aggregate
    // else {
    //   The second partial reduction does not span a reset, so accumulate both
    //   into the running aggregate
    // }
    retval.value = (second.key) ? second.value : op(first.value, second.value);
#endif
    return retval;
  }
};

template <class OpT>
inline constexpr bool basic_binary_op_v =
  ::cuda::__is_cuda_std_plus_v<OpT> || ::cuda::__is_cuda_minimum_v<OpT> || ::cuda::__is_cuda_maximum_v<OpT>;
} // namespace detail

/// @brief Default cast functor
template <typename B>
struct CastOp
{
  /// Cast operator, returns `(B) a`
  template <typename A>
  _CCCL_HOST_DEVICE _CCCL_FORCEINLINE B operator()(A&& a) const
  {
    return (B)::cuda::std::forward<A>(a);
  }
};

/// @brief Binary operator wrapper for switching non-commutative scan arguments
template <typename ScanOp>
class SwizzleScanOp
{
private:
  /// Wrapped scan operator
  ScanOp scan_op;

public:
  /// Constructor
  _CCCL_HOST_DEVICE _CCCL_FORCEINLINE SwizzleScanOp(ScanOp scan_op)
      : scan_op(scan_op)
  {}

  /// Switch the scan arguments
  template <typename T>
  _CCCL_HOST_DEVICE _CCCL_FORCEINLINE T operator()(const T& a, const T& b)
  {
    return scan_op(b, a);
  }
};

/**
 * @brief Reduce-by-segment functor.
 *
 * Given two cub::KeyValuePair inputs `a` and `b` and a binary associative
 * combining operator `f(const T &x, const T &y)`, an instance of this functor
 * returns a cub::KeyValuePair whose `key` field is `a.key + b.key`, and whose
 * `value` field is either `b.value` if `b.key` is non-zero, or
 * `f(a.value, b.value)` otherwise.
 *
 * ReduceBySegmentOp is an associative, non-commutative binary combining
 * operator for input sequences of cub::KeyValuePair pairings. Such sequences
 * are typically used to represent a segmented set of values to be reduced
 * and a corresponding set of {0,1}-valued integer "head flags" demarcating the
 * first value of each segment.
 *
 * @tparam ReductionOpT Binary reduction operator to apply to values
 */
template <typename ReductionOpT>
struct ReduceBySegmentOp
{
  /// Wrapped reduction operator
  ReductionOpT op;

  /// Constructor
  _CCCL_FORCEINLINE ReduceBySegmentOp() = default;

  /// Constructor
  _CCCL_HOST_DEVICE _CCCL_FORCEINLINE ReduceBySegmentOp(ReductionOpT op)
      : op(op)
  {}

  /**
   * @brief Scan operator
   *
   * @tparam KeyValuePairT
   *   KeyValuePair pairing of T (value) and OffsetT (head flag)
   *
   * @param[in] first
   *   First partial reduction
   *
   * @param[in] second
   *   Second partial reduction
   */
  template <typename KeyValuePairT>
  _CCCL_HOST_DEVICE _CCCL_FORCEINLINE KeyValuePairT operator()(const KeyValuePairT& first, const KeyValuePairT& second)
  {
    // Both branches assign key and value before returning.
    // NOLINTNEXTLINE(cppcoreguidelines-pro-type-member-init)
    KeyValuePairT retval;
    retval.key = first.key + second.key;
#ifdef _NVHPC_CUDA // WAR bug on nvc++
    if (second.key)
    {
      retval.value = second.value;
    }
    else
    {
      // If second.value isn't copied into a temporary here, nvc++ will
      // crash while compiling the TestScanByKeyWithLargeTypes test in
      // thrust/testing/scan_by_key.cu:
      auto v2      = second.value;
      retval.value = op(first.value, v2);
    }
#else // not nvc++:
    // if (second.key) {
    //   The second partial reduction spans a segment reset, so it's value
    //   aggregate becomes the running aggregate
    // else {
    //   The second partial reduction does not span a reset, so accumulate both
    //   into the running aggregate
    // }
    retval.value = (second.key) ? second.value : op(first.value, second.value);
#endif
    return retval;
  }
};

/**
 * @tparam ReductionOpT Binary reduction operator to apply to values
 */
template <typename ReductionOpT>
struct ReduceByKeyOp
{
  /// Wrapped reduction operator
  ReductionOpT op;

  /// Constructor
  _CCCL_FORCEINLINE ReduceByKeyOp() = default;

  /// Constructor
  _CCCL_HOST_DEVICE _CCCL_FORCEINLINE ReduceByKeyOp(ReductionOpT op)
      : op(op)
  {}

  /**
   * @brief Scan operator
   *
   * @param[in] first First partial reduction
   * @param[in] second Second partial reduction
   */
  template <typename KeyValuePairT>
  _CCCL_HOST_DEVICE _CCCL_FORCEINLINE KeyValuePairT operator()(const KeyValuePairT& first, const KeyValuePairT& second)
  {
    KeyValuePairT retval = second;

    if (first.key == second.key)
    {
      retval.value = op(first.value, retval.value);
    }

    return retval;
  }
};

#ifndef _CCCL_DOXYGEN_INVOKED // Do not document

//----------------------------------------------------------------------------------------------------------------------
// Predefined operators

namespace detail
{
//----------------------------------------------------------------------------------------------------------------------
// Predefined operators

template <typename Op, typename T = void>
inline constexpr bool is_cuda_minimum_maximum_v =
  ::cuda::__is_cuda_maximum_v<Op, T> || ::cuda::__is_cuda_minimum_v<Op, T>;

template <typename Op, typename T = void>
inline constexpr bool is_cuda_std_plus_mul_v =
  ::cuda::__is_cuda_std_plus_v<Op, T> || ::cuda::__is_cuda_std_multiplies_v<Op, T>;

template <typename Op, typename T = void>
inline constexpr bool is_cuda_std_bitwise_v =
  ::cuda::__is_cuda_std_bit_and_v<Op, T> || ::cuda::__is_cuda_std_bit_or_v<Op, T>
  || ::cuda::__is_cuda_std_bit_xor_v<Op, T>;

template <typename Op, typename T = void>
inline constexpr bool is_cuda_std_logical_v =
  ::cuda::__is_cuda_std_logical_and_v<Op, T> || ::cuda::__is_cuda_std_logical_or_v<Op, T>;

template <typename Op, typename T = void>
inline constexpr bool is_simd_enabled_cuda_operator =
  is_cuda_minimum_maximum_v<Op, T> || //
  is_cuda_std_plus_mul_v<Op, T> || //
  is_cuda_std_bitwise_v<Op, T>;

template <typename Op, typename T = void>
inline constexpr bool is_cuda_binary_operator =
  is_cuda_minimum_maximum_v<Op, T> || //
  is_cuda_std_plus_mul_v<Op, T> || //
  is_cuda_std_bitwise_v<Op, T> || //
  is_cuda_std_logical_v<Op, T>;

//----------------------------------------------------------------------------------------------------------------------
// Generalize Operator

template <typename Operator>
struct GeneralizeOperator
{
  using type = Operator;
};

template <template <typename = void> class Operator, typename T>
struct GeneralizeOperator<Operator<T>>
{
  using type = Operator<>;
};

template <typename Op>
using generalize_operator_t = typename GeneralizeOperator<Op>::type;

template <typename Operator>
[[nodiscard]] constexpr _CCCL_DEVICE _CCCL_FORCEINLINE auto generalize_operator(Operator op)
{
  if constexpr (::cuda::__is_cuda_std_logical_or_v<Operator> || ::cuda::__is_cuda_std_logical_and_v<Operator>
                || is_cuda_minimum_maximum_v<Operator> || is_cuda_std_plus_mul_v<Operator>
                || is_cuda_std_bitwise_v<Operator>)
  {
    return generalize_operator_t<Operator>{};
  }
  else
  {
    return op;
  }
}
} // namespace detail

#endif // !_CCCL_DOXYGEN_INVOKED

CUB_NAMESPACE_END
