// SPDX-FileCopyrightText: Copyright (c) 2011, Duane Merrill. All rights reserved.
// SPDX-FileCopyrightText: Copyright (c) 2011-2025, NVIDIA CORPORATION. All rights reserved.
// SPDX-License-Identifier: BSD-3

/**
 * @file
 * cub::WarpReduceSmem provides smem-based variants of parallel reduction of items partitioned
 * across a CUDA thread warp.
 */

#pragma once

#include <cub/config.cuh>

#if defined(_CCCL_IMPLICIT_SYSTEM_HEADER_GCC)
#  pragma GCC system_header
#elif defined(_CCCL_IMPLICIT_SYSTEM_HEADER_CLANG)
#  pragma clang system_header
#elif defined(_CCCL_IMPLICIT_SYSTEM_HEADER_MSVC)
#  pragma system_header
#endif // no system header

#include <cub/detail/constant.cuh>
#include <cub/detail/log2.cuh>
#include <cub/detail/uninitialized.cuh>
#include <cub/thread/thread_operators.cuh>
#include <cub/util_ptx.cuh>

#include <cuda/__cmath/pow2.h>
#include <cuda/__ptx/instructions/get_sreg.h>
#include <cuda/std/__bit/countr.h>
#include <cuda/std/__type_traits/integral_constant.h>

CUB_NAMESPACE_BEGIN

namespace detail
{
/**
 * @brief WarpReduceSmem provides smem-based variants of parallel reduction of items partitioned
 *        across a CUDA thread warp.
 *
 * @tparam T
 *   Data type being reduced
 *
 * @tparam LogicalWarpThreads
 *   Number of threads per logical warp
 */
template <typename T, int LogicalWarpThreads>
struct WarpReduceSmem
{
  /******************************************************************************
   * Constants and type definitions
   ******************************************************************************/

  /// Whether the logical warp size and the PTX warp size coincide
  static constexpr bool IS_ARCH_WARP = (LogicalWarpThreads == warp_threads);

  /// Whether the logical warp size is a power-of-two
  static constexpr bool IS_POW_OF_TWO = ::cuda::is_power_of_two(LogicalWarpThreads);

  /// The number of warp reduction steps
  static constexpr int STEPS = Log2<LogicalWarpThreads>::VALUE;

  /// The number of threads in half a warp
  static constexpr int HALF_WARP_THREADS = 1 << (STEPS - 1);

  /// The number of shared memory elements per warp
  static constexpr int WARP_SMEM_ELEMENTS = LogicalWarpThreads + HALF_WARP_THREADS;

  /// FlagT status (when not using ballot)
  static constexpr auto UNSET = 0x0; // Is initially unset
  static constexpr auto SET   = 0x1; // Is initially set
  static constexpr auto SEEN  = 0x2; // Has seen another head flag from a successor peer

  /// Shared memory flag type
  using SmemFlag = unsigned char;

  /// Shared memory storage layout type (1.5 warps-worth of elements for each warp)
  struct _TempStorage
  {
    T reduce[WARP_SMEM_ELEMENTS];
    SmemFlag flags[WARP_SMEM_ELEMENTS];
  };

  // Alias wrapper allowing storage to be unioned
  using TempStorage = Uninitialized<_TempStorage>;

  /******************************************************************************
   * Thread fields
   ******************************************************************************/

  _TempStorage& temp_storage;
  unsigned int lane_id;
  unsigned int member_mask;

  /******************************************************************************
   * Construction
   ******************************************************************************/

  /// Constructor
  explicit _CCCL_DEVICE _CCCL_FORCEINLINE WarpReduceSmem(TempStorage& temp_storage)
      : temp_storage(temp_storage.Alias())
      , lane_id(IS_ARCH_WARP ? ::cuda::ptx::get_sreg_laneid() : ::cuda::ptx::get_sreg_laneid() % LogicalWarpThreads)
      , member_mask(WarpMask<LogicalWarpThreads>(::cuda::ptx::get_sreg_laneid() / LogicalWarpThreads))
  {}

  /******************************************************************************
   * Utility methods
   ******************************************************************************/

  //---------------------------------------------------------------------
  // Regular reduction
  //---------------------------------------------------------------------

  /**
   * @brief Reduction step
   *
   * @tparam AllLanesValid
   *   Whether all lanes in each warp are contributing a valid fold of items
   *
   * @param[in] input
   *   Calling thread's input
   *
   * @param[in] valid_items
   *   Total number of valid items across the logical warp
   *
   * @param[in] reduction_op
   *   Reduction operator
   */
  template <bool AllLanesValid, typename ReductionOp, int STEP>
  _CCCL_DEVICE _CCCL_FORCEINLINE T
  ReduceStep(T input, int valid_items, ReductionOp reduction_op, constant_t<STEP> /*step*/)
  {
    constexpr int OFFSET = 1 << STEP;
    // Share input through buffer
    temp_storage.reduce[lane_id] = input;
    __syncwarp(member_mask);
    // Update input if peer_addend is in range
    if ((AllLanesValid && IS_POW_OF_TWO) || ((lane_id + OFFSET) < valid_items))
    {
      T peer_addend = temp_storage.reduce[lane_id + OFFSET];
      input         = reduction_op(input, peer_addend);
    }
    __syncwarp(member_mask);
    return ReduceStep<AllLanesValid>(input, valid_items, reduction_op, constant_v<STEP + 1>);
  }

  /**
   * @brief Reduction step (terminate)
   *
   * @tparam AllLanesValid
   *   Whether all lanes in each warp are contributing a valid fold of items
   *
   * @param[in] input
   *   Calling thread's input
   *
   * @param[in] valid_items
   *   Total number of valid items across the logical warp
   *
   * @param[in] reduction_op
   *   Reduction operator
   */
  template <bool AllLanesValid, typename ReductionOp>
  _CCCL_DEVICE _CCCL_FORCEINLINE T
  ReduceStep(T input, int valid_items, ReductionOp /*reduction_op*/, constant_t<STEPS> /*step*/)
  {
    return input;
  }

  //---------------------------------------------------------------------
  // Segmented reduction
  //---------------------------------------------------------------------

  /**
   * @brief Ballot-based segmented reduce
   *
   * @tparam HeadSegmented
   *   Whether flags indicate a segment-head or a segment-tail
   *
   * @param[in] input
   *   Calling thread's input
   *
   * @param[in] flag
   *   Whether or not the current lane is a segment head/tail
   *
   * @param[in] reduction_op
   *   Reduction operator
   *
   * @param[in] has_ballot
   *   Marker type for whether the target arch has ballot functionality
   */
  template <bool HeadSegmented, typename FlagT, typename ReductionOp>
  _CCCL_DEVICE _CCCL_FORCEINLINE T
  SegmentedReduce(T input, FlagT flag, ReductionOp reduction_op, ::cuda::std::true_type /*has_ballot*/)
  {
    // Get the start flags for each thread in the warp.
    unsigned warp_flags = __ballot_sync(member_mask, flag);

    if (!HeadSegmented)
    {
      warp_flags <<= 1;
    }

    // Keep bits above the current thread.
    warp_flags &= ::cuda::ptx::get_sreg_lanemask_gt();

    // Accommodate packing of multiple logical warps in a single physical warp
    if (!IS_ARCH_WARP)
    {
      warp_flags >>= (::cuda::ptx::get_sreg_laneid() / LogicalWarpThreads) * LogicalWarpThreads;
    }

    // Find next flag
    int next_flag = ::cuda::std::countr_zero(warp_flags);

    // Clip the next segment at the warp boundary if necessary
    if (LogicalWarpThreads != 32)
    {
      next_flag = ::cuda::std::min(next_flag, LogicalWarpThreads);
    }

    _CCCL_PRAGMA_UNROLL_FULL()
    for (int STEP = 0; STEP < STEPS; STEP++)
    {
      const int OFFSET = 1 << STEP;

      // Share input into buffer
      temp_storage.reduce[lane_id] = input;

      __syncwarp(member_mask);

      // Update input if peer_addend is in range
      if (OFFSET + lane_id < next_flag)
      {
        T peer_addend = temp_storage.reduce[lane_id + OFFSET];
        input         = reduction_op(input, peer_addend);
      }

      __syncwarp(member_mask);
    }

    return input;
  }

  /**
   * @brief Smem-based segmented reduce
   *
   * @tparam HeadSegmented
   *   Whether flags indicate a segment-head or a segment-tail
   *
   * @param[in] input
   *   Calling thread's input
   *
   * @param[in] flag
   *   Whether or not the current lane is a segment head/tail
   *
   * @param[in] reduction_op
   *   Reduction operator
   *
   * @param[in] has_ballot
   *   Marker type for whether the target arch has ballot functionality
   */
  template <bool HeadSegmented, typename FlagT, typename ReductionOp>
  _CCCL_DEVICE _CCCL_FORCEINLINE T
  SegmentedReduce(T input, FlagT flag, ReductionOp reduction_op, ::cuda::std::false_type /*has_ballot*/)
  {
    // Alias flags onto shared data storage
    SmemFlag* flag_storage = temp_storage.flags;

    SmemFlag flag_status = (flag) ? SET : UNSET;

    for (int STEP = 0; STEP < STEPS; STEP++)
    {
      const int OFFSET = 1 << STEP;

      // Share input through buffer
      temp_storage.reduce[lane_id] = input;

      __syncwarp(member_mask);

      // Get peer from buffer
      T peer_addend = temp_storage.reduce[lane_id + OFFSET];

      __syncwarp(member_mask);

      // Share flag through buffer
      flag_storage[lane_id] = flag_status;

      // Get peer flag from buffer
      SmemFlag peer_flag_status = flag_storage[lane_id + OFFSET];

      // Update input if peer was in range
      if (lane_id < LogicalWarpThreads - OFFSET)
      {
        if (HeadSegmented)
        {
          // Head-segmented
          if ((flag_status & SEEN) == 0)
          {
            // Has not seen a more distant head flag
            if (peer_flag_status & SET)
            {
              // Has now seen a head flag
              flag_status |= SEEN;
            }
            else
            {
              // Peer is not a head flag: grab its count
              input = reduction_op(input, peer_addend);
            }

            // Update seen status to include that of peer
            flag_status |= (peer_flag_status & SEEN);
          }
        }
        else
        {
          // Tail-segmented.  Simply propagate flag status
          if (!flag_status)
          {
            input = reduction_op(input, peer_addend);
            flag_status |= peer_flag_status;
          }
        }
      }
    }

    return input;
  }

  /******************************************************************************
   * Interface
   ******************************************************************************/

  /**
   * @brief Reduction
   *
   * @tparam AllLanesValid
   *   Whether all lanes in each warp are contributing a valid fold of items
   *
   * @param[in] input
   *   Calling thread's input
   *
   * @param[in] valid_items
   *   Total number of valid items across the logical warp
   *
   * @param[in] reduction_op
   *   Reduction operator
   */
  template <bool AllLanesValid, typename ReductionOp>
  _CCCL_DEVICE _CCCL_FORCEINLINE T Reduce(T input, int valid_items, ReductionOp reduction_op)
  {
    return ReduceStep<AllLanesValid>(input, valid_items, reduction_op, constant_v<0>);
  }

  /**
   * @brief Segmented reduction
   *
   * @tparam HeadSegmented
   *   Whether flags indicate a segment-head or a segment-tail
   *
   * @param[in] input
   *   Calling thread's input
   *
   * @param[in] flag
   *   Whether or not the current lane is a segment head/tail
   *
   * @param[in] reduction_op
   *   Reduction operator
   */
  template <bool HeadSegmented, typename FlagT, typename ReductionOp>
  _CCCL_DEVICE _CCCL_FORCEINLINE T SegmentedReduce(T input, FlagT flag, ReductionOp reduction_op)
  {
    return SegmentedReduce<HeadSegmented>(input, flag, reduction_op, ::cuda::std::true_type());
  }
};
} // namespace detail

CUB_NAMESPACE_END
