// SPDX-FileCopyrightText: Copyright (c) 2011-2021, NVIDIA CORPORATION. All rights reserved.
// SPDX-License-Identifier: BSD-3

//! @file
//! Operations for writing linear segments of data from the CUDA warp

#pragma once

#include <cub/config.cuh>

#if defined(_CCCL_IMPLICIT_SYSTEM_HEADER_GCC)
#  pragma GCC system_header
#elif defined(_CCCL_IMPLICIT_SYSTEM_HEADER_CLANG)
#  pragma clang system_header
#elif defined(_CCCL_IMPLICIT_SYSTEM_HEADER_MSVC)
#  pragma system_header
#endif // no system header

#include <cub/block/block_store.cuh>
#include <cub/detail/null_type.cuh>
#include <cub/detail/uninitialized.cuh>
#include <cub/util_ptx.cuh>
#include <cub/warp/warp_exchange.cuh>

#include <cuda/__cmath/pow2.h>
#include <cuda/__ptx/instructions/get_sreg.h>
#include <cuda/std/__concepts/same_as.h>
#include <cuda/std/__fwd/format.h>
#include <cuda/std/__host_stdlib/ostream>

CUB_NAMESPACE_BEGIN

//! @rst
//! ``cub::WarpStoreAlgorithm`` enumerates alternative algorithms for :cpp:struct:`cub::WarpStore`
//! to write a blocked arrangement of items across a CUDA warp to a linear segment of memory.
//! @endrst
enum WarpStoreAlgorithm // NOLINT(cppcoreguidelines-use-enum-class)
{
  //! @rst
  //! Overview
  //! ++++++++++++++++++++++++++
  //!
  //! A :ref:`blocked arrangement <flexible-data-arrangement>` of data is written directly
  //! to memory.
  //!
  //! Performance Considerations
  //! ++++++++++++++++++++++++++
  //!
  //! The utilization of memory transactions (coalescing) decreases as the
  //! access stride between threads increases (i.e., the number items per thread).
  //! @endrst
  WARP_STORE_DIRECT,

  //! @rst
  //! Overview
  //! ++++++++++++++++++++++++++
  //!
  //! A :ref:`striped arrangement <flexible-data-arrangement>` of data is written
  //! directly to memory.
  //!
  //! Performance Considerations
  //! ++++++++++++++++++++++++++
  //!
  //! The utilization of memory transactions (coalescing) remains high regardless
  //! of items written per thread.
  //! @endrst
  WARP_STORE_STRIPED,

  //! @rst
  //! Overview
  //! ++++++++++++++++++++++++++
  //!
  //! A :ref:`blocked arrangement <flexible-data-arrangement>` of data is written
  //! directly to memory using CUDA's built-in vectorized stores as a coalescing
  //! optimization. For example, ``st.global.v4.s32`` instructions will be
  //! generated when ``T = int`` and ``ItemsPerThread % 4 == 0``.
  //!
  //! Performance Considerations
  //! ++++++++++++++++++++++++++
  //!
  //! * The utilization of memory transactions (coalescing) remains high until
  //!   the the access stride between threads (i.e., the number items per thread)
  //!   exceeds the maximum vector store width (typically 4 items or 64B,
  //!   whichever is lower).
  //! * The following conditions will prevent vectorization and writing will fall
  //!   back to ``cub::WARP_STORE_DIRECT``:
  //!
  //!   * ``ItemsPerThread`` is odd
  //!   * The ``OutputIteratorT`` is not a simple pointer type
  //!   * The block output offset is not quadword-aligned
  //!   * The data type ``T`` is not a built-in primitive or CUDA vector type
  //!     (e.g., ``short``, ``int2``, ``double``, ``float2``, etc.)
  //!
  //! @endrst
  WARP_STORE_VECTORIZE,

  //! @rst
  //! Overview
  //! ++++++++++++++++++++++++++
  //!
  //! A :ref:`blocked arrangement <flexible-data-arrangement>` is locally
  //! transposed and then efficiently written to memory as a
  //! :ref:`striped arrangement <flexible-data-arrangement>`.
  //!
  //! Performance Considerations
  //! ++++++++++++++++++++++++++
  //!
  //! * The utilization of memory transactions (coalescing) remains high
  //!   regardless of items written per thread.
  //! * The local reordering incurs slightly longer latencies and throughput than the
  //!   direct ``cub::WARP_STORE_DIRECT`` and ``cub::WARP_STORE_VECTORIZE`` alternatives.
  //!
  //! @endrst
  WARP_STORE_TRANSPOSE
};

#if _CCCL_HOSTED()
namespace detail
{
[[nodiscard]] _CCCL_HOST_DEVICE_API constexpr const char* to_string(WarpStoreAlgorithm algo) noexcept
{
  switch (algo)
  {
    case WARP_STORE_DIRECT:
      return "WARP_STORE_DIRECT";
    case WARP_STORE_STRIPED:
      return "WARP_STORE_STRIPED";
    case WARP_STORE_VECTORIZE:
      return "WARP_STORE_VECTORIZE";
    case WARP_STORE_TRANSPOSE:
      return "WARP_STORE_TRANSPOSE";
  }
  return "<unknown WarpStoreAlgorithm>";
}
} // namespace detail

inline ::std::ostream& operator<<(::std::ostream& os, WarpStoreAlgorithm algo)
{
  return os << CUB_NS_QUALIFIER::detail::to_string(algo);
}
#endif // _CCCL_HOSTED()

CUB_NAMESPACE_END

#if __cpp_lib_format >= 201907L && !defined(_CCCL_DOXYGEN_INVOKED)
template <::cuda::std::same_as<char> CharT>
struct std::formatter<CUB_NS_QUALIFIER::WarpStoreAlgorithm, CharT> : formatter<const CharT*, CharT>
{
  template <class FmtCtx>
  auto format(const CUB_NS_QUALIFIER::WarpStoreAlgorithm& algo, FmtCtx& ctx) const
  {
    return formatter<const CharT*, CharT>::format(CUB_NS_QUALIFIER::detail::to_string(algo), ctx);
  }
};
#endif // __cpp_lib_format >= 201907L && !defined(_CCCL_DOXYGEN_INVOKED)

CUB_NAMESPACE_BEGIN

//! @rst
//! The WarpStore class provides :ref:`collective <collective-primitives>`
//! data movement methods for writing a :ref:`blocked arrangement <flexible-data-arrangement>`
//! of items partitioned across a CUDA warp to a linear segment of memory.
//!
//! Overview
//! ++++++++++++++++
//!
//! * The WarpStore class provides a single data movement abstraction that can be
//!   specialized to implement different cub::WarpStoreAlgorithm strategies. This
//!   facilitates different performance policies for different architectures,
//!   data types, granularity sizes, etc.
//! * WarpStore can be optionally specialized by different data movement strategies:
//!
//!   #. :cpp:enumerator:`cub::WARP_STORE_DIRECT`:
//!      a :ref:`blocked arrangement <flexible-data-arrangement>` of data is written directly to
//!      memory.
//!   #. :cpp:enumerator:`cub::WARP_STORE_STRIPED`:
//!      a :ref:`striped arrangement <flexible-data-arrangement>` of data is written directly to
//!      memory.
//!   #. :cpp:enumerator:`cub::WARP_STORE_VECTORIZE`:
//!      a :ref:`blocked arrangement <flexible-data-arrangement>` of data is written directly to
//!      memory using CUDA's built-in vectorized stores as a coalescing optimization.
//!   #. :cpp:enumerator:`cub::WARP_STORE_TRANSPOSE`:
//!      a :ref:`blocked arrangement <flexible-data-arrangement>` is locally transposed into a
//!      :ref:`striped arrangement <flexible-data-arrangement>` which is then written to memory.
//!
//! * @rowmajor
//!
//! A Simple Example
//! ++++++++++++++++
//!
//! The code snippet below illustrates the storing of a "blocked" arrangement
//! of 64 integers across 16 threads (where each thread owns 4 consecutive items)
//! into a linear segment of memory. The store is specialized for
//! ``WARP_STORE_TRANSPOSE``, meaning items are locally reordered among threads so
//! that memory references will be efficiently coalesced using a warp-striped
//! access pattern.
//!
//! .. code-block:: c++
//!
//!    #include <cub/cub.cuh>   // or equivalently <cub/warp/warp_store.cuh>
//!
//!    __global__ void ExampleKernel(int *d_data, ...)
//!    {
//!        constexpr int warp_threads = 16;
//!        constexpr int threads_per_block = 256;
//!        constexpr int items_per_thread = 4;
//!
//!        // Specialize WarpStore for a virtual warp of 16 threads owning 4 integer items each
//!        using WarpStoreT = WarpStore<int,
//!                                     items_per_thread,
//!                                     cub::WARP_STORE_TRANSPOSE,
//!                                     warp_threads>;
//!
//!        constexpr int warps_in_block = threads_per_block / warp_threads;
//!        constexpr int tile_size = items_per_thread * warp_threads;
//!        const int warp_id = static_cast<int>(threadIdx.x) / warp_threads;
//!
//!        // Allocate shared memory for WarpStore
//!        __shared__ typename WarpStoreT::TempStorage temp_storage[warps_in_block];
//!
//!        // Obtain a segment of consecutive items that are blocked across threads
//!        int thread_data[4];
//!        ...
//!
//!        // Store items to linear memory
//!        WarpStoreT(temp_storage[warp_id]).Store(d_data + warp_id * tile_size, thread_data);
//!    }
//!
//! Suppose the set of ``thread_data`` across the warp threads is
//! ``{ [0,1,2,3], [4,5,6,7], ..., [60,61,62,63] }``.
//! The output ``d_data`` will be ``0, 1, 2, 3, 4, 5, ...``.
//! @endrst
//!
//! @tparam T
//!   The type of data to be written.
//!
//! @tparam ItemsPerThread
//!   The number of consecutive items partitioned onto each thread.
//!
//! @tparam ALGORITHM
//!   <b>[optional]</b> cub::WarpStoreAlgorithm tuning policy enumeration.
//!   default: cub::WARP_STORE_DIRECT.
//!
//! @tparam LogicalWarpThreads
//!   <b>[optional]</b> The number of threads per "logical" warp (may be less
//!   than the number of hardware warp threads). Default is the warp size of the
//!   targeted CUDA compute-capability (e.g., 32 threads for SM86). Must be a
//!   power of two.
//!
template <typename T,
          int ItemsPerThread,
          WarpStoreAlgorithm ALGORITHM = WARP_STORE_DIRECT,
          int LogicalWarpThreads       = detail::warp_threads>
class WarpStore
{
  static_assert(::cuda::is_power_of_two(LogicalWarpThreads), "LogicalWarpThreads must be a power of two");

  static constexpr bool IS_ARCH_WARP = LogicalWarpThreads == detail::warp_threads;

private:
  /// Store helper
  template <WarpStoreAlgorithm Algorithm, int DUMMY>
  struct StoreInternal;

  template <int DUMMY>
  struct StoreInternal<WARP_STORE_DIRECT, DUMMY>
  {
    using TempStorage = NullType;

    int linear_tid;

    _CCCL_DEVICE _CCCL_FORCEINLINE StoreInternal(TempStorage& /*temp_storage*/, int linear_tid)
        : linear_tid(linear_tid)
    {}

    template <typename OutputIteratorT>
    _CCCL_DEVICE _CCCL_FORCEINLINE void Store(OutputIteratorT block_itr, T (&items)[ItemsPerThread])
    {
      StoreDirectBlocked(linear_tid, block_itr, items);
    }

    template <typename OutputIteratorT>
    _CCCL_DEVICE _CCCL_FORCEINLINE void Store(OutputIteratorT block_itr, T (&items)[ItemsPerThread], int valid_items)
    {
      StoreDirectBlocked(linear_tid, block_itr, items, valid_items);
    }
  };

  template <int DUMMY>
  struct StoreInternal<WARP_STORE_STRIPED, DUMMY>
  {
    using TempStorage = NullType;

    int linear_tid;

    _CCCL_DEVICE _CCCL_FORCEINLINE StoreInternal(TempStorage& /*temp_storage*/, int linear_tid)
        : linear_tid(linear_tid)
    {}

    template <typename OutputIteratorT>
    _CCCL_DEVICE _CCCL_FORCEINLINE void Store(OutputIteratorT block_itr, T (&items)[ItemsPerThread])
    {
      StoreDirectStriped<LogicalWarpThreads>(linear_tid, block_itr, items);
    }

    template <typename OutputIteratorT>
    _CCCL_DEVICE _CCCL_FORCEINLINE void Store(OutputIteratorT block_itr, T (&items)[ItemsPerThread], int valid_items)
    {
      StoreDirectStriped<LogicalWarpThreads>(linear_tid, block_itr, items, valid_items);
    }
  };

  template <int DUMMY>
  struct StoreInternal<WARP_STORE_VECTORIZE, DUMMY>
  {
    using TempStorage = NullType;

    int linear_tid;

    _CCCL_DEVICE _CCCL_FORCEINLINE StoreInternal(TempStorage& /*temp_storage*/, int linear_tid)
        : linear_tid(linear_tid)
    {}

    _CCCL_DEVICE _CCCL_FORCEINLINE void Store(T* block_ptr, T (&items)[ItemsPerThread])
    {
      StoreDirectBlockedVectorized(linear_tid, block_ptr, items);
    }

    template <typename OutputIteratorT>
    _CCCL_DEVICE _CCCL_FORCEINLINE void Store(OutputIteratorT block_itr, T (&items)[ItemsPerThread])
    {
      StoreDirectBlocked(linear_tid, block_itr, items);
    }

    template <typename OutputIteratorT>
    _CCCL_DEVICE _CCCL_FORCEINLINE void Store(OutputIteratorT block_itr, T (&items)[ItemsPerThread], int valid_items)
    {
      StoreDirectBlocked(linear_tid, block_itr, items, valid_items);
    }
  };

  template <int DUMMY>
  struct StoreInternal<WARP_STORE_TRANSPOSE, DUMMY>
  {
    using WarpExchangeT = WarpExchange<T, ItemsPerThread, LogicalWarpThreads>;

    struct _TempStorage : WarpExchangeT::TempStorage
    {};

    using TempStorage = Uninitialized<_TempStorage>;

    _TempStorage& temp_storage;

    int linear_tid;

    _CCCL_DEVICE _CCCL_FORCEINLINE StoreInternal(TempStorage& temp_storage, int linear_tid)
        : temp_storage(temp_storage.Alias())
        , linear_tid(linear_tid)
    {}

    template <typename OutputIteratorT>
    _CCCL_DEVICE _CCCL_FORCEINLINE void Store(OutputIteratorT block_itr, T (&items)[ItemsPerThread])
    {
      WarpExchangeT(temp_storage).BlockedToStriped(items, items);
      StoreDirectStriped<LogicalWarpThreads>(linear_tid, block_itr, items);
    }

    template <typename OutputIteratorT>
    _CCCL_DEVICE _CCCL_FORCEINLINE void Store(OutputIteratorT block_itr, T (&items)[ItemsPerThread], int valid_items)
    {
      WarpExchangeT(temp_storage).BlockedToStriped(items, items);
      StoreDirectStriped<LogicalWarpThreads>(linear_tid, block_itr, items, valid_items);
    }
  };

  /// Internal load implementation to use
  using InternalStore = StoreInternal<ALGORITHM, 0>;

  /// Shared memory storage layout type
  using _TempStorage = typename InternalStore::TempStorage;

  _CCCL_DEVICE _CCCL_FORCEINLINE _TempStorage& PrivateStorage()
  {
    __shared__ _TempStorage private_storage;
    return private_storage;
  }

  _TempStorage& temp_storage;

  int linear_tid;

public:
  using TempStorage = Uninitialized<_TempStorage>;

  //! @name Collective constructors
  //! @{

  //! @brief Collective constructor using a private static allocation of shared
  //!        memory as temporary storage.
  _CCCL_DEVICE _CCCL_FORCEINLINE WarpStore()
      : temp_storage(PrivateStorage())
      , linear_tid(
          IS_ARCH_WARP ? ::cuda::ptx::get_sreg_laneid() : (::cuda::ptx::get_sreg_laneid() % LogicalWarpThreads))
  {}

  //! @brief Collective constructor using the specified memory allocation as
  //!        temporary storage.
  _CCCL_DEVICE _CCCL_FORCEINLINE WarpStore(TempStorage& temp_storage)
      : temp_storage(temp_storage.Alias())
      , linear_tid(
          IS_ARCH_WARP ? ::cuda::ptx::get_sreg_laneid() : (::cuda::ptx::get_sreg_laneid() % LogicalWarpThreads))
  {}

  //! @}
  //! @name Data movement
  //! @{

  //! @rst
  //! Store items into a linear segment of memory.
  //!
  //! .. versionadded:: 2.2.0
  //!    First appears in CUDA Toolkit 12.3.
  //!
  //! @smemwarpreuse
  //!
  //! Snippet
  //! +++++++
  //!
  //! The code snippet below illustrates the storing of a "blocked" arrangement
  //! of 64 integers across 16 threads (where each thread owns 4 consecutive items)
  //! into a linear segment of memory. The store is specialized for
  //! ``WARP_STORE_TRANSPOSE``, meaning items are locally reordered among threads so
  //! that memory references will be efficiently coalesced using a warp-striped
  //! access pattern.
  //!
  //! .. code-block:: c++
  //!
  //!    #include <cub/cub.cuh>   // or equivalently <cub/warp/warp_store.cuh>
  //!
  //!    __global__ void ExampleKernel(int *d_data, ...)
  //!    {
  //!        constexpr int warp_threads = 16;
  //!        constexpr int threads_per_block = 256;
  //!        constexpr int items_per_thread = 4;
  //!
  //!        // Specialize WarpStore for a virtual warp of 16 threads owning 4 integer items each
  //!        using WarpStoreT = WarpStore<int,
  //!                                     items_per_thread,
  //!                                     cub::WARP_STORE_TRANSPOSE,
  //!                                     warp_threads>;
  //!
  //!        constexpr int warps_in_block = threads_per_block / warp_threads;
  //!        constexpr int tile_size = items_per_thread * warp_threads;
  //!        const int warp_id = static_cast<int>(threadIdx.x) / warp_threads;
  //!
  //!        // Allocate shared memory for WarpStore
  //!        __shared__ typename WarpStoreT::TempStorage temp_storage[warps_in_block];
  //!
  //!        // Obtain a segment of consecutive items that are blocked across threads
  //!        int thread_data[4];
  //!        ...
  //!
  //!        // Store items to linear memory
  //!        WarpStoreT(temp_storage[warp_id]).Store(d_data + warp_id * tile_size, thread_data);
  //!
  //! Suppose the set of ``thread_data`` across the warp threads is
  //! ``{ [0,1,2,3], [4,5,6,7], ..., [60,61,62,63] }``.
  //! The output ``d_data`` will be ``0, 1, 2, 3, 4, 5, ...``.
  //! @endrst
  //!
  //! @param[out] block_itr The thread block's base output iterator for storing to
  //! @param[in] items Data to store
  template <typename OutputIteratorT>
  _CCCL_DEVICE _CCCL_FORCEINLINE void Store(OutputIteratorT block_itr, T (&items)[ItemsPerThread])
  {
    InternalStore(temp_storage, linear_tid).Store(block_itr, items);
  }

  //! @rst
  //! Store items into a linear segment of memory, guarded by range.
  //!
  //! .. versionadded:: 2.2.0
  //!    First appears in CUDA Toolkit 12.3.
  //!
  //! @smemwarpreuse
  //!
  //! Snippet
  //! +++++++
  //!
  //! The code snippet below illustrates the storing of a "blocked" arrangement
  //! of 64 integers across 16 threads (where each thread owns 4 consecutive items)
  //! into a linear segment of memory. The store is specialized for
  //! ``WARP_STORE_TRANSPOSE``, meaning items are locally reordered among threads so
  //! that memory references will be efficiently coalesced using a warp-striped
  //! access pattern.
  //!
  //! .. code-block:: c++
  //!
  //!    #include <cub/cub.cuh>   // or equivalently <cub/warp/warp_store.cuh>
  //!
  //!    __global__ void ExampleKernel(int *d_data, int valid_items ...)
  //!    {
  //!        constexpr int warp_threads = 16;
  //!        constexpr int threads_per_block = 256;
  //!        constexpr int items_per_thread = 4;
  //!
  //!        // Specialize WarpStore for a virtual warp of 16 threads owning 4 integer items each
  //!        using WarpStoreT = WarpStore<int,
  //!                                     items_per_thread,
  //!                                     cub::WARP_STORE_TRANSPOSE,
  //!                                     warp_threads>;
  //!
  //!        constexpr int warps_in_block = threads_per_block / warp_threads;
  //!        constexpr int tile_size = items_per_thread * warp_threads;
  //!        const int warp_id = static_cast<int>(threadIdx.x) / warp_threads;
  //!
  //!        // Allocate shared memory for WarpStore
  //!        __shared__ typename WarpStoreT::TempStorage temp_storage[warps_in_block];
  //!
  //!        // Obtain a segment of consecutive items that are blocked across threads
  //!        int thread_data[4];
  //!        ...
  //!
  //!        // Store items to linear memory
  //!        WarpStoreT(temp_storage[warp_id]).Store(
  //!          d_data + warp_id * tile_size, thread_data, valid_items);
  //!
  //! Suppose the set of ``thread_data`` across the warp threads is
  //! ``{ [0,1,2,3], [4,5,6,7], ..., [60,61,62,63] }`` and ``valid_items``
  //! is ``5``. The output ``d_data`` will be ``0, 1, 2, 3, 4, ?, ?, ...``,
  //! with only the first two threads being unmasked to store portions of valid
  //! data.
  //! @endrst
  //!
  //! @param[out] block_itr The thread block's base output iterator for storing to
  //! @param[in] items Data to store
  //! @param[in] valid_items Number of valid items to write
  //!
  template <typename OutputIteratorT>
  _CCCL_DEVICE _CCCL_FORCEINLINE void Store(OutputIteratorT block_itr, T (&items)[ItemsPerThread], int valid_items)
  {
    InternalStore(temp_storage, linear_tid).Store(block_itr, items, valid_items);
  }

  //! @}
};

CUB_NAMESPACE_END
