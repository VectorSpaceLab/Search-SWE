// SPDX-FileCopyrightText: Copyright (c) 2011, Duane Merrill. All rights reserved.
// SPDX-FileCopyrightText: Copyright (c) 2011-2025, NVIDIA CORPORATION. All rights reserved.
// SPDX-License-Identifier: BSD-3

//! @rst
//! @file
//! cub::BlockReduceWarpReductions provides variants of warp-reduction-based parallel reduction
//! across a CUDA thread block. Supports non-commutative reduction operators.
//! @endrst

#pragma once

#include <cub/config.cuh>

#if defined(_CCCL_IMPLICIT_SYSTEM_HEADER_GCC)
#  pragma GCC system_header
#elif defined(_CCCL_IMPLICIT_SYSTEM_HEADER_CLANG)
#  pragma clang system_header
#elif defined(_CCCL_IMPLICIT_SYSTEM_HEADER_MSVC)
#  pragma system_header
#endif // no system header

#include <cub/detail/uninitialized.cuh>
#include <cub/detail/uninitialized_copy.cuh>
#include <cub/util_ptx.cuh>
#include <cub/warp/specializations/warp_reduce_shfl.cuh>
#include <cub/warp/warp_reduce.cuh>

#include <cuda/__cmath/ceil_div.h>
#include <cuda/__cmath/pow2.h>
#include <cuda/__functional/operator_properties.h>
#include <cuda/__ptx/instructions/get_sreg.h>
#include <cuda/atomic>
#include <cuda/std/__algorithm/min.h>

CUB_NAMESPACE_BEGIN
namespace detail
{
//! @rst
//! BlockReduceWarpReductions provides variants of warp-reduction-based parallel reduction
//! across a CUDA thread block. Supports non-commutative reduction operators.
//! @endrst
//!
//! @tparam T
//!   Data type being reduced
//!
//! @tparam BlockDimX
//!   The thread block length in threads along the X dimension
//!
//! @tparam BlockDimY
//!   The thread block length in threads along the Y dimension
//!
//! @tparam BlockDimZ
//!   The thread block length in threads along the Z dimension
//!
//! @tparam IsDeterministic
//!   Whether the reduction is deterministic
//!
//! @tparam WarpAggregateThreshold
//!   Minimum number of warps required to use the parallel warp-0 reduction path.
//!   -1 (default) or 0: always use sequential path.
//!   >0: use parallel path when warps >= threshold.
//!   Values below -1 are rejected via static_assert.
template <typename T,
          int BlockDimX,
          int BlockDimY,
          int BlockDimZ,
          bool IsDeterministic       = true,
          int WarpAggregateThreshold = -1>
struct BlockReduceWarpReductions
{
  /// The thread block size in threads
  static constexpr int threads_per_block = BlockDimX * BlockDimY * BlockDimZ;

  /// Number of active warps
  static constexpr int warps = ::cuda::ceil_div(threads_per_block, warp_threads);

  /// The logical warp size for warp reductions
  static constexpr int logical_warp_size = ::cuda::std::min(threads_per_block, warp_threads);

  /// Whether or not the logical warp size evenly divides the thread block size
  static constexpr bool even_warp_multiple = (threads_per_block % logical_warp_size == 0);

  static_assert(WarpAggregateThreshold >= -1, "WarpAggregateThreshold must be -1, 0, or positive");

  using WarpReduceInternal = typename WarpReduce<T, logical_warp_size>::InternalWarpReduce;

  /// Shared memory storage layout type
  struct _TempStorage
  {
    /// Buffer for warp-synchronous reduction
    typename WarpReduceInternal::TempStorage warp_reduce[warps];

    /// Shared totals from each warp-synchronous reduction
    T warp_aggregates[warps];

    /// Shared prefix for the entire thread block
    T block_prefix;
  };

  using TempStorage = Uninitialized<_TempStorage>;

  // Thread fields
  _TempStorage& temp_storage;
  int linear_tid;
  int warp_id;
  int lane_id;

  _CCCL_DEVICE _CCCL_FORCEINLINE BlockReduceWarpReductions(TempStorage& temp_storage)
      : temp_storage(temp_storage.Alias())
      , linear_tid(RowMajorTid(BlockDimX, BlockDimY, BlockDimZ))
      , warp_id((warps == 1) ? 0 : linear_tid / warp_threads)
      , lane_id(static_cast<int>(::cuda::ptx::get_sreg_laneid()))
  {}

  //! @rst
  //! Returns block-wide aggregate in *thread*\ :sub:`0`.
  //! @endrst
  //!
  //! @tparam ReductionOp
  //!   **[inferred]** Binary reduction operator type
  //!
  //! @param[in] reduction_op
  //!   Binary reduction operator
  //!
  //! @param[in] warp_aggregate
  //!   **[**\ *lane*\ :sub:`0` **only]** Warp-wide aggregate reduction of input items
  template <typename ReductionOp>
  _CCCL_DEVICE _CCCL_FORCEINLINE T ApplyWarpAggregatesNonDeterministic(ReductionOp /*reduction_op*/, T warp_aggregate)
  {
    if (linear_tid == 0)
    {
      detail::uninitialized_copy_single(temp_storage.warp_aggregates, warp_aggregate);
    }

    __syncthreads();

    // Warp 0 already contributed its aggregate above since it is also linear_tid == 0
    if (lane_id == 0 && warp_id != 0)
    {
      // TODO: replace this with other atomic operations when specified
      const ::cuda::atomic_ref<T, ::cuda::thread_scope_block> atomic_target(temp_storage.warp_aggregates[0]);
      atomic_target.fetch_add(warp_aggregate, ::cuda::memory_order_relaxed);
    }

    __syncthreads();
    return temp_storage.warp_aggregates[0];
  }

  //! @rst
  //! Cooperatively reduces warp aggregates.
  //!
  //! For small blocks (few warps) the reduction is performed sequentially by ``linear_tid == 0``.
  //! For larger blocks, warp 0 reduces the warp aggregates in parallel:
  //! @endrst
  //!
  //! @tparam FullTile
  //!   **[inferred]** Whether this is a full tile
  //!
  //! @tparam ReductionOp
  //!   **[inferred]** Binary reduction operator type
  template <bool FullTile, typename ReductionOp>
  _CCCL_DEVICE _CCCL_FORCEINLINE T ApplyWarpAggregates(ReductionOp reduction_op, T warp_aggregate, int num_valid)
  {
    // Share lane aggregates
    if (lane_id == 0)
    {
      detail::uninitialized_copy_single(temp_storage.warp_aggregates + warp_id, warp_aggregate);
    }

    __syncthreads();

    // Decide whether to reduce warp aggregates in parallel (warp-0) or sequentially (thread-0).
    // Sequential by default: a simple unrolled loop over <=31 values is just as fast.
    // The parallel path is only used when WarpAggregateThreshold is positive and met.
    constexpr int effective_threshold     = WarpAggregateThreshold > 0 ? WarpAggregateThreshold : warps + 1;
    constexpr bool use_parallel_reduction = (warps >= effective_threshold) && (threads_per_block >= warp_threads);

    // TODO(WarpShuffle PR): replace with cub::WarpReduce<T, warps>.
    if constexpr (!use_parallel_reduction)
    {
      // Single-thread sequential reduction over warp aggregates.
      if (linear_tid == 0)
      {
        _CCCL_PRAGMA_UNROLL_FULL()
        for (int warp_idx = 1; warp_idx < warps; ++warp_idx)
        {
          if (FullTile || (warp_idx * logical_warp_size < num_valid))
          {
            const auto addend = temp_storage.warp_aggregates[warp_idx];
            warp_aggregate    = reduction_op(warp_aggregate, addend);
          }
        }
      }
      return warp_aggregate;
    }
    else
    {
      // Parallel reduction in warp 0.
      if (warp_id == 0)
      {
        const int num_warps =
          FullTile ? warps : ::cuda::std::min(::cuda::ceil_div(num_valid, logical_warp_size), +warps);

        const T val = (lane_id < num_warps) ? temp_storage.warp_aggregates[lane_id] : T{};

        constexpr int logical_lanes = ::cuda::next_power_of_two(warps);
        NullType dummy_storage;
        WarpReduceShfl<T, logical_lanes> warp_reduce(dummy_storage);

        constexpr bool all_lanes_valid = FullTile && (warps == logical_lanes);
        warp_aggregate                 = warp_reduce.template Reduce<all_lanes_valid>(val, num_warps, reduction_op);
      }
      return warp_aggregate;
    }
  }

  //! @rst
  //! Computes a thread block-wide reduction using addition (+/cuda::std::plus<>) as the reduction operator.
  //! The first num_valid threads each contribute one reduction partial. The return value is
  //! only valid for *thread*\ :sub:`0`.
  //! @endrst
  //!
  //! @tparam FullTile
  //!   **[inferred]** Whether this is a full tile
  //!
  //! @param[in] input
  //!   Calling thread's input partial reductions
  //!
  //! @param[in] num_valid
  //!   Number of valid elements (may be less than threads_per_block)
  template <bool FullTile>
  _CCCL_DEVICE _CCCL_FORCEINLINE T Sum(T input, int num_valid)
  {
    return Reduce<FullTile>(input, num_valid, ::cuda::std::plus<>{});
  }

  //! @rst
  //! Computes a thread block-wide reduction using the specified reduction operator.
  //! The first num_valid threads each contribute one reduction partial.
  //! The return value is only valid for *thread*\ :sub:`0`.
  //! @endrst
  //!
  //! @tparam FullTile
  //!   **[inferred]** Whether this is a full tile
  //!
  //! @tparam ReductionOp
  //!   **[inferred]** Binary reduction operator type
  //!
  //! @param[in] input
  //!   Calling thread's input partial reductions
  //!
  //! @param[in] num_valid
  //!   Number of valid elements (may be less than threads_per_block)
  //!
  //! @param[in] reduction_op
  //!   Binary reduction operator
  template <bool FullTile, typename ReductionOp>
  _CCCL_DEVICE _CCCL_FORCEINLINE T Reduce(T input, int num_valid, ReductionOp reduction_op)
  {
    const int warp_offset = warp_id * logical_warp_size;
    const int warp_num_valid =
      ((FullTile && even_warp_multiple) || (warp_offset + logical_warp_size <= num_valid))
        ? logical_warp_size
        : num_valid - warp_offset;

    // Warp reduction in every warp
    const T warp_aggregate = WarpReduceInternal(temp_storage.warp_reduce[warp_id])
                               .template Reduce<(FullTile && even_warp_multiple)>(input, warp_num_valid, reduction_op);

    // Update outputs and block_aggregate with warp-wide aggregates from lane-0s
    // The atomic accumulation of warp aggregates is only valid for addition
    if constexpr (IsDeterministic || !::cuda::__is_cuda_std_plus_v<ReductionOp, T>)
    {
      return ApplyWarpAggregates<FullTile>(reduction_op, warp_aggregate, num_valid);
    }
    else
    {
      // Warps without valid items contribute the additive identity
      const T add_value = (FullTile || warp_offset < num_valid) ? warp_aggregate : T{};
      return ApplyWarpAggregatesNonDeterministic(reduction_op, add_value);
    }
  }
};
} // namespace detail

CUB_NAMESPACE_END
